"""Initial schema, sequences and row-level security policies.

Revision ID: 0001
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

APP_ROLE = "wm_app"


def upgrade() -> None:
    bind = op.get_bind()

    # ---- enums -----------------------------------------------------------
    op.execute("CREATE TYPE user_role AS ENUM ('DEO','CLIN','HOD','IMAGE')")
    op.execute("CREATE TYPE record_status AS ENUM "
               "('DRAFT','SUBMITTED','QUERY','VERIFIED','APPROVED')")
    op.execute("CREATE TYPE query_status AS ENUM ('OPEN','RESOLVED','CANCELLED')")

    # ---- sequences used for human-facing identifiers ----------------------
    op.execute("CREATE SEQUENCE registry_no_seq START 1")
    op.execute("CREATE SEQUENCE query_no_seq START 1")

    uuid_pk = dict(type_=postgresql.UUID(as_uuid=True), primary_key=True,
                   server_default=sa.text("gen_random_uuid()"))
    op.execute("CREATE EXTENSION IF NOT EXISTS pgcrypto")

    # ---- centres ---------------------------------------------------------
    op.create_table(
        "centres",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("code", sa.String(16), nullable=False, unique=True),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("city", sa.String(80)),
        sa.Column("state", sa.String(80)),
        sa.Column("zone", sa.String(40)),
        sa.Column("pi_name", sa.String(160)),
        sa.Column("ethics_approval_ref", sa.String(120)),
        sa.Column("ethics_approval_date", sa.Date),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("true")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # ---- users -----------------------------------------------------------
    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("email", sa.String(255), nullable=False, unique=True),
        sa.Column("full_name", sa.String(160), nullable=False),
        sa.Column("designation", sa.String(160)),
        sa.Column("role", postgresql.ENUM(name="user_role", create_type=False), nullable=False),
        sa.Column("centre_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("centres.id", ondelete="RESTRICT")),
        sa.Column("password_hash", sa.String(255), nullable=False),
        sa.Column("must_change_password", sa.Boolean, nullable=False, server_default=sa.text("true")),
        sa.Column("password_changed_at", sa.DateTime(timezone=True)),
        sa.Column("totp_secret", sa.String(64)),
        sa.Column("totp_enabled", sa.Boolean, nullable=False, server_default=sa.text("false")),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("true")),
        sa.Column("failed_logins", sa.Integer, nullable=False, server_default="0"),
        sa.Column("locked_until", sa.DateTime(timezone=True)),
        sa.Column("last_login_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.CheckConstraint("(role = 'IMAGE') OR (centre_id IS NOT NULL)",
                           name="ck_users_centre_required"),
    )
    op.create_index("ix_users_centre_id", "users", ["centre_id"])

    op.create_table(
        "refresh_tokens",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("token_hash", sa.String(128), nullable=False, unique=True),
        sa.Column("issued_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("revoked_at", sa.DateTime(timezone=True)),
        sa.Column("ip", sa.String(64)),
        sa.Column("user_agent", sa.String(300)),
    )
    op.create_index("ix_refresh_tokens_user_id", "refresh_tokens", ["user_id"])

    # ---- import batches (referenced by patients) -------------------------
    op.create_table(
        "import_batches",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("centre_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("centres.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("filename", sa.String(300), nullable=False),
        sa.Column("sheet_name", sa.String(120)),
        sa.Column("uploaded_by", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("users.id"), nullable=False),
        sa.Column("uploaded_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("rows_read", sa.Integer, nullable=False, server_default="0"),
        sa.Column("rows_imported", sa.Integer, nullable=False, server_default="0"),
        sa.Column("rows_skipped", sa.Integer, nullable=False, server_default="0"),
        sa.Column("committed", sa.Boolean, nullable=False, server_default=sa.text("false")),
        sa.Column("report", postgresql.JSONB, server_default=sa.text("'{}'::jsonb")),
    )
    op.create_index("ix_import_batches_centre_id", "import_batches", ["centre_id"])

    # ---- patients --------------------------------------------------------
    bool_cols = ["sym_anaemia", "fever", "bleeding", "hyperviscosity", "constitutional",
                 "igm_symptoms", "lymphadenopathy", "splenomegaly", "dct", "amyloid",
                 "cryoglobulins", "pb_lpl", "relapse", "transformation", "death"]
    float_cols = ["hb", "tlc", "alc", "platelets", "calcium", "urea", "creatinine",
                  "total_protein", "albumin", "ldh", "m_band", "igm", "kappa_flc",
                  "lambda_flc", "beta2m", "bm_lpl_pct"]
    date_cols = ["dx_date", "bm_date", "relapse_date", "transformation_date",
                 "death_date", "last_followup_date"]

    op.create_table(
        "patients",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("registry_no", sa.Integer, nullable=False, unique=True),
        sa.Column("registry_id", sa.String(16), nullable=False, unique=True),
        sa.Column("centre_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("centres.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("crno", sa.String(64), nullable=False),
        sa.Column("age", sa.Integer),
        sa.Column("gender", sa.String(16)),
        *[sa.Column(c, sa.Boolean) for c in bool_cols],
        sa.Column("ecog_dx", sa.Integer),
        sa.Column("clinical_notes", sa.Text),
        *[sa.Column(c, sa.Float) for c in float_cols],
        *[sa.Column(c, sa.Date) for c in date_cols],
        sa.Column("srsm_score", sa.String(32)),
        sa.Column("hiv", sa.String(16)),
        sa.Column("hbsag", sa.String(16)),
        sa.Column("anti_hcv", sa.String(16)),
        sa.Column("anti_hbc", sa.String(16)),
        sa.Column("sife", sa.String(64)),
        sa.Column("myd88", sa.String(24)),
        sa.Column("cxcr4", sa.String(24)),
        sa.Column("death_cause", sa.String(120)),
        sa.Column("status", postgresql.ENUM(name="record_status", create_type=False),
                  nullable=False, server_default="DRAFT"),
        sa.Column("submitted_by", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id")),
        sa.Column("submitted_at", sa.DateTime(timezone=True)),
        sa.Column("verified_by", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id")),
        sa.Column("verified_at", sa.DateTime(timezone=True)),
        sa.Column("approved_by", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id")),
        sa.Column("approved_at", sa.DateTime(timezone=True)),
        sa.Column("followup_amended", sa.Boolean, nullable=False, server_default=sa.text("false")),
        sa.Column("followup_amended_at", sa.DateTime(timezone=True)),
        sa.Column("import_batch_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("import_batches.id", ondelete="SET NULL")),
        sa.Column("import_issue_count", sa.Integer, nullable=False, server_default="0"),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("version", sa.Integer, nullable=False, server_default="1"),
        sa.UniqueConstraint("centre_id", "crno", name="uq_patient_centre_crno"),
        sa.CheckConstraint("age IS NULL OR (age BETWEEN 0 AND 120)", name="ck_patient_age"),
        sa.CheckConstraint("hb IS NULL OR (hb BETWEEN 0 AND 30)", name="ck_patient_hb"),
        sa.CheckConstraint("bm_lpl_pct IS NULL OR (bm_lpl_pct BETWEEN 0 AND 100)",
                           name="ck_patient_bmlpl"),
        sa.CheckConstraint("death_date IS NULL OR dx_date IS NULL OR death_date >= dx_date",
                           name="ck_patient_death_after_dx"),
        sa.CheckConstraint("death IS NOT TRUE OR death_date IS NOT NULL",
                           name="ck_patient_death_date"),
    )
    op.create_index("ix_patients_centre_id", "patients", ["centre_id"])
    op.create_index("ix_patients_status", "patients", ["status"])
    op.create_index("ix_patients_centre_status", "patients", ["centre_id", "status"])
    op.create_index("ix_patients_dx_date", "patients", ["dx_date"])

    # ---- therapy lines ---------------------------------------------------
    op.create_table(
        "therapy_lines",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("patient_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("patients.id", ondelete="CASCADE"), nullable=False),
        sa.Column("centre_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("centres.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("line_no", sa.Integer, nullable=False),
        sa.Column("category", sa.String(80)),
        sa.Column("regimen", sa.String(200)),
        sa.Column("cycles", sa.Integer),
        sa.Column("start_date", sa.Date),
        sa.Column("end_date", sa.Date),
        sa.Column("best_response", sa.String(80)),
        sa.Column("stop_reason", sa.String(120)),
        sa.Column("grade3_toxicity", sa.Boolean),
        sa.Column("toxicity_detail", sa.Text),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("added_after_lock", sa.Boolean, nullable=False, server_default=sa.text("false")),
        sa.UniqueConstraint("patient_id", "line_no", name="uq_line_patient_no"),
        sa.CheckConstraint("cycles IS NULL OR (cycles BETWEEN 0 AND 100)", name="ck_line_cycles"),
        sa.CheckConstraint("end_date IS NULL OR start_date IS NULL OR end_date >= start_date",
                           name="ck_line_dates"),
    )
    op.create_index("ix_therapy_lines_patient_id", "therapy_lines", ["patient_id"])
    op.create_index("ix_therapy_lines_centre_id", "therapy_lines", ["centre_id"])

    # ---- follow-up visits ------------------------------------------------
    op.create_table(
        "followup_visits",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("patient_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("patients.id", ondelete="CASCADE"), nullable=False),
        sa.Column("centre_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("centres.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("visit_date", sa.Date, nullable=False),
        sa.Column("visit_type", sa.String(80)),
        sa.Column("ecog", sa.Integer),
        sa.Column("on_therapy", sa.Boolean),
        sa.Column("hb", sa.Float), sa.Column("tlc", sa.Float), sa.Column("alc", sa.Float),
        sa.Column("platelets", sa.Float), sa.Column("creatinine", sa.Float),
        sa.Column("total_protein", sa.Float), sa.Column("albumin", sa.Float),
        sa.Column("igm", sa.Float), sa.Column("m_band", sa.Float), sa.Column("beta2m", sa.Float),
        sa.Column("disease_status", sa.String(80)),
        sa.Column("transfusion_dependent", sa.Boolean),
        sa.Column("new_symptoms", sa.Text),
        sa.Column("notes", sa.Text),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("added_after_lock", sa.Boolean, nullable=False, server_default=sa.text("false")),
        sa.UniqueConstraint("patient_id", "visit_date", name="uq_visit_patient_date"),
        sa.CheckConstraint("ecog IS NULL OR (ecog BETWEEN 0 AND 4)", name="ck_visit_ecog"),
    )
    op.create_index("ix_followup_visits_patient_id", "followup_visits", ["patient_id"])
    op.create_index("ix_followup_visits_centre_id", "followup_visits", ["centre_id"])
    op.create_index("ix_visits_patient_date", "followup_visits", ["patient_id", "visit_date"])

    # ---- data queries ----------------------------------------------------
    op.create_table(
        "data_queries",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("query_no", sa.String(16), nullable=False, unique=True),
        sa.Column("patient_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("patients.id", ondelete="CASCADE"), nullable=False),
        sa.Column("centre_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("centres.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("field_key", sa.String(64)),
        sa.Column("query_text", sa.Text, nullable=False),
        sa.Column("status", postgresql.ENUM(name="query_status", create_type=False),
                  nullable=False, server_default="OPEN"),
        sa.Column("raised_by", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id"),
                  nullable=False),
        sa.Column("raised_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("resolved_by", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id")),
        sa.Column("resolved_at", sa.DateTime(timezone=True)),
        sa.Column("resolution_note", sa.Text),
    )
    op.create_index("ix_data_queries_patient_id", "data_queries", ["patient_id"])
    op.create_index("ix_data_queries_centre_id", "data_queries", ["centre_id"])
    op.create_index("ix_data_queries_status", "data_queries", ["status"])

    # ---- audit log -------------------------------------------------------
    op.create_table(
        "audit_log",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id")),
        sa.Column("user_name", sa.String(160)),
        sa.Column("user_role", sa.String(16)),
        sa.Column("centre_code", sa.String(16)),
        sa.Column("action", sa.String(80), nullable=False),
        sa.Column("entity_type", sa.String(40)),
        sa.Column("entity_id", sa.String(64)),
        sa.Column("registry_id", sa.String(16)),
        sa.Column("ip", sa.String(64)),
        sa.Column("user_agent", sa.String(300)),
        sa.Column("changes", postgresql.JSONB),
        sa.Column("detail", sa.Text),
    )
    op.create_index("ix_audit_log_at", "audit_log", ["at"])
    op.create_index("ix_audit_log_centre_code", "audit_log", ["centre_code"])
    op.create_index("ix_audit_log_registry_id", "audit_log", ["registry_id"])

    # =====================================================================
    # ROW-LEVEL SECURITY
    #
    # The application connects as an unprivileged role. These policies mean a
    # centre's rows are invisible to any session whose app.centre_id setting
    # does not match, regardless of what the SQL asks for. The national role
    # (app.national = 'on') may read rows a centre has released to the pool,
    # and may never write.
    # =====================================================================
    op.execute(f"""
    DO $$
    BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{APP_ROLE}') THEN
        CREATE ROLE {APP_ROLE} LOGIN PASSWORD 'change-me';
      END IF;
    END $$;
    """)
    op.execute(f"GRANT USAGE ON SCHEMA public TO {APP_ROLE}")
    op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO {APP_ROLE}")
    op.execute(f"GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO {APP_ROLE}")
    # The audit trail is append-only even for the application role.
    op.execute(f"REVOKE UPDATE, DELETE ON audit_log FROM {APP_ROLE}")

    scoped = {
        "patients": "centre_id",
        "therapy_lines": "centre_id",
        "followup_visits": "centre_id",
        "data_queries": "centre_id",
        "import_batches": "centre_id",
    }
    for table, col in scoped.items():
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        # Read: own centre, or the national role.
        op.execute(f"""
            CREATE POLICY {table}_read ON {table} FOR SELECT USING (
                current_setting('app.national', true) = 'on'
                OR {col}::text = current_setting('app.centre_id', true)
            )""")
        # Write: own centre only. The national role can never write.
        op.execute(f"""
            CREATE POLICY {table}_write ON {table} FOR ALL USING (
                current_setting('app.national', true) IS DISTINCT FROM 'on'
                AND {col}::text = current_setting('app.centre_id', true)
            ) WITH CHECK (
                current_setting('app.national', true) IS DISTINCT FROM 'on'
                AND {col}::text = current_setting('app.centre_id', true)
            )""")

    # Reference tables stay readable to every authenticated session.
    for table in ("centres", "users", "audit_log", "refresh_tokens"):
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"CREATE POLICY {table}_all ON {table} FOR ALL USING (true) WITH CHECK (true)")


def downgrade() -> None:
    for t in ("audit_log", "data_queries", "followup_visits", "therapy_lines",
              "patients", "import_batches", "refresh_tokens", "users", "centres"):
        op.execute(f"DROP TABLE IF EXISTS {t} CASCADE")
    op.execute("DROP SEQUENCE IF EXISTS registry_no_seq")
    op.execute("DROP SEQUENCE IF EXISTS query_no_seq")
    for e in ("user_role", "record_status", "query_status"):
        op.execute(f"DROP TYPE IF EXISTS {e}")
