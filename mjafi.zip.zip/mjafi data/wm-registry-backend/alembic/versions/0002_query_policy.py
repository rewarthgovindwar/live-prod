"""Allow the national coordinator to raise (but not alter) a data query.

The base write policy deliberately excludes the national context from every
table, which is what stops the coordinator editing a centre's data. Raising a
query is the single exception: it is how a correction request travels back to
the owning centre. This adds a narrow INSERT-only policy for that case; UPDATE
and DELETE remain closed to the national context, so only the owning centre can
close a query.

Revision ID: 0002
Revises: 0001
"""
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""
        CREATE POLICY data_queries_national_insert ON data_queries
        FOR INSERT WITH CHECK (current_setting('app.national', true) = 'on')
    """)
    # The coordinator must also be able to read the queries they raised, on
    # records that have been released to the pool. The existing read policy
    # already permits this, so nothing further is required.


def downgrade() -> None:
    op.execute("DROP POLICY IF EXISTS data_queries_national_insert ON data_queries")
