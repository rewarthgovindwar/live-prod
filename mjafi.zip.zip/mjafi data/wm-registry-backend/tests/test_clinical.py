"""Derived clinical values, validation rules and survival estimation."""
from datetime import date

import pytest

from app.core.config import settings
from app.services.derive import ipss_wm, months_between, survival
from app.services.dictionary import FIELD_BY_KEY
from app.services.survival import kaplan_meier, logrank
from app.services.validation import coerce, parse_date

API = settings.API_PREFIX


# --------------------------------------------------------------------------- IPSS-WM
@pytest.mark.parametrize("age,hb,plt,b2m,igm,score,risk", [
    # no adverse covariate, young  -> Low
    (55, 13.0, 250, 2.0, 20.0, 0, "Low"),
    # one adverse covariate, young -> Low
    (55, 10.0, 250, 2.0, 20.0, 1, "Low"),
    # age > 65 alone -> Intermediate, even though the score is 1
    (70, 13.0, 250, 2.0, 20.0, 1, "Intermediate"),
    # two covariates, young -> Intermediate
    (55, 10.0, 90, 2.0, 20.0, 2, "Intermediate"),
    # three covariates -> High
    (55, 10.0, 90, 4.0, 20.0, 3, "High"),
    # all five -> High
    (80, 9.0, 60, 6.0, 90.0, 5, "High"),
])
def test_ipss_wm_matches_published_definition(age, hb, plt, b2m, igm, score, risk):
    r = ipss_wm(age=age, hb=hb, platelets=plt, beta2m=b2m, igm=igm)
    assert r.score == score
    assert r.risk == risk


def test_ipss_wm_boundaries_are_inclusive_where_published():
    assert ipss_wm(age=65, hb=11.5, platelets=100, beta2m=3.0, igm=70.0).score == 2
    assert ipss_wm(age=66, hb=11.6, platelets=101, beta2m=3.1, igm=70.1).score == 3


def test_ipss_wm_refuses_to_guess_when_data_missing():
    r = ipss_wm(age=70, hb=None, platelets=100, beta2m=3.5, igm=80.0)
    assert r.score is None and r.risk is None
    assert "Haemoglobin ≤ 11.5 g/dL" in r.missing


# --------------------------------------------------------------------------- survival
def test_pfs_runs_from_first_line_and_censors_correctly():
    s = survival(dx_date=date(2020, 1, 1), first_line_start=date(2020, 3, 1),
                 relapse_date=None, death=False, death_date=None,
                 last_followup=date(2022, 3, 1))
    assert s.pfs_event == 0
    assert s.pfs_months == pytest.approx(24.0, abs=0.4)
    assert s.os_event == 0
    assert s.os_months == pytest.approx(26.0, abs=0.4)


def test_pfs_uses_the_earlier_of_progression_and_death():
    s = survival(dx_date=date(2020, 1, 1), first_line_start=date(2020, 1, 1),
                 relapse_date=date(2021, 1, 1), death=True, death_date=date(2021, 6, 1),
                 last_followup=date(2021, 6, 1))
    assert s.pfs_event == 1
    assert s.pfs_months == pytest.approx(12.0, abs=0.4)
    assert s.os_months == pytest.approx(17.0, abs=0.4)


def test_untreated_patient_still_contributes_pfs():
    s = survival(dx_date=date(2021, 1, 1), first_line_start=None, relapse_date=None,
                 death=False, death_date=None, last_followup=date(2023, 1, 1))
    assert s.pfs_months == pytest.approx(24.0, abs=0.4)


# --------------------------------------------------------------------------- Kaplan-Meier
def test_km_against_a_hand_worked_example():
    # 5 patients: events at 6 and 12 months, censoring at 9, 15 and 18
    obs = [(6, 1), (9, 0), (12, 1), (15, 0), (18, 0)]
    km = kaplan_meier(obs)
    assert km.n == 5 and km.events == 2
    # a point is emitted at every observed time, including censoring times, so
    # the curve can carry tick marks
    times = [p.time for p in km.points]
    assert times == [0, 6, 9, 12, 15, 18]
    # S(6) = 1 - 1/5 = 0.8; censoring at 9 does not change S;
    # at t=12 three remain at risk -> 0.8 * (1 - 1/3) = 0.5333
    assert km.points[1].survival == pytest.approx(0.8)
    assert km.points[2].survival == pytest.approx(0.8)
    assert km.points[3].survival == pytest.approx(0.5333, abs=1e-3)


def test_km_median_is_the_first_time_survival_drops_to_half():
    km = kaplan_meier([(5, 1), (10, 1), (15, 1), (20, 1)])
    assert km.median == 10


def test_km_median_is_none_when_not_reached():
    # one event out of five: survival never falls to 0.5
    km = kaplan_meier([(10, 1), (20, 0), (30, 0), (40, 0), (50, 0)])
    assert km.points[-1].survival == pytest.approx(0.8)
    assert km.median is None


def test_logrank_detects_a_clear_difference():
    early = [(m, 1) for m in (2, 3, 4, 5, 6, 7)]
    late = [(m, 1) for m in (40, 45, 50, 55, 60, 65)]
    res = logrank([early, late])
    assert res["p_value"] < 0.01


def test_logrank_finds_nothing_between_identical_groups():
    g = [(m, 1) for m in (10, 20, 30, 40)]
    res = logrank([g, list(g)])
    assert res["p_value"] > 0.5


# --------------------------------------------------------------------------- coercion
def test_date_formats_accepted_from_indian_worksheets():
    assert parse_date("12/03/2021") == date(2021, 3, 12)
    assert parse_date("12-03-2021") == date(2021, 3, 12)
    assert parse_date("2021-03-12") == date(2021, 3, 12)
    assert parse_date(44267) == date(2021, 3, 12)          # Excel serial


def test_impossible_calendar_date_is_rejected():
    with pytest.raises(ValueError):
        parse_date("31/02/2020")


def test_yes_no_variants():
    f = FIELD_BY_KEY["fever"]
    for word in ("Yes", "y", "YES", "1", "true", "Present"):
        assert coerce(f, word).value is True
    for word in ("No", "n", "0", "false", "Absent"):
        assert coerce(f, word).value is False
    assert coerce(f, "maybe").failed


def test_blank_markers_become_null_not_errors():
    f = FIELD_BY_KEY["hb"]
    for word in ("", "NA", "n/a", "not done", "-"):
        res = coerce(f, word)
        assert res.value is None and not res.issues


def test_hard_limit_refuses_and_soft_limit_warns():
    f = FIELD_BY_KEY["tlc"]
    hard = coerce(f, 999)
    assert hard.failed and "maximum" in hard.issues[0].message

    soft = coerce(f, 48.6)
    assert not soft.failed
    assert soft.value == 48.6
    assert soft.issues[0].level == "warning"


def test_enum_matching_is_forgiving_but_explicit():
    f = FIELD_BY_KEY["l1_response"]
    assert coerce(f, "PR").value == "PR — Partial Response"
    assert coerce(f, "partial response").value == "PR — Partial Response"
    unmatched = coerce(f, "excellent")
    assert unmatched.value is None
    assert unmatched.issues[0].level == "warning"     # never silently invented


# --------------------------------------------------------------------------- via the API
def test_derived_values_returned_by_the_api(client, as_deo):
    import uuid
    r = client.post(f"{API}/patients", headers=as_deo,
                    json={"crno": f"CALC/{uuid.uuid4().hex[:8]}", "age": 70,
                          "gender": "Male", "dx_date": "2020-01-06"})
    pid = r.json()["id"]
    client.patch(f"{API}/patients/{pid}", headers=as_deo,
                 json={"hb": 10.2, "platelets": 90, "beta2m": 4.5, "igm": 82.0,
                       "ldh": 320, "kappa_flc": 400.0, "lambda_flc": 8.0,
                       "death": False, "relapse": False, "last_followup_date": "2024-01-06"})
    d = client.get(f"{API}/patients/{pid}", headers=as_deo).json()["derived"]
    assert d["ipss_score"] == 5 and d["ipss_risk"] == "High"
    assert d["elevated_ldh"] == "Yes"          # 320 > 250 U/L
    assert d["igm_above_threshold"] == "Yes"   # 82 > 7.5 g/L
    assert d["sflc_ratio"] == 50.0             # 400 / 8
    assert d["dx_year"] == 2020
    assert d["os_months"] == pytest.approx(48.0, abs=0.5)
    assert d["os_event"] == 0


def test_derived_values_cannot_be_supplied_by_a_client(client, as_deo):
    import uuid
    r = client.post(f"{API}/patients", headers=as_deo,
                    json={"crno": f"SPOOF/{uuid.uuid4().hex[:8]}"})
    pid = r.json()["id"]
    r = client.patch(f"{API}/patients/{pid}", headers=as_deo,
                     json={"ipss_risk": "Low", "os_months": 999})
    assert r.status_code == 422, "the API accepted a client-supplied derived value"
