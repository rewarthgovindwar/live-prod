"""Authentication hardening, data queries and analytics scoping."""
import uuid

import pytest

from app.core.config import settings

API = settings.API_PREFIX
SEED_PASSWORD = "ChangeMe#2026Registry"


# --------------------------------------------------------------------------- auth
def test_unauthenticated_requests_are_refused(client):
    for path in ("/patients", "/analytics/summary", "/exports/patients.csv", "/audit"):
        assert client.get(f"{API}{path}").status_code == 401


def test_wrong_password_and_unknown_email_are_indistinguishable(client):
    a = client.post(f"{API}/auth/login",
                    json={"email": "deo.pgimer@example.org", "password": "wrong-password-x"})
    b = client.post(f"{API}/auth/login",
                    json={"email": "nobody@example.org", "password": "wrong-password-x"})
    assert a.status_code == b.status_code == 401
    assert a.json()["detail"] == b.json()["detail"]


def test_garbage_token_is_refused(client):
    r = client.get(f"{API}/patients", headers={"Authorization": "Bearer not.a.token"})
    assert r.status_code == 401


def test_refresh_rotates_and_revokes(client):
    r = client.post(f"{API}/auth/login",
                    json={"email": "deo.cmc@example.org", "password": SEED_PASSWORD})
    refresh = r.json()["refresh_token"]
    r2 = client.post(f"{API}/auth/refresh", json={"refresh_token": refresh})
    assert r2.status_code == 200
    assert r2.json()["refresh_token"] != refresh
    # the original token is now dead
    assert client.post(f"{API}/auth/refresh", json={"refresh_token": refresh}).status_code == 401


def test_me_returns_the_signed_in_identity(client, as_deo):
    r = client.get(f"{API}/auth/me", headers=as_deo)
    assert r.status_code == 200
    body = r.json()
    assert body["role"] == "DEO"
    assert body["centre"]["code"] == "AHC-02"


def test_weak_password_is_rejected(client, as_deo):
    r = client.post(f"{API}/auth/change-password", headers=as_deo,
                    json={"current_password": SEED_PASSWORD, "new_password": "password1234"})
    assert r.status_code == 422
    assert "upper-case" in str(r.json()).lower() or "symbol" in str(r.json()).lower()


def test_2fa_enrolment_round_trip(client, as_hod):
    import pyotp
    r = client.post(f"{API}/auth/2fa/enrol", headers=as_hod)
    if r.status_code == 409:
        pytest.skip("already enrolled")
    assert r.status_code == 200
    secret = r.json()["secret"]
    assert r.json()["otpauth_uri"].startswith("otpauth://totp/")
    assert client.post(f"{API}/auth/2fa/confirm", headers=as_hod,
                       json={"code": "000000"}).status_code == 400
    good = pyotp.TOTP(secret).now()
    assert client.post(f"{API}/auth/2fa/confirm", headers=as_hod,
                       json={"code": good}).status_code == 204
    # sign-in now demands the code
    assert client.post(f"{API}/auth/login",
                       json={"email": "hod.pgimer@example.org",
                             "password": SEED_PASSWORD}).status_code == 401
    try:
        assert client.post(f"{API}/auth/login",
                           json={"email": "hod.pgimer@example.org", "password": SEED_PASSWORD,
                                 "totp_code": pyotp.TOTP(secret).now()}).status_code == 200
    finally:
        # always tidy up, so a failure here cannot lock later tests out
        client.post(f"{API}/auth/2fa/disable", headers=as_hod,
                    json={"code": pyotp.TOTP(secret).now()})


# --------------------------------------------------------------------------- queries
def _submitted_patient(client, as_deo, as_clin):
    from tests.test_workflow import _complete, _new_patient
    p = _new_patient(client, as_deo)
    _complete(client, as_deo, p["id"])
    client.post(f"{API}/patients/{p['id']}/transition", headers=as_deo, json={"to": "SUBMITTED"})
    client.post(f"{API}/patients/{p['id']}/transition", headers=as_clin, json={"to": "VERIFIED"})
    return p["id"]


def test_national_query_travels_to_the_centre(client, as_deo, as_clin, as_national):
    pid = _submitted_patient(client, as_deo, as_clin)
    r = client.post(f"{API}/queries", headers=as_national,
                    json={"patient_id": pid, "field_key": "beta2m",
                          "query_text": "Beta-2 microglobulin looks inconsistent with creatinine."})
    assert r.status_code == 201, r.text
    q = r.json()
    assert q["query_no"].startswith("Q-")
    assert q["field_label"] == "Beta2 MG"

    # the centre can see it
    mine = client.get(f"{API}/queries?status=OPEN", headers=as_deo).json()
    assert any(x["id"] == q["id"] for x in mine)

    # the raiser cannot close it — only the owning centre can
    assert client.post(f"{API}/queries/{q['id']}/resolve", headers=as_national,
                       json={"resolution_note": "ok"}).status_code == 403
    r = client.post(f"{API}/queries/{q['id']}/resolve", headers=as_deo,
                    json={"resolution_note": "Checked against the laboratory report."})
    assert r.status_code == 200 and r.json()["status"] == "RESOLVED"


def test_deo_cannot_raise_a_query(client, as_deo, as_clin):
    pid = _submitted_patient(client, as_deo, as_clin)
    r = client.post(f"{API}/queries", headers=as_deo,
                    json={"patient_id": pid, "query_text": "please check this value"})
    assert r.status_code == 403


def test_query_on_a_foreign_record_is_404(client, as_clin, foreign_patient_id):
    r = client.post(f"{API}/queries", headers=as_clin,
                    json={"patient_id": foreign_patient_id, "query_text": "check this please"})
    assert r.status_code == 404


# --------------------------------------------------------------------------- analytics
def test_centre_analytics_cover_only_that_centre(client, as_hod, as_national):
    mine = client.get(f"{API}/analytics/summary", headers=as_hod).json()
    pooled = client.get(f"{API}/analytics/summary", headers=as_national).json()
    # the centre view is drawn from exactly one centre...
    assert mine["centres_contributing"] == 1
    assert mine["scope"] == "AHC-02"
    # ...while the pooled view spans every centre that has released records
    assert pooled["centres_contributing"] >= 6
    assert pooled["scope"] == "national_pool"


def test_deo_cannot_see_analytics(client, as_deo):
    assert client.get(f"{API}/analytics/summary", headers=as_deo).status_code == 403


def test_centre_scorecard_is_national_only(client, as_hod, as_national):
    assert client.get(f"{API}/analytics/centres", headers=as_hod).status_code == 403
    r = client.get(f"{API}/analytics/centres", headers=as_national)
    assert r.status_code == 200
    assert len(r.json()["centres"]) >= 6
    # aggregates only — no patient-level identifier anywhere in the payload
    assert "registry_id" not in r.text and "crno" not in r.text


def test_survival_endpoint_returns_curves_and_a_test(client, as_national):
    r = client.get(f"{API}/analytics/survival?endpoint=os&stratify=ipss_risk",
                   headers=as_national)
    assert r.status_code == 200
    body = r.json()
    assert body["curves"]
    for c in body["curves"]:
        assert c["points"][0]["s"] == 1.0
        assert all(0 <= p["s"] <= 1 for p in c["points"])
    if len(body["curves"]) > 1:
        assert body["logrank"] is not None and 0 <= body["logrank"]["p_value"] <= 1


def test_followup_due_lists_living_patients_by_gap(client, as_deo):
    r = client.get(f"{API}/analytics/followup-due", headers=as_deo)
    assert r.status_code == 200
    items = r.json()["items"]
    gaps = [i["months_since"] for i in items]
    assert gaps == sorted(gaps, reverse=True)


# --------------------------------------------------------------------------- metadata
def test_dictionary_covers_all_65_worksheet_columns(client, as_deo):
    d = client.get(f"{API}/meta/dictionary", headers=as_deo).json()
    cols = [f["column"] for f in d["patient"] if f["column"]]
    assert len(cols) == 65
    assert len(set(cols)) == 65


def test_permission_matrix_is_published(client, as_deo):
    r = client.get(f"{API}/meta/roles", headers=as_deo).json()
    assert r["roles"]["IMAGE"]["scope"] == "all_centres"
    assert r["roles"]["DEO"]["scope"] == "own_centre"
    assert "edit_baseline" not in r["roles"]["IMAGE"]["permissions"]
    assert "edit_followup" in r["roles"]["DEO"]["permissions"]


def test_health_endpoint(client):
    r = client.get("/health")
    assert r.status_code == 200 and r.json()["database"] is True
