import os
import uuid

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select, text

from app.core.config import settings
from app.db import SessionLocal, set_rls_context
from app.main import app
from app.models import Centre, Patient, User

API = settings.API_PREFIX
SEED_PASSWORD = "ChangeMe#2026Registry"

ACCOUNTS = {
    "deo": "deo.pgimer@example.org",            # AHC-02
    "clin": "clinician.pgimer@example.org",     # AHC-02
    "hod": "hod.pgimer@example.org",            # AHC-02
    "deo_other": "deo.cmc@example.org",         # AHC-04
    "national": "coordinator@imagesociety.co.in",
}


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c


def _token(client, email: str) -> str:
    r = client.post(f"{API}/auth/login", json={"email": email, "password": SEED_PASSWORD})
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


@pytest.fixture(scope="session", autouse=True)
def reset_accounts():
    """Make the suite repeatable: clear any second factor or lockout left behind
    by an earlier run before tokens are issued."""
    s = SessionLocal()
    set_rls_context(s, user_id=None, centre_id=None, national=True)
    try:
        for u in s.execute(select(User).where(User.email.in_(list(ACCOUNTS.values())))).scalars():
            u.totp_enabled = False
            u.totp_secret = None
            u.failed_logins = 0
            u.locked_until = None
            u.is_active = True
        s.commit()
    finally:
        s.close()


@pytest.fixture(scope="session")
def tokens(client, reset_accounts):
    return {k: _token(client, e) for k, e in ACCOUNTS.items()}


@pytest.fixture
def as_deo(tokens):
    return {"Authorization": f"Bearer {tokens['deo']}"}


@pytest.fixture
def as_clin(tokens):
    return {"Authorization": f"Bearer {tokens['clin']}"}


@pytest.fixture
def as_hod(tokens):
    return {"Authorization": f"Bearer {tokens['hod']}"}


@pytest.fixture
def as_other_centre(tokens):
    return {"Authorization": f"Bearer {tokens['deo_other']}"}


@pytest.fixture
def as_national(tokens):
    return {"Authorization": f"Bearer {tokens['national']}"}


@pytest.fixture
def db():
    s = SessionLocal()
    set_rls_context(s, user_id=None, centre_id=None, national=True)
    try:
        yield s
    finally:
        s.rollback()
        s.close()


@pytest.fixture
def centre_ids(db):
    return {c.code: c.id for c in db.execute(select(Centre)).scalars()}


@pytest.fixture
def foreign_patient_id(db, centre_ids):
    """A record belonging to AHC-03, which nobody in AHC-02 may see."""
    p = db.execute(select(Patient).where(Patient.centre_id == centre_ids["AHC-03"])).scalars().first()
    assert p is not None
    return str(p.id)
