"""Record lifecycle, role permissions and the follow-up-after-lock rule."""
import uuid
from datetime import date, timedelta

import pytest
from sqlalchemy import select

from app.core.config import settings
from app.models import Patient

API = settings.API_PREFIX


def _new_patient(client, headers, crno=None):
    crno = crno or f"TEST/{uuid.uuid4().hex[:10]}"
    r = client.post(f"{API}/patients", headers=headers,
                    json={"crno": crno, "age": 68, "gender": "Male", "dx_date": "2021-03-12"})
    assert r.status_code == 201, r.text
    return r.json()


def _complete(client, headers, pid):
    """Fill in every mandatory field so the record becomes submittable."""
    body = {
        "sym_anaemia": True, "fever": False, "bleeding": False, "hyperviscosity": True,
        "constitutional": True, "igm_symptoms": False, "lymphadenopathy": True,
        "splenomegaly": False,
        "hb": 9.4, "tlc": 6.2, "alc": 3.1, "platelets": 88,
        "srsm_score": "Intermediate", "hiv": "Negative", "hbsag": "Negative",
        "anti_hcv": "Negative", "sife": "IgM Kappa", "igm": 62.0, "beta2m": 5.2,
        "bm_lpl_pct": 55, "relapse": False, "death": False,
        "last_followup_date": "2026-06-01",
    }
    r = client.patch(f"{API}/patients/{pid}", headers=headers, json=body)
    assert r.status_code == 200, r.text
    r = client.post(f"{API}/patients/{pid}/therapy-lines", headers=headers,
                    json={"category": "Chemo-immunotherapy",
                          "regimen": "DRC (Dexamethasone–Rituximab–Cyclophosphamide)",
                          "cycles": 6, "start_date": "2021-05-15", "end_date": "2021-11-15",
                          "best_response": "PR — Partial Response"})
    assert r.status_code == 201, r.text
    return r.json()


def test_create_stamps_the_users_own_centre(client, as_deo):
    p = _new_patient(client, as_deo)
    assert p["centre"]["code"] == "AHC-02"
    assert p["status"] == "DRAFT"
    assert p["registry_id"].startswith("WM")


def test_duplicate_crno_in_same_centre_is_rejected(client, as_deo):
    crno = f"TEST/{uuid.uuid4().hex[:10]}"
    _new_patient(client, as_deo, crno)
    r = client.post(f"{API}/patients", headers=as_deo, json={"crno": crno})
    assert r.status_code == 409


def test_same_crno_allowed_in_different_centres(client, as_deo, as_other_centre):
    crno = f"SHARED/{uuid.uuid4().hex[:8]}"
    _new_patient(client, as_deo, crno)
    r = client.post(f"{API}/patients", headers=as_other_centre, json={"crno": crno})
    assert r.status_code == 201, "two centres must be able to use the same local number"


def test_submission_blocked_until_mandatory_fields_present(client, as_deo):
    p = _new_patient(client, as_deo)
    r = client.post(f"{API}/patients/{p['id']}/transition", headers=as_deo,
                    json={"to": "SUBMITTED"})
    assert r.status_code == 422
    assert "missing" in str(r.json()).lower()


def test_full_lifecycle_deo_clinician_hod(client, as_deo, as_clin, as_hod):
    p = _new_patient(client, as_deo)
    pid = p["id"]
    _complete(client, as_deo, pid)

    # DEO submits
    r = client.post(f"{API}/patients/{pid}/transition", headers=as_deo, json={"to": "SUBMITTED"})
    assert r.status_code == 200 and r.json()["status"] == "SUBMITTED"

    # DEO cannot verify
    assert client.post(f"{API}/patients/{pid}/transition", headers=as_deo,
                       json={"to": "VERIFIED"}).status_code == 403
    # clinician verifies
    r = client.post(f"{API}/patients/{pid}/transition", headers=as_clin, json={"to": "VERIFIED"})
    assert r.status_code == 200 and r.json()["status"] == "VERIFIED"
    # clinician cannot approve
    assert client.post(f"{API}/patients/{pid}/transition", headers=as_clin,
                       json={"to": "APPROVED"}).status_code == 403
    # HoD approves
    r = client.post(f"{API}/patients/{pid}/transition", headers=as_hod, json={"to": "APPROVED"})
    assert r.status_code == 200 and r.json()["status"] == "APPROVED"


def test_illegal_transition_is_refused(client, as_hod):
    p = _new_patient(client, as_hod)
    r = client.post(f"{API}/patients/{p['id']}/transition", headers=as_hod, json={"to": "APPROVED"})
    assert r.status_code == 403


def test_locked_baseline_but_open_followup(client, as_deo, as_clin, as_hod):
    """The rule the study group asked for: HoD approval freezes the baseline,
    while the DEO keeps recording follow-up."""
    p = _new_patient(client, as_deo)
    pid = p["id"]
    _complete(client, as_deo, pid)
    client.post(f"{API}/patients/{pid}/transition", headers=as_deo, json={"to": "SUBMITTED"})
    client.post(f"{API}/patients/{pid}/transition", headers=as_clin, json={"to": "VERIFIED"})
    client.post(f"{API}/patients/{pid}/transition", headers=as_hod, json={"to": "APPROVED"})

    # baseline is frozen for the DEO
    r = client.patch(f"{API}/patients/{pid}", headers=as_deo, json={"hb": 8.1})
    assert r.status_code == 423, r.text

    # follow-up entry still works
    r = client.post(f"{API}/patients/{pid}/visits", headers=as_deo,
                    json={"visit_date": "2026-07-01", "visit_type": "Routine follow-up",
                          "ecog": 1, "hb": 10.2, "disease_status": "PR — Partial Response"})
    assert r.status_code == 201, r.text
    detail = r.json()
    assert detail["workflow"]["followup_amended"] is True
    assert detail["visits"][-1]["added_after_lock"] is True
    assert detail["fields"]["last_followup_date"] == "2026-07-01"

    # a new line of therapy is also follow-up data
    r = client.post(f"{API}/patients/{pid}/therapy-lines", headers=as_deo,
                    json={"category": "BTK inhibitor based therapy", "regimen": "Ibrutinib monotherapy",
                          "start_date": "2026-07-05", "best_response": "PR — Partial Response"})
    assert r.status_code == 201
    assert r.json()["derived"]["btki_ever"] == "Yes"
    assert r.json()["derived"]["total_lines"] == 2

    # the HoD can still unlock for a baseline correction
    r = client.post(f"{API}/patients/{pid}/transition", headers=as_hod, json={"to": "VERIFIED"})
    assert r.status_code == 200
    assert client.patch(f"{API}/patients/{pid}", headers=as_deo, json={"hb": 8.1}).status_code == 200


def test_progression_at_a_visit_sets_relapse(client, as_deo):
    p = _new_patient(client, as_deo)
    pid = p["id"]
    _complete(client, as_deo, pid)
    r = client.post(f"{API}/patients/{pid}/visits", headers=as_deo,
                    json={"visit_date": "2026-02-10", "visit_type": "Suspected progression",
                          "disease_status": "PD — Progressive Disease"})
    assert r.status_code == 201
    assert r.json()["fields"]["relapse"] is True
    assert r.json()["fields"]["relapse_date"] == "2026-02-10"


def test_national_role_cannot_create_or_edit(client, as_national):
    r = client.post(f"{API}/patients", headers=as_national, json={"crno": "X/1"})
    assert r.status_code == 403
    listing = client.get(f"{API}/patients?limit=1", headers=as_national).json()["items"]
    assert listing
    pid = listing[0]["id"]
    r = client.patch(f"{API}/patients/{pid}", headers=as_national, json={"hb": 9.0})
    assert r.status_code == 403
    assert "cannot modify" in r.json()["detail"].lower()


def test_national_sees_only_pooled_records(client, as_national):
    rows = client.get(f"{API}/patients?limit=500", headers=as_national).json()["items"]
    assert rows
    assert {r["status"] for r in rows} <= {"VERIFIED", "APPROVED"}
    assert all(r["crno"] is None for r in rows), "hospital numbers must not leave the centre"


def test_optimistic_locking(client, as_deo):
    p = _new_patient(client, as_deo)
    pid, version = p["id"], p["version"]
    assert client.patch(f"{API}/patients/{pid}", headers=as_deo,
                        json={"hb": 10.0, "version": version}).status_code == 200
    # the stale version is now refused
    r = client.patch(f"{API}/patients/{pid}", headers=as_deo,
                     json={"hb": 11.0, "version": version})
    assert r.status_code == 409


def test_only_drafts_can_be_deleted(client, as_deo, as_clin):
    p = _new_patient(client, as_deo)
    pid = p["id"]
    _complete(client, as_deo, pid)
    client.post(f"{API}/patients/{pid}/transition", headers=as_deo, json={"to": "SUBMITTED"})
    assert client.delete(f"{API}/patients/{pid}", headers=as_deo).status_code == 409
    client.post(f"{API}/patients/{pid}/transition", headers=as_clin, json={"to": "DRAFT"})
    assert client.delete(f"{API}/patients/{pid}", headers=as_deo).status_code == 204
