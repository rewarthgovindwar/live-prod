"""Bulk import of a centre's worksheet, and export in worksheet column order."""
import csv
import io
import json
import uuid
from datetime import date

from openpyxl import Workbook, load_workbook

from app.core.config import settings
from app.services.dictionary import WORKSHEET_ORDER

API = settings.API_PREFIX

HEADERS = [
    "S No", "AHC", "CR No", "Age", "Gender", "Date of diagnosis", "Hb", "TLC", "ALC",
    "Platelet", "Beta2 MG", "IgM level", "Symptoms of anemia", "Fever", "Bleeding",
    "Hyperviscosity", "Constitutional symptoms", "IgM related symp (except hyperviscosity)",
    "lymphadenopathy", "Splenomegaly", "SIFE", "Bone marrow LPL cell %", "MYD 88",
    "SRSM WM score", "HIV", "HBsAG", "Anti HCV", "First Line therapy category",
    "First Line therapy (exact regimen)", "Number of cycles of therapy",
    "First therapy start date", "First therapy End date",
    "Response to First line therapy (as per IWMF)", "Relapse/Progression", "Death",
    "Last Follow up date", "Local remarks",
]


def _row(crno, **over):
    base = ["1", "AHC-99", crno, "67", "M", "12/03/2021", "9.4", "6.2", "3.1", "88",
            "5.2", "62", "yes", "N", "N", "Y", "Y", "N", "Y", "N", "IgM Kappa", "55",
            "Positive", "Intermediate", "Negative", "Negative", "Negative",
            "Chemo-immunotherapy", "DRC", "6", "15/05/2021", "15/11/2021", "PR",
            "No", "No", "01/06/2026", "retrospective"]
    for k, v in over.items():
        base[HEADERS.index(k)] = v
    return base


def _xlsx(rows):
    wb = Workbook()
    ws = wb.active
    ws.title = "WM Data Sheet"
    ws.append(HEADERS)
    for r in rows:
        ws.append(r)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _upload(client, headers, rows, filename="centre_retrospective.xlsx"):
    files = {"file": (filename, _xlsx(rows),
                      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
    r = client.post(f"{API}/imports/preview", headers=headers, files=files)
    assert r.status_code == 200, r.text
    return r.json()


def test_worksheet_headings_map_without_manual_work(client, as_deo):
    p = _upload(client, as_deo, [_row(f"IMP/{uuid.uuid4().hex[:8]}")])
    # every heading except S No, AHC (assigned by the registry) and the centre's
    # own extra column should be recognised
    assert len(p["mapping"]) >= len(HEADERS) - 4
    assert "Local remarks" in p["unmapped_columns"]
    assert p["unmapped_required_fields"] == []


def test_preview_writes_nothing(client, as_deo):
    before = client.get(f"{API}/patients?limit=500", headers=as_deo).json()["total"]
    _upload(client, as_deo, [_row(f"IMP/{uuid.uuid4().hex[:8]}")])
    after = client.get(f"{API}/patients?limit=500", headers=as_deo).json()["total"]
    assert before == after


def test_validation_classifies_each_row(client, as_deo):
    good = _row(f"IMP/{uuid.uuid4().hex[:8]}")
    warn = _row(f"IMP/{uuid.uuid4().hex[:8]}", **{"Beta2 MG": "9.9"})
    bad_date = _row(f"IMP/{uuid.uuid4().hex[:8]}", **{"Date of diagnosis": "31/02/2020"})
    no_id = _row("")
    dup = _row(good[HEADERS.index("CR No")])

    p = _upload(client, as_deo, [good, warn, bad_date, no_id, dup])
    verdicts = {r["row"]: r["verdict"] for r in p["rows"]}
    assert verdicts[2] == "ok"
    assert verdicts[3] == "warning"
    assert verdicts[4] == "error"
    assert verdicts[5] == "rejected"
    assert verdicts[6] == "duplicate"

    bad = next(r for r in p["rows"] if r["row"] == 4)
    assert any("calendar" in i["message"] or "date" in i["message"] for i in bad["issues"])


def test_commit_creates_drafts_in_the_callers_centre(client, as_deo):
    crno = f"IMP/{uuid.uuid4().hex[:8]}"
    p = _upload(client, as_deo, [_row(crno)])
    r = client.post(f"{API}/imports/commit", headers=as_deo, json={"batch_id": p["batch_id"]})
    assert r.status_code == 200, r.text
    res = r.json()
    assert res["imported"] == 1

    listing = client.get(f"{API}/patients?q={crno}", headers=as_deo).json()["items"]
    assert len(listing) == 1
    pid = listing[0]["id"]
    detail = client.get(f"{API}/patients/{pid}", headers=as_deo).json()

    assert detail["status"] == "DRAFT"
    assert detail["centre"]["code"] == "AHC-02", "the AHC column in the file must be ignored"
    assert detail["fields"]["age"] == 67
    assert detail["fields"]["sym_anaemia"] is True
    assert detail["fields"]["hyperviscosity"] is True
    assert detail["fields"]["dx_date"] == "2021-03-12"
    # the flat first-line columns became a proper therapy line
    assert detail["derived"]["total_lines"] == 1
    assert detail["derived"]["l1_regimen"].startswith("DRC")
    assert detail["derived"]["l1_response"] == "PR — Partial Response"
    assert detail["derived"]["ipss_risk"] in ("Low", "Intermediate", "High")
    assert detail["workflow"]["imported"] is True


def test_duplicate_row_is_not_imported_twice(client, as_deo):
    crno = f"IMP/{uuid.uuid4().hex[:8]}"
    p = _upload(client, as_deo, [_row(crno), _row(crno)])
    r = client.post(f"{API}/imports/commit", headers=as_deo, json={"batch_id": p["batch_id"]})
    assert r.json()["imported"] == 1
    assert r.json()["skipped"] == 1


def test_reupload_of_the_same_file_imports_nothing(client, as_deo):
    crno = f"IMP/{uuid.uuid4().hex[:8]}"
    rows = [_row(crno)]
    p1 = _upload(client, as_deo, rows)
    client.post(f"{API}/imports/commit", headers=as_deo, json={"batch_id": p1["batch_id"]})
    p2 = _upload(client, as_deo, rows)
    r = client.post(f"{API}/imports/commit", headers=as_deo, json={"batch_id": p2["batch_id"]})
    assert r.json()["imported"] == 0, "a re-upload created duplicates"


def test_batch_cannot_be_committed_twice(client, as_deo):
    p = _upload(client, as_deo, [_row(f"IMP/{uuid.uuid4().hex[:8]}")])
    client.post(f"{API}/imports/commit", headers=as_deo, json={"batch_id": p["batch_id"]})
    r = client.post(f"{API}/imports/commit", headers=as_deo, json={"batch_id": p["batch_id"]})
    assert r.status_code == 409


def test_national_role_cannot_import(client, as_national):
    files = {"file": ("x.xlsx", _xlsx([_row("N/1")]),
                      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
    assert client.post(f"{API}/imports/preview", headers=as_national, files=files).status_code == 403


def test_template_is_a_readable_workbook(client, as_deo):
    r = client.get(f"{API}/imports/template.xlsx", headers=as_deo)
    assert r.status_code == 200
    wb = load_workbook(io.BytesIO(r.content))
    ws = wb.active
    headings = [c.value for c in ws[1]]
    assert len(headings) == 65
    assert headings[0] == "S No" and headings[-1] == "Last Follow up date"


# --------------------------------------------------------------------------- export
def test_export_reproduces_the_worksheet_column_order(client, as_hod):
    r = client.get(f"{API}/exports/patients.csv", headers=as_hod)
    reader = csv.reader(io.StringIO(r.content.decode("utf-8-sig")))
    headings = next(reader)
    assert len(headings) == 65
    assert headings == [f.label for f in WORKSHEET_ORDER]


def test_analysis_export_adds_survival_variables(client, as_hod):
    r = client.get(f"{API}/exports/patients.csv?analysis=true", headers=as_hod)
    rows = list(csv.DictReader(io.StringIO(r.content.decode("utf-8-sig"))))
    assert rows
    assert "PFS (months)" in rows[0] and "OS event" in rows[0]
    assert len(rows[0]) == 65 + 9


def test_pooled_export_masks_hospital_numbers(client, as_national):
    r = client.get(f"{API}/exports/patients.csv", headers=as_national)
    rows = list(csv.DictReader(io.StringIO(r.content.decode("utf-8-sig"))))
    assert rows
    for row in rows:
        assert row["CR No"].startswith("WM"), "a hospital number leaked into the pooled export"


def test_visit_and_line_exports(client, as_hod):
    for path in ("visits.csv", "therapy-lines.csv"):
        r = client.get(f"{API}/exports/{path}", headers=as_hod)
        assert r.status_code == 200
        rows = list(csv.DictReader(io.StringIO(r.content.decode("utf-8-sig"))))
        assert rows, path
        assert {row["AHC"] for row in rows} == {"AHC-02"}
