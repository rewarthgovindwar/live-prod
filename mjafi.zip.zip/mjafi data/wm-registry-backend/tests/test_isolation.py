"""Centre isolation — the security property the study group asked for.

These tests attack the boundary from several directions: the list endpoint, a
direct record fetch with a known identifier, a write attempt, an export, and
finally raw SQL underneath the application to confirm PostgreSQL row-level
security holds even if an endpoint were written incorrectly.
"""
import csv
import io
import uuid

from sqlalchemy import select, text

from app.core.config import settings
from app.models import Centre, Patient

API = settings.API_PREFIX


def test_list_returns_only_own_centre(client, as_deo):
    r = client.get(f"{API}/patients?limit=500", headers=as_deo)
    assert r.status_code == 200
    codes = {row["centre_code"] for row in r.json()["items"]}
    assert codes == {"AHC-02"}, f"DEO saw other centres: {codes}"


def test_other_centre_deo_sees_a_disjoint_set(client, as_deo, as_other_centre):
    a = {row["registry_id"] for row in client.get(f"{API}/patients?limit=500",
                                                  headers=as_deo).json()["items"]}
    b = {row["registry_id"] for row in client.get(f"{API}/patients?limit=500",
                                                  headers=as_other_centre).json()["items"]}
    assert a and b
    assert a.isdisjoint(b), "two centres saw overlapping records"


def test_direct_fetch_of_foreign_record_is_404(client, as_deo, foreign_patient_id):
    """404 rather than 403: a 403 would confirm the identifier exists."""
    r = client.get(f"{API}/patients/{foreign_patient_id}", headers=as_deo)
    assert r.status_code == 404


def test_write_to_foreign_record_is_refused(client, as_deo, foreign_patient_id):
    r = client.patch(f"{API}/patients/{foreign_patient_id}", headers=as_deo, json={"hb": 9.9})
    assert r.status_code == 404


def test_foreign_centre_filter_is_refused(client, as_deo):
    r = client.get(f"{API}/patients?centre=AHC-03", headers=as_deo)
    assert r.status_code == 403


def test_centre_list_is_scoped(client, as_deo, as_national):
    mine = client.get(f"{API}/meta/centres", headers=as_deo).json()
    assert [c["code"] for c in mine] == ["AHC-02"]
    theirs = client.get(f"{API}/meta/centres", headers=as_national).json()
    assert len(theirs) >= 6


def test_export_contains_only_own_centre(client, as_hod):
    r = client.get(f"{API}/exports/patients.csv", headers=as_hod)
    assert r.status_code == 200
    rows = list(csv.DictReader(io.StringIO(r.content.decode("utf-8-sig"))))
    assert rows
    assert {row["AHC"] for row in rows} == {"AHC-02"}


def test_deo_cannot_export_at_all(client, as_deo):
    assert client.get(f"{API}/exports/patients.csv", headers=as_deo).status_code == 403


def test_audit_trail_is_scoped(client, as_deo):
    r = client.get(f"{API}/audit?limit=200", headers=as_deo)
    assert r.status_code == 200
    centres = {row["centre"] for row in r.json()["items"] if row["centre"]}
    assert centres <= {"AHC-02"}


# --------------------------------------------------------------------------- database layer
def test_row_level_security_blocks_wrong_centre(db, centre_ids):
    """Bypass the application entirely: with AHC-02's context set, a plain
    SELECT for AHC-03's rows must come back empty."""
    db.execute(text("SELECT set_config('app.national','off',true)"))
    db.execute(text("SELECT set_config('app.centre_id', :c, true)"),
               {"c": str(centre_ids["AHC-02"])})
    n = db.execute(text("SELECT count(*) FROM patients WHERE centre_id = :c"),
                   {"c": str(centre_ids["AHC-03"])}).scalar_one()
    assert n == 0, "row-level security did not hide another centre's rows"

    own = db.execute(text("SELECT count(*) FROM patients")).scalar_one()
    assert own > 0, "row-level security hid the centre's own rows"


def test_row_level_security_blocks_child_tables(db, centre_ids):
    db.execute(text("SELECT set_config('app.national','off',true)"))
    db.execute(text("SELECT set_config('app.centre_id', :c, true)"),
               {"c": str(centre_ids["AHC-02"])})
    for table in ("therapy_lines", "followup_visits"):
        n = db.execute(text(f"SELECT count(*) FROM {table} WHERE centre_id = :c"),
                       {"c": str(centre_ids["AHC-03"])}).scalar_one()
        assert n == 0, f"{table} leaked across centres"


def test_national_context_cannot_write(db, centre_ids):
    """The national role may read the pool but the write policy excludes it."""
    db.execute(text("SELECT set_config('app.national','on',true)"))
    db.execute(text("SELECT set_config('app.centre_id','',true)"))
    pid = db.execute(text("SELECT id FROM patients LIMIT 1")).scalar_one()
    res = db.execute(text("UPDATE patients SET hb = 9.1 WHERE id = :i"), {"i": pid})
    assert res.rowcount == 0, "the national context was able to write to a centre's row"
    db.rollback()
