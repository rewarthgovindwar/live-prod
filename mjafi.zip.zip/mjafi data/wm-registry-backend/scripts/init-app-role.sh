#!/bin/sh
# Runs once, on first start of an empty database volume.
#
# Creates the UNPRIVILEGED application role. The API connects as this role so
# that PostgreSQL row-level security actually applies to it; migrations connect
# as the owner role instead.
set -e
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<SQL
DO \$\$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '${POSTGRES_APP_USER:-wm_app}') THEN
    CREATE ROLE ${POSTGRES_APP_USER:-wm_app} LOGIN PASSWORD '${POSTGRES_APP_PASSWORD}';
  ELSE
    ALTER ROLE ${POSTGRES_APP_USER:-wm_app} WITH PASSWORD '${POSTGRES_APP_PASSWORD}';
  END IF;
END
\$\$;
GRANT CONNECT ON DATABASE ${POSTGRES_DB} TO ${POSTGRES_APP_USER:-wm_app};
GRANT USAGE ON SCHEMA public TO ${POSTGRES_APP_USER:-wm_app};
-- Objects created later by the migration inherit these defaults.
ALTER DEFAULT PRIVILEGES FOR ROLE ${POSTGRES_USER} IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO ${POSTGRES_APP_USER:-wm_app};
ALTER DEFAULT PRIVILEGES FOR ROLE ${POSTGRES_USER} IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO ${POSTGRES_APP_USER:-wm_app};
CREATE EXTENSION IF NOT EXISTS pgcrypto;
SQL
