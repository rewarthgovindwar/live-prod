"""Seed the registry with participating centres, accounts and (optionally) a
synthetic dataset for demonstration and load testing.

    python -m scripts.seed --demo          # centres + users + synthetic patients
    python -m scripts.seed                 # centres + users only (use for a real install)

Synthetic patients are clearly flagged: every CR number begins with "DEMO/".
Never run --demo against a production database.
"""
from __future__ import annotations

import argparse
import random
import sys
from datetime import date, timedelta

from sqlalchemy import select, text

from app.core.security import hash_password
from app.db import SessionLocal, set_rls_context
from app.models import Centre, FollowupVisit, Patient, TherapyLine, User
from app.services.dictionary import (DEATH_CAUSE, REGIMENS, RESPONSE, SIFE, SRSM,
                                     STOP_REASON, VISIT_TYPE)

TODAY = date(2026, 8, 14)

CENTRES = [
    ("AHC-01", "AIIMS, New Delhi", "New Delhi", "Delhi", "North"),
    ("AHC-02", "PGIMER, Chandigarh", "Chandigarh", "Chandigarh", "North"),
    ("AHC-03", "Tata Memorial Hospital, Mumbai", "Mumbai", "Maharashtra", "West"),
    ("AHC-04", "Christian Medical College, Vellore", "Vellore", "Tamil Nadu", "South"),
    ("AHC-05", "NIMS, Hyderabad", "Hyderabad", "Telangana", "South"),
    ("AHC-06", "AFMC / Command Hospital, Pune", "Pune", "Maharashtra", "West"),
]

USERS = [
    ("deo.pgimer@example.org", "Ms. Anjali Rao", "Registry Data Entry Operator", "DEO", "AHC-02"),
    ("clinician.pgimer@example.org", "Dr. Rohit Menon",
     "Assistant Professor, Clinical Haematology", "CLIN", "AHC-02"),
    ("hod.pgimer@example.org", "Prof. S. Venkatesan",
     "Head, Department of Clinical Haematology", "HOD", "AHC-02"),
    ("deo.cmc@example.org", "Ms. Fatima Sheikh", "Registry Data Entry Operator", "DEO", "AHC-04"),
    ("coordinator@imagesociety.co.in", "Col (Dr) Uday Y.",
     "National Coordinator, IMAGe WM Study Group", "IMAGE", None),
]

DEFAULT_PASSWORD = "ChangeMe#2026Registry"


def months_after(d: date, m: float) -> date:
    return d + timedelta(days=int(round(m * 30.4375)))


def seed_reference(db) -> dict[str, Centre]:
    centres: dict[str, Centre] = {}
    for code, name, city, state, zone in CENTRES:
        c = db.execute(select(Centre).where(Centre.code == code)).scalar_one_or_none()
        if c is None:
            c = Centre(code=code, name=name, city=city, state=state, zone=zone)
            db.add(c)
            db.flush()
        centres[code] = c

    for email, name, desig, role, centre_code in USERS:
        u = db.execute(select(User).where(User.email == email)).scalar_one_or_none()
        if u is None:
            db.add(User(email=email, full_name=name, designation=desig, role=role,
                        centre_id=centres[centre_code].id if centre_code else None,
                        password_hash=hash_password(DEFAULT_PASSWORD),
                        must_change_password=True))
    db.flush()
    return centres


def seed_demo(db, centres: dict[str, Centre], rng: random.Random) -> int:
    counts = {"AHC-01": 11, "AHC-02": 14, "AHC-03": 9, "AHC-04": 8, "AHC-05": 6, "AHC-06": 5}
    deo = {c: db.execute(select(User).where(User.centre_id == centres[c].id)).scalars().first()
           for c in centres}
    created = 0

    for code, centre in centres.items():
        n = counts.get(code, 6)
        # each centre is written inside its own row-level-security context
        set_rls_context(db, user_id=None, centre_id=str(centre.id), national=False)
        for i in range(n):
            no = db.execute(text("SELECT nextval('registry_no_seq')")).scalar_one()
            male = rng.random() < 0.68
            age = rng.choice([rng.randint(40, 55), rng.randint(56, 65),
                              rng.randint(66, 74), rng.randint(75, 86)])
            dx = date(rng.randint(2016, 2024), rng.randint(1, 12), rng.randint(1, 28))
            igm = round(rng.choice([rng.uniform(3, 7.4), rng.uniform(7.6, 25),
                                    rng.uniform(25, 60), rng.uniform(60, 105)]), 1)
            hb = round(rng.choice([rng.uniform(5, 8.4), rng.uniform(8.5, 11.5),
                                   rng.uniform(11.6, 14.5)]), 1)
            plt = round(rng.choice([rng.uniform(20, 99), rng.uniform(100, 180),
                                    rng.uniform(181, 340)]))
            b2m = round(rng.choice([rng.uniform(1.2, 3), rng.uniform(3.1, 6),
                                    rng.uniform(6.1, 16)]), 2)
            kappa_clone = rng.random() < 0.62

            p = Patient(
                registry_no=no, registry_id=f"WM{no:04d}", centre_id=centre.id,
                crno=f"DEMO/{code[-2:]}/{dx.year}/{rng.randint(100, 9999):04d}",
                age=age, gender="Male" if male else "Female", dx_date=dx,
                sym_anaemia=hb < 11, fever=rng.random() < 0.22, bleeding=rng.random() < 0.18,
                hyperviscosity=(rng.random() < 0.55) if igm > 40 else (rng.random() < 0.12),
                constitutional=rng.random() < 0.46, igm_symptoms=rng.random() < 0.30,
                lymphadenopathy=rng.random() < 0.42, splenomegaly=rng.random() < 0.34,
                ecog_dx=rng.choice([0, 1, 1, 2, 2, 3]),
                hb=hb, tlc=round(rng.uniform(2.4, 16), 2), alc=round(rng.uniform(0.8, 9), 2),
                platelets=plt, calcium=round(rng.uniform(8.2, 10.6), 1),
                urea=round(rng.uniform(16, 72)), creatinine=round(rng.uniform(0.6, 2.2), 2),
                total_protein=round(rng.uniform(6.4, 12.5), 1),
                albumin=round(rng.uniform(2.8, 4.6), 1),
                ldh=round(rng.choice([rng.uniform(140, 249), rng.uniform(250, 520)])),
                srsm_score=rng.choice(SRSM),
                hiv="Negative", hbsag="Negative", anti_hcv="Negative",
                anti_hbc="Reactive" if rng.random() < 0.1 else "Negative",
                m_band=round(rng.uniform(0.6, 6.4), 2),
                sife=SIFE[0] if kappa_clone else SIFE[1],
                igm=igm,
                kappa_flc=round(rng.uniform(30, 900) if kappa_clone else rng.uniform(4, 26), 2),
                lambda_flc=round(rng.uniform(3, 22) if kappa_clone else rng.uniform(35, 1100), 2),
                dct=rng.random() < 0.14, amyloid=rng.random() < 0.05,
                cryoglobulins=rng.random() < 0.09, beta2m=b2m,
                pb_lpl=rng.random() < 0.26,
                bm_lpl_pct=round(rng.uniform(10, 95)),
                myd88=rng.choices(["Positive", "Negative", "Not done"], [78, 12, 10])[0],
                bm_date=dx, status="DRAFT",
                created_by=deo[code].id if deo[code] else None,
            )
            db.add(p)
            db.flush()

            # therapy lines
            n_lines = rng.choices([1, 2, 3], [58, 30, 12])[0]
            start = months_after(dx, rng.uniform(0.2, 8))
            if start > TODAY:
                start = months_after(TODAY, -rng.uniform(1, 8))
            last_end = start
            for ln in range(1, n_lines + 1):
                cat = rng.choice(list(REGIMENS))
                dur = rng.uniform(6, 30) if "BTK" in cat else rng.uniform(3, 7)
                end = months_after(start, dur)
                db.add(TherapyLine(
                    patient_id=p.id, centre_id=centre.id, line_no=ln, category=cat,
                    regimen=rng.choice(REGIMENS[cat]),
                    cycles=rng.randint(3, 24) if "BTK" in cat else rng.randint(2, 8),
                    start_date=start, end_date=end if end <= TODAY else None,
                    best_response=rng.choices(RESPONSE[:6], [10, 20, 38, 15, 10, 7])[0],
                    stop_reason=rng.choice(STOP_REASON),
                    grade3_toxicity=rng.random() < 0.24,
                    created_by=deo[code].id if deo[code] else None))
                last_end = min(end, TODAY)
                if ln < n_lines:
                    start = months_after(end, rng.uniform(9, 50))
                    if start > TODAY:
                        break

            if n_lines > 1:
                p.relapse = True
                p.relapse_date = months_after(last_end, -0.5)
            else:
                p.relapse = rng.random() < 0.18
                if p.relapse:
                    rd = months_after(last_end, rng.uniform(6, 36))
                    p.relapse_date = rd if rd <= TODAY else months_after(TODAY, -1)
            p.transformation = bool(p.relapse and rng.random() < 0.07)
            if p.transformation:
                p.transformation_date = p.relapse_date

            adverse = sum([age > 65, hb <= 11.5, plt <= 100, b2m > 3, igm > 70])
            if rng.random() < min(0.02 + adverse * 0.07, 0.55):
                p.death = True
                dd = months_after(last_end, rng.uniform(1, max(6, 44 - adverse * 6)))
                p.death_date = min(dd, months_after(TODAY, -1))
                if p.death_date < dx:
                    p.death_date = months_after(dx, 3)
                p.last_followup_date = p.death_date
                p.death_cause = rng.choice(DEATH_CAUSE)
            else:
                p.death = False
                lf = months_after(last_end, rng.uniform(1, 26))
                p.last_followup_date = min(lf, TODAY)

            # follow-up visits
            v = months_after(dx, 3)
            k = 1
            while v < p.last_followup_date and k <= 12:
                past = p.relapse_date is not None and v >= p.relapse_date
                db.add(FollowupVisit(
                    patient_id=p.id, centre_id=centre.id, visit_date=v,
                    visit_type=rng.choice(VISIT_TYPE[:4]),
                    ecog=rng.choice([0, 1, 1, 2]), on_therapy=rng.random() < 0.4,
                    hb=round(hb + rng.uniform(-0.5, 3.4), 1),
                    tlc=round(rng.uniform(3, 12), 2), alc=round(rng.uniform(0.9, 6), 2),
                    platelets=round(plt + rng.uniform(-40, 120)),
                    creatinine=round(rng.uniform(0.6, 1.9), 2),
                    total_protein=round(rng.uniform(6.2, 9.6), 1),
                    albumin=round(rng.uniform(3, 4.6), 1),
                    igm=round(igm * rng.uniform(0.18, 1.4 if past else 0.75), 1),
                    m_band=round((p.m_band or 1) * rng.uniform(0.15, 1.3 if past else 0.7), 2),
                    beta2m=round(b2m * rng.uniform(0.5, 1.5 if past else 1.05), 2),
                    disease_status=(rng.choices(RESPONSE[:6], [5, 10, 22, 13, 20, 30])[0] if past
                                    else rng.choices(RESPONSE[:5], [12, 22, 36, 13, 17])[0]),
                    transfusion_dependent=rng.random() < 0.15,
                    created_by=deo[code].id if deo[code] else None))
                v = months_after(v, rng.uniform(2.5, 6))
                k += 1
            created += 1
        # commit per centre: the row-level-security context is transaction-scoped,
        # so pending writes must not survive into the next centre's context
        db.commit()

    # spread the demo records across the workflow so every screen has content
    ref = centres.get("AHC-02")
    if ref is None:
        return created
    set_rls_context(db, user_id=None, centre_id=str(ref.id), national=False)
    own = db.execute(select(Patient).where(Patient.centre_id == ref.id)
                     .order_by(Patient.registry_no)).scalars().all()
    for p, st in zip(own, ["DRAFT", "DRAFT", "SUBMITTED", "SUBMITTED", "SUBMITTED",
                           "VERIFIED", "VERIFIED", "APPROVED", "APPROVED", "APPROVED",
                           "APPROVED", "APPROVED", "APPROVED", "APPROVED"]):
        p.status = st
    db.commit()
    for code, centre in centres.items():
        if code == "AHC-02":
            continue
        set_rls_context(db, user_id=None, centre_id=str(centre.id), national=False)
        for p in db.execute(select(Patient).where(Patient.centre_id == centre.id)).scalars():
            p.status = "APPROVED"
        db.commit()
    set_rls_context(db, user_id=None, centre_id=str(ref.id), national=False)
    # one deliberately incomplete draft, to exercise the validation path
    if own:
        own[0].beta2m = own[0].igm = own[0].bm_lpl_pct = None
        own[0].srsm_score = own[0].sife = None
    return created


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true", help="also create synthetic patients")
    ap.add_argument("--seed", type=int, default=20260814)
    args = ap.parse_args()

    rng = random.Random(args.seed)
    db = SessionLocal()
    try:
        # Seeding runs outside the centre context, so RLS must be satisfied by
        # the owner connection or by the national flag.
        set_rls_context(db, user_id=None, centre_id=None, national=True)
        centres = seed_reference(db)
        db.commit()
        print(f"centres: {len(centres)}   users: {len(USERS)}")
        print(f"default password for every seeded account: {DEFAULT_PASSWORD}")
        print("  (each account is forced to change it at first sign-in)")

        if args.demo:
            n = seed_demo(db, centres, rng)
            db.commit()
            print(f"synthetic patients created: {n}")
    finally:
        db.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
