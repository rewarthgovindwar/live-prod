#!/usr/bin/env bash
# Nightly logical backup, kept for 30 days, with a restore test reminder.
#
#   0 2 * * *  /opt/wm-registry/scripts/backup.sh >> /var/log/wm-backup.log 2>&1
set -euo pipefail

STAMP=$(date +%Y%m%d-%H%M)
DIR=${BACKUP_DIR:-/opt/wm-registry/backups}
KEEP_DAYS=${KEEP_DAYS:-30}
mkdir -p "$DIR"

docker compose exec -T db pg_dump \
  --username "${POSTGRES_OWNER:-wm_owner}" \
  --dbname "${POSTGRES_DB:-wm_registry}" \
  --format=custom --compress=9 \
  > "$DIR/wm_registry-$STAMP.dump"

# Verify the dump is readable before trusting it.
docker compose exec -T db pg_restore --list "/backups/wm_registry-$STAMP.dump" > /dev/null \
  || { echo "BACKUP VERIFY FAILED for $STAMP"; exit 1; }

find "$DIR" -name 'wm_registry-*.dump' -mtime +"$KEEP_DAYS" -delete
echo "$(date -Is) backup ok: wm_registry-$STAMP.dump ($(du -h "$DIR/wm_registry-$STAMP.dump" | cut -f1))"

# Restore into a scratch database:
#   docker compose exec -T db createdb -U wm_owner wm_restore_test
#   docker compose exec -T db pg_restore -U wm_owner -d wm_restore_test /backups/<file>.dump
