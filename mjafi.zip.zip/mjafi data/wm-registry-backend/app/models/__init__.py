"""SQLAlchemy ORM models for the IMAGe WM Registry.

Design notes
------------
* Everything a centre owns carries ``centre_id``. That column is the anchor for
  both application-level scoping and PostgreSQL row-level security.
* The flat worksheet's first-line and second-line therapy columns (AV-BB, BE-BF)
  are NOT stored on the patient row. They are derived from ``therapy_lines`` so
  the two can never drift apart. The export layer rebuilds the flat columns.
* Clinical picklists (regimen, response, cause of death ...) are stored as text
  and validated in the application, so the study group can extend a list without
  a database migration. Structural enums (role, workflow status) are native
  PostgreSQL enums because changing them is a deliberate schema decision.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime
from typing import Optional

from sqlalchemy import (
    Boolean, CheckConstraint, Date, DateTime, Enum, Float, ForeignKey, Index,
    Integer, String, Text, UniqueConstraint, func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


def _uuid_pk():
    return mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)


RoleEnum = Enum("DEO", "CLIN", "HOD", "IMAGE", name="user_role", create_type=True)
StatusEnum = Enum("DRAFT", "SUBMITTED", "QUERY", "VERIFIED", "APPROVED",
                  name="record_status", create_type=True)
QueryStatusEnum = Enum("OPEN", "RESOLVED", "CANCELLED", name="query_status", create_type=True)


# ---------------------------------------------------------------------------
# Reference
# ---------------------------------------------------------------------------
class Centre(Base):
    __tablename__ = "centres"

    id: Mapped[uuid.UUID] = _uuid_pk()
    code: Mapped[str] = mapped_column(String(16), unique=True, nullable=False)   # AHC-01
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    city: Mapped[Optional[str]] = mapped_column(String(80))
    state: Mapped[Optional[str]] = mapped_column(String(80))
    zone: Mapped[Optional[str]] = mapped_column(String(40))
    pi_name: Mapped[Optional[str]] = mapped_column(String(160))
    ethics_approval_ref: Mapped[Optional[str]] = mapped_column(String(120))
    ethics_approval_date: Mapped[Optional[date]] = mapped_column(Date)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    users: Mapped[list["User"]] = relationship(back_populates="centre")


class User(Base):
    __tablename__ = "users"

    id: Mapped[uuid.UUID] = _uuid_pk()
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    full_name: Mapped[str] = mapped_column(String(160), nullable=False)
    designation: Mapped[Optional[str]] = mapped_column(String(160))
    role: Mapped[str] = mapped_column(RoleEnum, nullable=False)
    # NULL centre == national scope (IMAGe representative only)
    centre_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("centres.id", ondelete="RESTRICT"), index=True)

    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    must_change_password: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    password_changed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    totp_secret: Mapped[Optional[str]] = mapped_column(String(64))
    totp_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    failed_logins: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    locked_until: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    last_login_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(),
                                                 onupdate=func.now())

    centre: Mapped[Optional[Centre]] = relationship(back_populates="users")

    __table_args__ = (
        # Only the national representative may have no centre.
        CheckConstraint("(role = 'IMAGE') OR (centre_id IS NOT NULL)", name="ck_users_centre_required"),
    )


class RefreshToken(Base):
    __tablename__ = "refresh_tokens"

    id: Mapped[uuid.UUID] = _uuid_pk()
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True),
                                               ForeignKey("users.id", ondelete="CASCADE"), index=True)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)
    issued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    revoked_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    ip: Mapped[Optional[str]] = mapped_column(String(64))
    user_agent: Mapped[Optional[str]] = mapped_column(String(300))


# ---------------------------------------------------------------------------
# Registry core
# ---------------------------------------------------------------------------
class Patient(Base):
    """One row per enrolled patient. Column letters refer to the IMAGe WM worksheet."""

    __tablename__ = "patients"

    id: Mapped[uuid.UUID] = _uuid_pk()
    registry_no: Mapped[int] = mapped_column(Integer, unique=True, nullable=False)      # A  S No
    registry_id: Mapped[str] = mapped_column(String(16), unique=True, nullable=False)   # WM0001
    centre_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("centres.id", ondelete="RESTRICT"),
        nullable=False, index=True)                                                     # B  AHC
    crno: Mapped[str] = mapped_column(String(64), nullable=False)                       # C  CR No

    # --- demographics (D-F) ---
    age: Mapped[Optional[int]] = mapped_column(Integer)
    gender: Mapped[Optional[str]] = mapped_column(String(16))
    dx_date: Mapped[Optional[date]] = mapped_column(Date)

    # --- clinical presentation (H-O) ---
    sym_anaemia: Mapped[Optional[bool]] = mapped_column(Boolean)
    fever: Mapped[Optional[bool]] = mapped_column(Boolean)
    bleeding: Mapped[Optional[bool]] = mapped_column(Boolean)
    hyperviscosity: Mapped[Optional[bool]] = mapped_column(Boolean)
    constitutional: Mapped[Optional[bool]] = mapped_column(Boolean)
    igm_symptoms: Mapped[Optional[bool]] = mapped_column(Boolean)
    lymphadenopathy: Mapped[Optional[bool]] = mapped_column(Boolean)
    splenomegaly: Mapped[Optional[bool]] = mapped_column(Boolean)
    ecog_dx: Mapped[Optional[int]] = mapped_column(Integer)          # registry extension
    clinical_notes: Mapped[Optional[str]] = mapped_column(Text)

    # --- haematology & biochemistry (P-Y) ---
    hb: Mapped[Optional[float]] = mapped_column(Float)
    tlc: Mapped[Optional[float]] = mapped_column(Float)
    alc: Mapped[Optional[float]] = mapped_column(Float)
    platelets: Mapped[Optional[float]] = mapped_column(Float)
    calcium: Mapped[Optional[float]] = mapped_column(Float)
    urea: Mapped[Optional[float]] = mapped_column(Float)
    creatinine: Mapped[Optional[float]] = mapped_column(Float)
    total_protein: Mapped[Optional[float]] = mapped_column(Float)
    albumin: Mapped[Optional[float]] = mapped_column(Float)
    ldh: Mapped[Optional[float]] = mapped_column(Float)
    # Z (elevated LDH) is derived, not stored.

    # --- risk (AA) ---
    srsm_score: Mapped[Optional[str]] = mapped_column(String(32))
    # AT / AU (IPSS-WM score and risk) are derived, not stored.

    # --- serology (AB-AE) ---
    hiv: Mapped[Optional[str]] = mapped_column(String(16))
    hbsag: Mapped[Optional[str]] = mapped_column(String(16))
    anti_hcv: Mapped[Optional[str]] = mapped_column(String(16))
    anti_hbc: Mapped[Optional[str]] = mapped_column(String(16))

    # --- paraprotein & immunoglobulins (AF-AH) ---
    m_band: Mapped[Optional[float]] = mapped_column(Float)
    sife: Mapped[Optional[str]] = mapped_column(String(64))
    igm: Mapped[Optional[float]] = mapped_column(Float)              # g/L
    # AI (IgM > 7.5 g/L) is derived.

    # --- free light chains (AJ-AL) ---
    kappa_flc: Mapped[Optional[float]] = mapped_column(Float)
    lambda_flc: Mapped[Optional[float]] = mapped_column(Float)
    # AL (SFLC ratio) is derived.

    # --- associated phenomena (AM-AP) ---
    dct: Mapped[Optional[bool]] = mapped_column(Boolean)
    amyloid: Mapped[Optional[bool]] = mapped_column(Boolean)
    cryoglobulins: Mapped[Optional[bool]] = mapped_column(Boolean)
    beta2m: Mapped[Optional[float]] = mapped_column(Float)

    # --- marrow & molecular (AQ-AS) ---
    pb_lpl: Mapped[Optional[bool]] = mapped_column(Boolean)
    bm_lpl_pct: Mapped[Optional[float]] = mapped_column(Float)
    myd88: Mapped[Optional[str]] = mapped_column(String(24))
    cxcr4: Mapped[Optional[str]] = mapped_column(String(24))         # registry extension
    bm_date: Mapped[Optional[date]] = mapped_column(Date)            # registry extension

    # --- relapse / progression (BC-BD) ---
    relapse: Mapped[Optional[bool]] = mapped_column(Boolean)
    relapse_date: Mapped[Optional[date]] = mapped_column(Date)
    # BE / BF (2nd line received, 2nd line regimen) are derived from therapy_lines.

    # --- transformation & vital status (BG, BJ-BM) ---
    transformation: Mapped[Optional[bool]] = mapped_column(Boolean)
    transformation_date: Mapped[Optional[date]] = mapped_column(Date)
    death: Mapped[Optional[bool]] = mapped_column(Boolean)
    death_date: Mapped[Optional[date]] = mapped_column(Date)
    death_cause: Mapped[Optional[str]] = mapped_column(String(120))
    last_followup_date: Mapped[Optional[date]] = mapped_column(Date)
    # BH (BTKi ever) and BI (event) are derived.

    # --- workflow ---
    status: Mapped[str] = mapped_column(StatusEnum, nullable=False, server_default="DRAFT", index=True)
    submitted_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    submitted_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    verified_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    verified_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    approved_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    followup_amended: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    followup_amended_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    # --- provenance ---
    import_batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("import_batches.id", ondelete="SET NULL"))
    import_issue_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(),
                                                 onupdate=func.now())
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)   # optimistic locking

    therapy_lines: Mapped[list["TherapyLine"]] = relationship(
        back_populates="patient", cascade="all, delete-orphan",
        order_by="TherapyLine.line_no", lazy="selectin")
    visits: Mapped[list["FollowupVisit"]] = relationship(
        back_populates="patient", cascade="all, delete-orphan",
        order_by="FollowupVisit.visit_date", lazy="selectin")

    __table_args__ = (
        # A hospital number is unique inside its own centre, never globally:
        # two centres may legitimately use the same local number.
        UniqueConstraint("centre_id", "crno", name="uq_patient_centre_crno"),
        CheckConstraint("age IS NULL OR (age BETWEEN 0 AND 120)", name="ck_patient_age"),
        CheckConstraint("hb IS NULL OR (hb BETWEEN 0 AND 30)", name="ck_patient_hb"),
        CheckConstraint("bm_lpl_pct IS NULL OR (bm_lpl_pct BETWEEN 0 AND 100)", name="ck_patient_bmlpl"),
        CheckConstraint("death_date IS NULL OR dx_date IS NULL OR death_date >= dx_date",
                        name="ck_patient_death_after_dx"),
        CheckConstraint("death IS NOT TRUE OR death_date IS NOT NULL", name="ck_patient_death_date"),
        Index("ix_patients_centre_status", "centre_id", "status"),
        Index("ix_patients_dx_date", "dx_date"),
    )


class TherapyLine(Base):
    __tablename__ = "therapy_lines"

    id: Mapped[uuid.UUID] = _uuid_pk()
    patient_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("patients.id", ondelete="CASCADE"), nullable=False, index=True)
    centre_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("centres.id", ondelete="RESTRICT"), nullable=False, index=True)

    line_no: Mapped[int] = mapped_column(Integer, nullable=False)
    category: Mapped[Optional[str]] = mapped_column(String(80))       # AW for line 1
    regimen: Mapped[Optional[str]] = mapped_column(String(200))       # AX for line 1, BF for line 2
    cycles: Mapped[Optional[int]] = mapped_column(Integer)            # AY
    start_date: Mapped[Optional[date]] = mapped_column(Date)          # AZ
    end_date: Mapped[Optional[date]] = mapped_column(Date)            # BA
    best_response: Mapped[Optional[str]] = mapped_column(String(80))  # BB
    stop_reason: Mapped[Optional[str]] = mapped_column(String(120))
    grade3_toxicity: Mapped[Optional[bool]] = mapped_column(Boolean)
    toxicity_detail: Mapped[Optional[str]] = mapped_column(Text)

    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    added_after_lock: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    patient: Mapped[Patient] = relationship(back_populates="therapy_lines")

    __table_args__ = (
        UniqueConstraint("patient_id", "line_no", name="uq_line_patient_no"),
        CheckConstraint("line_no >= 1", name="ck_line_no"),
        CheckConstraint("cycles IS NULL OR (cycles BETWEEN 0 AND 100)", name="ck_line_cycles"),
        CheckConstraint("end_date IS NULL OR start_date IS NULL OR end_date >= start_date",
                        name="ck_line_dates"),
    )


class FollowupVisit(Base):
    __tablename__ = "followup_visits"

    id: Mapped[uuid.UUID] = _uuid_pk()
    patient_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("patients.id", ondelete="CASCADE"), nullable=False, index=True)
    centre_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("centres.id", ondelete="RESTRICT"), nullable=False, index=True)

    visit_date: Mapped[date] = mapped_column(Date, nullable=False)
    visit_type: Mapped[Optional[str]] = mapped_column(String(80))
    ecog: Mapped[Optional[int]] = mapped_column(Integer)
    on_therapy: Mapped[Optional[bool]] = mapped_column(Boolean)

    hb: Mapped[Optional[float]] = mapped_column(Float)
    tlc: Mapped[Optional[float]] = mapped_column(Float)
    alc: Mapped[Optional[float]] = mapped_column(Float)
    platelets: Mapped[Optional[float]] = mapped_column(Float)
    creatinine: Mapped[Optional[float]] = mapped_column(Float)
    total_protein: Mapped[Optional[float]] = mapped_column(Float)
    albumin: Mapped[Optional[float]] = mapped_column(Float)
    igm: Mapped[Optional[float]] = mapped_column(Float)
    m_band: Mapped[Optional[float]] = mapped_column(Float)
    beta2m: Mapped[Optional[float]] = mapped_column(Float)

    disease_status: Mapped[Optional[str]] = mapped_column(String(80))
    transfusion_dependent: Mapped[Optional[bool]] = mapped_column(Boolean)
    new_symptoms: Mapped[Optional[str]] = mapped_column(Text)
    notes: Mapped[Optional[str]] = mapped_column(Text)

    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    added_after_lock: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    patient: Mapped[Patient] = relationship(back_populates="visits")

    __table_args__ = (
        UniqueConstraint("patient_id", "visit_date", name="uq_visit_patient_date"),
        CheckConstraint("ecog IS NULL OR (ecog BETWEEN 0 AND 4)", name="ck_visit_ecog"),
        Index("ix_visits_patient_date", "patient_id", "visit_date"),
    )


class DataQuery(Base):
    __tablename__ = "data_queries"

    id: Mapped[uuid.UUID] = _uuid_pk()
    query_no: Mapped[str] = mapped_column(String(16), unique=True, nullable=False)   # Q-014
    patient_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("patients.id", ondelete="CASCADE"), nullable=False, index=True)
    centre_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("centres.id", ondelete="RESTRICT"), nullable=False, index=True)

    field_key: Mapped[Optional[str]] = mapped_column(String(64))
    query_text: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(QueryStatusEnum, nullable=False, server_default="OPEN", index=True)

    raised_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    raised_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    resolved_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    resolution_note: Mapped[Optional[str]] = mapped_column(Text)


class ImportBatch(Base):
    __tablename__ = "import_batches"

    id: Mapped[uuid.UUID] = _uuid_pk()
    centre_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("centres.id", ondelete="RESTRICT"), nullable=False, index=True)
    filename: Mapped[str] = mapped_column(String(300), nullable=False)
    sheet_name: Mapped[Optional[str]] = mapped_column(String(120))
    uploaded_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    uploaded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    rows_read: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    rows_imported: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    rows_skipped: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    committed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    report: Mapped[dict] = mapped_column(JSONB, default=dict)


class AuditLog(Base):
    """Append-only. No UPDATE or DELETE grant is issued on this table."""

    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), index=True)
    user_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    user_name: Mapped[Optional[str]] = mapped_column(String(160))
    user_role: Mapped[Optional[str]] = mapped_column(String(16))
    centre_code: Mapped[Optional[str]] = mapped_column(String(16), index=True)
    action: Mapped[str] = mapped_column(String(80), nullable=False)
    entity_type: Mapped[Optional[str]] = mapped_column(String(40))
    entity_id: Mapped[Optional[str]] = mapped_column(String(64))
    registry_id: Mapped[Optional[str]] = mapped_column(String(16), index=True)
    ip: Mapped[Optional[str]] = mapped_column(String(64))
    user_agent: Mapped[Optional[str]] = mapped_column(String(300))
    changes: Mapped[Optional[dict]] = mapped_column(JSONB)
    detail: Mapped[Optional[str]] = mapped_column(Text)
