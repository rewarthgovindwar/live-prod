"""Data queries, centre/user administration, audit trail and metadata."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import (client_ip, current_user, get_db, get_patient_or_404, is_national,
                          require, resolve_centre)
from app.core import permissions as P
from app.core.config import settings
from app.core.security import hash_password, validate_password_strength
from app.models import AuditLog, Centre, DataQuery, Patient, User
from app.schemas import (CentreOut, QueryCreate, QueryOut, QueryResolve, UserCreate,
                         UserOut, UserUpdate)
from app.services import dictionary
from app.services.audit import record

router = APIRouter(tags=["administration"])


def _now():
    return datetime.now(timezone.utc)


# ===========================================================================
# Metadata — the front-end builds its forms from these, so client and server
# can never disagree about a range, a picklist or a permission.
# ===========================================================================
meta = APIRouter(prefix="/meta", tags=["metadata"])


@meta.get("/dictionary")
def get_dictionary():
    return dictionary.as_dict()


@meta.get("/roles")
def get_roles():
    return P.as_dict()


@meta.get("/centres", response_model=list[CentreOut])
def list_centres(db: Session = Depends(get_db), user: User = Depends(current_user)):
    """Centre staff see only their own centre in this list."""
    stmt = select(Centre).where(Centre.is_active.is_(True)).order_by(Centre.code)
    if not is_national(user):
        stmt = stmt.where(Centre.id == user.centre_id)
    return db.execute(stmt).scalars().all()


@meta.get("/config")
def get_config():
    return {
        "ldh_upper_limit": settings.LDH_UPPER_LIMIT,
        "igm_flag_threshold": settings.IGM_FLAG_THRESHOLD,
        "followup_due_months": settings.FOLLOWUP_DUE_MONTHS,
        "followup_overdue_months": settings.FOLLOWUP_OVERDUE_MONTHS,
        "max_import_rows": settings.MAX_IMPORT_ROWS,
        "access_token_minutes": settings.ACCESS_TOKEN_MINUTES,
        "ipss_wm_definition": {
            "covariates": ["age > 65 years", "haemoglobin <= 11.5 g/dL",
                           "platelets <= 100 x10^9/L", "beta-2 microglobulin > 3 mg/L",
                           "serum IgM > 70 g/L"],
            "risk_groups": {"Low": "0-1 covariates and age <= 65",
                            "Intermediate": "2 covariates, or age > 65",
                            "High": "more than 2 covariates"},
            "reference": "Morel P et al. International prognostic scoring system for "
                         "Waldenstrom macroglobulinemia. Blood 2009;113:4163-70.",
        },
    }


# ===========================================================================
# Data queries
# ===========================================================================
queries = APIRouter(prefix="/queries", tags=["data queries"])


def _out(q: DataQuery, patient: Optional[Patient], centre_code: Optional[str],
         raiser: Optional[str]) -> QueryOut:
    f = dictionary.FIELD_BY_KEY.get(q.field_key or "")
    return QueryOut(id=q.id, query_no=q.query_no, patient_id=q.patient_id,
                    registry_id=patient.registry_id if patient else None,
                    centre_code=centre_code, field_key=q.field_key,
                    field_label=f.label if f else q.field_key,
                    query_text=q.query_text, status=q.status,
                    raised_by_name=raiser, raised_at=q.raised_at,
                    resolved_at=q.resolved_at, resolution_note=q.resolution_note)


@queries.get("", response_model=list[QueryOut])
def list_queries(status_filter: Optional[str] = Query(None, alias="status"),
                 db: Session = Depends(get_db), user: User = Depends(current_user)):
    stmt = select(DataQuery)
    if not is_national(user):
        stmt = stmt.where(DataQuery.centre_id == user.centre_id)
    if status_filter:
        stmt = stmt.where(DataQuery.status == status_filter.upper())
    rows = db.execute(stmt.order_by(DataQuery.raised_at.desc()).limit(500)).scalars().all()

    patients = {p.id: p for p in db.execute(select(Patient)).scalars()}
    centres = {c.id: c.code for c in db.execute(select(Centre)).scalars()}
    users = {u.id: u.full_name for u in db.execute(select(User)).scalars()}
    return [_out(q, patients.get(q.patient_id), centres.get(q.centre_id), users.get(q.raised_by))
            for q in rows]


@queries.post("", response_model=QueryOut, status_code=status.HTTP_201_CREATED)
def raise_query(payload: QueryCreate, request: Request, db: Session = Depends(get_db),
                user: User = Depends(require(P.Perm.RAISE_QUERY))):
    """Ask the owning centre to check a value.

    This is the only channel through which the national coordinator can act on a
    centre's data: the query travels to the centre, the centre makes the change.
    """
    patient = get_patient_or_404(db, user, payload.patient_id)
    if patient.status == P.Status.DRAFT.value:
        raise HTTPException(status.HTTP_409_CONFLICT,
                            "A query cannot be raised on a record that has not been submitted")
    if payload.field_key and payload.field_key not in dictionary.FIELD_BY_KEY:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Unknown field")

    seq = db.execute(select(func.nextval("query_no_seq"))).scalar_one()
    q = DataQuery(query_no=f"Q-{seq:04d}", patient_id=patient.id, centre_id=patient.centre_id,
                  field_key=payload.field_key, query_text=payload.query_text.strip(),
                  raised_by=user.id)
    db.add(q)
    # A query raised by the owning centre flags the record. A query raised by the
    # national coordinator does not: the workflow state of a record belongs to
    # the centre that owns it, and the coordinator has no write access to it.
    # The centre still sees the flag, because every patient payload carries the
    # count of open queries.
    if not is_national(user) and patient.status == P.Status.SUBMITTED.value:
        patient.status = P.Status.QUERY.value

    record(db, user=user, action=f"Raised data query {q.query_no}", entity_type="query",
           entity_id=q.id, patient=patient, detail=payload.query_text[:500],
           ip=client_ip(request))
    db.commit()
    db.refresh(q)
    return _out(q, patient, db.get(Centre, patient.centre_id).code, user.full_name)


@queries.post("/{query_id}/resolve", response_model=QueryOut)
def resolve_query(query_id: uuid.UUID, payload: QueryResolve, request: Request,
                  db: Session = Depends(get_db),
                  user: User = Depends(require(P.Perm.RESOLVE_QUERY))):
    """Only the owning centre closes a query — the raiser cannot close their own."""
    q = db.get(DataQuery, query_id)
    if q is None or (not is_national(user) and q.centre_id != user.centre_id):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Query not found")
    if q.centre_id != user.centre_id:
        raise HTTPException(status.HTTP_403_FORBIDDEN,
                            "A query is resolved by the centre that owns the record")
    if q.status != "OPEN":
        raise HTTPException(status.HTTP_409_CONFLICT, "This query is already closed")

    q.status = "RESOLVED"
    q.resolved_by = user.id
    q.resolved_at = _now()
    q.resolution_note = payload.resolution_note

    patient = db.get(Patient, q.patient_id)
    remaining = db.execute(select(func.count()).select_from(DataQuery)
                           .where(DataQuery.patient_id == q.patient_id,
                                  DataQuery.status == "OPEN")).scalar_one()
    if remaining == 0 and patient.status == P.Status.QUERY.value:
        patient.status = P.Status.SUBMITTED.value

    record(db, user=user, action=f"Resolved data query {q.query_no}", entity_type="query",
           entity_id=q.id, patient=patient, detail=payload.resolution_note,
           ip=client_ip(request))
    db.commit()
    db.refresh(q)
    return _out(q, patient, db.get(Centre, q.centre_id).code, None)


# ===========================================================================
# Users and centres
# ===========================================================================
admin = APIRouter(prefix="/admin", tags=["administration"])


@admin.get("/users", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db),
               user: User = Depends(require(P.Perm.MANAGE_CENTRE_USERS))):
    """A Head of Department administers only their own department's accounts."""
    return db.execute(select(User).where(User.centre_id == user.centre_id)
                      .order_by(User.full_name)).scalars().all()


@admin.post("/users", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def create_user(payload: UserCreate, request: Request, db: Session = Depends(get_db),
                user: User = Depends(require(P.Perm.MANAGE_CENTRE_USERS))):
    problems = validate_password_strength(payload.initial_password, payload.email)
    if problems:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                            "Initial password " + "; ".join(problems))
    if payload.role == "IMAGE":
        raise HTTPException(status.HTTP_403_FORBIDDEN,
                            "A national coordinator account is created centrally, not by a centre")

    centre = resolve_centre(db, user, payload.centre_code) if payload.centre_code else user.centre
    if centre is None or centre.id != user.centre_id:
        raise HTTPException(status.HTTP_403_FORBIDDEN,
                            "You may only create accounts in your own centre")
    if db.execute(select(User).where(User.email == payload.email.lower())).scalar_one_or_none():
        raise HTTPException(status.HTTP_409_CONFLICT, "That email address already has an account")

    new = User(email=payload.email.lower(), full_name=payload.full_name,
               designation=payload.designation, role=payload.role, centre_id=centre.id,
               password_hash=hash_password(payload.initial_password), must_change_password=True)
    db.add(new)
    record(db, user=user, action="Created a centre user account", entity_type="user",
           entity_id=new.id, detail=f"{payload.full_name} ({payload.role})", ip=client_ip(request))
    db.commit()
    db.refresh(new)
    return new


@admin.patch("/users/{user_id}", response_model=UserOut)
def update_user(user_id: uuid.UUID, payload: UserUpdate, request: Request,
                db: Session = Depends(get_db),
                user: User = Depends(require(P.Perm.MANAGE_CENTRE_USERS))):
    target = db.get(User, user_id)
    if target is None or target.centre_id != user.centre_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "User not found")
    if target.id == user.id and payload.is_active is False:
        raise HTTPException(status.HTTP_409_CONFLICT, "You cannot deactivate your own account")
    if payload.role == "IMAGE":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "A centre cannot grant national access")

    changes: dict = {}
    for attr in ("full_name", "designation", "role", "is_active"):
        v = getattr(payload, attr)
        if v is not None and getattr(target, attr) != v:
            changes[attr] = {"from": getattr(target, attr), "to": v}
            setattr(target, attr, v)
    if payload.reset_password_to:
        problems = validate_password_strength(payload.reset_password_to, target.email)
        if problems:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                                "Password " + "; ".join(problems))
        target.password_hash = hash_password(payload.reset_password_to)
        target.password_changed_at = _now()
        target.must_change_password = True
        target.failed_logins = 0
        target.locked_until = None
        changes["password"] = {"from": "***", "to": "reset"}

    record(db, user=user, action="Updated a centre user account", entity_type="user",
           entity_id=target.id, changes=changes, ip=client_ip(request))
    db.commit()
    db.refresh(target)
    return target


@admin.post("/centres", response_model=CentreOut, status_code=status.HTTP_201_CREATED)
def create_centre(payload: dict, request: Request, db: Session = Depends(get_db),
                  user: User = Depends(require(P.Perm.MANAGE_CENTRES))):
    """Only the national coordinator enrols a new participating centre."""
    code = str(payload.get("code", "")).strip().upper()
    name = str(payload.get("name", "")).strip()
    if not code or not name:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "code and name are required")
    if db.execute(select(Centre).where(Centre.code == code)).scalar_one_or_none():
        raise HTTPException(status.HTTP_409_CONFLICT, "That centre code already exists")
    centre = Centre(code=code, name=name, city=payload.get("city"), state=payload.get("state"),
                    zone=payload.get("zone"), pi_name=payload.get("pi_name"),
                    ethics_approval_ref=payload.get("ethics_approval_ref"))
    db.add(centre)
    record(db, user=user, action="Enrolled a participating centre", entity_type="centre",
           entity_id=centre.id, detail=f"{code} — {name}", ip=client_ip(request))
    db.commit()
    db.refresh(centre)
    return centre


# ===========================================================================
# Audit trail
# ===========================================================================
audit = APIRouter(prefix="/audit", tags=["audit"])


@audit.get("")
def list_audit(limit: int = Query(100, le=1000), offset: int = 0,
               registry_id: Optional[str] = None, action: Optional[str] = None,
               db: Session = Depends(get_db), user: User = Depends(require(P.Perm.VIEW_AUDIT))):
    """Centre staff see their own centre's events; the coordinator sees all."""
    stmt = select(AuditLog)
    if not is_national(user):
        centre_code = user.centre.code if user.centre else None
        stmt = stmt.where(AuditLog.centre_code == centre_code)
    if registry_id:
        stmt = stmt.where(AuditLog.registry_id == registry_id)
    if action:
        stmt = stmt.where(AuditLog.action.ilike(f"%{action}%"))

    total = db.execute(select(func.count()).select_from(stmt.subquery())).scalar_one()
    rows = db.execute(stmt.order_by(AuditLog.at.desc()).limit(limit).offset(offset)).scalars().all()
    return {
        "total": total, "limit": limit, "offset": offset,
        "items": [{"id": r.id, "at": r.at, "user": r.user_name, "role": r.user_role,
                   "centre": r.centre_code, "action": r.action, "entity": r.entity_type,
                   "registry_id": r.registry_id, "ip": r.ip, "changes": r.changes,
                   "detail": r.detail} for r in rows],
    }


router.include_router(meta)
router.include_router(queries)
router.include_router(admin)
router.include_router(audit)
