"""Patient records: list, read, create, update, workflow transitions,
therapy lines and follow-up visits."""
from __future__ import annotations

import uuid
from datetime import date, datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.api.deps import (client_ip, current_user, get_db, get_patient_or_404,
                          get_writable_patient, is_national, require, resolve_centre,
                          scoped_patients)
from app.core.permissions import Perm, Status, baseline_editable, can_transition, followup_editable, has
from app.models import Centre, DataQuery, FollowupVisit, Patient, TherapyLine, User
from app.schemas import (Page, PatientCreate, PatientDetail, PatientSummary, PatientUpdate,
                         QueryOut, TherapyLineIn, TherapyLineOut, TransitionRequest,
                         VisitIn, VisitOut)
from app.services import derive as D
from app.services.audit import diff, record, snapshot
from app.services.dictionary import (BASELINE_KEYS, FIELD_BY_KEY, FOLLOWUP_KEYS,
                                     LINE_FIELD_BY_KEY, VISIT_FIELD_BY_KEY)
from app.services.validation import Issue, check_consistency, coerce

router = APIRouter(prefix="/patients", tags=["patients"])


def _now():
    return datetime.now(timezone.utc)


# --------------------------------------------------------------------------- helpers
def _validate_assignments(values: dict, field_map: dict) -> tuple[dict, list[Issue]]:
    """Run every supplied value through the shared dictionary rules."""
    clean, issues = {}, []
    for key, raw in values.items():
        f = field_map.get(key)
        if f is None:
            clean[key] = raw
            continue
        if raw is None:
            clean[key] = None
            continue
        res = coerce(f, raw)
        issues.extend(res.issues)
        if res.failed:
            continue
        clean[key] = res.value
    return clean, issues


def _raise_on_errors(issues: list[Issue]) -> list[dict]:
    errors = [i for i in issues if i.level == "error"]
    if errors:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                            {"message": "Some values could not be accepted",
                             "errors": [i.as_dict() for i in errors]})
    return [i.as_dict() for i in issues]


def _renumber_lines(db: Session, patient: Patient) -> None:
    """Lines are ordered by start date; the numbering follows automatically so
    the flat worksheet columns AW-BB always describe the true first line."""
    lines = db.execute(select(TherapyLine).where(TherapyLine.patient_id == patient.id)).scalars().all()
    lines.sort(key=lambda l: (l.start_date or date.max, l.created_at or _now()))
    for i, l in enumerate(lines, start=1):
        l.line_no = -i          # two-pass avoids tripping the unique constraint
    db.flush()
    for l in lines:
        l.line_no = -l.line_no
    db.flush()


def _permissions_for(user: User, patient: Patient) -> dict[str, bool]:
    own = (not is_national(user)) and patient.centre_id == user.centre_id
    return {
        "edit_baseline": own and baseline_editable(user.role, patient.status),
        "edit_followup": own and followup_editable(user.role, patient.status),
        "submit": own and has(user.role, Perm.SUBMIT) and patient.status == Status.DRAFT.value,
        "verify": own and has(user.role, Perm.VERIFY)
                  and patient.status in (Status.SUBMITTED.value, Status.QUERY.value),
        "approve": own and has(user.role, Perm.APPROVE) and patient.status == Status.VERIFIED.value,
        "unlock": own and has(user.role, Perm.UNLOCK) and patient.status == Status.APPROVED.value,
        "raise_query": has(user.role, Perm.RAISE_QUERY) and patient.status != Status.DRAFT.value,
        "delete": own and patient.status == Status.DRAFT.value and has(user.role, Perm.EDIT_BASELINE),
    }


def _stored_fields(patient: Patient, national: bool) -> dict:
    data = {f.key: getattr(patient, f.key, None)
            for f in FIELD_BY_KEY.values()
            if f.type != "derived" and hasattr(patient, f.key)}
    if national:
        # The hospital number never leaves the owning centre.
        data["crno"] = None
    return data


def _detail(db: Session, user: User, patient: Patient) -> PatientDetail:
    lines = list(patient.therapy_lines)
    derived = D.derive_patient(patient, lines)
    national = is_national(user)
    queries = db.execute(
        select(DataQuery).where(DataQuery.patient_id == patient.id,
                                DataQuery.status == "OPEN")).scalars().all()
    return PatientDetail(
        id=patient.id, registry_id=patient.registry_id, registry_no=patient.registry_no,
        centre=patient.centre if hasattr(patient, "centre") else db.get(Centre, patient.centre_id),
        status=patient.status, version=patient.version,
        fields=_stored_fields(patient, national),
        derived=derived,
        completeness=D.completeness(patient, lines),
        warnings=[i.as_dict() for i in check_consistency(patient, lines)],
        therapy_lines=[TherapyLineOut.model_validate(l) for l in lines],
        visits=[VisitOut.model_validate(v) for v in patient.visits],
        permissions=_permissions_for(user, patient),
        workflow={
            "status": patient.status,
            "submitted_at": patient.submitted_at, "verified_at": patient.verified_at,
            "approved_at": patient.approved_at,
            "followup_amended": patient.followup_amended,
            "followup_amended_at": patient.followup_amended_at,
            "imported": patient.import_batch_id is not None,
            "import_issue_count": patient.import_issue_count,
        },
        open_queries=[_query_out(q, patient) for q in queries],
    )


def _query_out(q: DataQuery, patient: Optional[Patient] = None) -> QueryOut:
    f = FIELD_BY_KEY.get(q.field_key or "")
    return QueryOut(
        id=q.id, query_no=q.query_no, patient_id=q.patient_id,
        registry_id=patient.registry_id if patient else None,
        field_key=q.field_key, field_label=f.label if f else q.field_key,
        query_text=q.query_text, status=q.status, raised_at=q.raised_at,
        resolved_at=q.resolved_at, resolution_note=q.resolution_note)


# --------------------------------------------------------------------------- list
@router.get("", response_model=Page)
def list_patients(
    db: Session = Depends(get_db), user: User = Depends(current_user),
    q: Optional[str] = Query(None, description="Registry ID or hospital CR number"),
    status_filter: Optional[str] = Query(None, alias="status"),
    centre: Optional[str] = Query(None, description="AHC code (national role only)"),
    risk: Optional[str] = Query(None, description="IPSS-WM risk group"),
    followup_overdue: bool = False,
    limit: int = Query(50, le=500), offset: int = 0,
):
    stmt = scoped_patients(user)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(Patient.registry_id.ilike(like) | Patient.crno.ilike(like))
    if status_filter:
        stmt = stmt.where(Patient.status == status_filter)
    if centre:
        c = resolve_centre(db, user, centre)
        stmt = stmt.where(Patient.centre_id == c.id)

    total = db.execute(select(func.count()).select_from(stmt.subquery())).scalar_one()
    rows = db.execute(stmt.order_by(Patient.registry_no).limit(limit).offset(offset)).scalars().all()

    centres = {c.id: c for c in db.execute(select(Centre)).scalars()}
    open_q = dict(db.execute(
        select(DataQuery.patient_id, func.count()).where(DataQuery.status == "OPEN")
        .group_by(DataQuery.patient_id)).all())

    today = date.today()
    items = []
    for p in rows:
        d = D.derive_patient(p)
        if risk and d.get("ipss_risk") != risk:
            continue
        gap = D.months_between(p.last_followup_date, today)
        if followup_overdue and not (p.death is not True and gap is not None and gap > 6):
            continue
        items.append(PatientSummary(
            id=p.id, registry_id=p.registry_id, registry_no=p.registry_no,
            centre_code=centres[p.centre_id].code,
            crno=None if is_national(user) else p.crno,
            age=p.age, gender=p.gender, dx_date=p.dx_date, hb=p.hb, igm=p.igm,
            ipss_risk=d["ipss_risk"], l1_category=d["l1_category"], l1_response=d["l1_response"],
            pfs_months=d["pfs_months"], pfs_event=d["pfs_event"],
            os_months=d["os_months"], os_event=d["os_event"],
            death=p.death, status=p.status,
            completeness=D.completeness(p)["percent"],
            open_queries=open_q.get(p.id, 0),
            followup_amended=p.followup_amended,
            months_since_followup=gap,
        ))
    return Page(items=items, total=total, limit=limit, offset=offset)


# --------------------------------------------------------------------------- read
@router.get("/{patient_id}", response_model=PatientDetail)
def get_patient(patient_id: uuid.UUID, db: Session = Depends(get_db),
                user: User = Depends(current_user)):
    return _detail(db, user, get_patient_or_404(db, user, patient_id))


# --------------------------------------------------------------------------- create
@router.post("", response_model=PatientDetail, status_code=status.HTTP_201_CREATED)
def create_patient(payload: PatientCreate, request: Request,
                   db: Session = Depends(get_db),
                   user: User = Depends(require(Perm.CREATE))):
    """The centre is taken from the signed-in user and cannot be supplied by the
    client, so a record can never be created against another centre."""
    if user.centre_id is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your account is not attached to a centre")

    values, issues = _validate_assignments(payload.model_dump(exclude_none=True), FIELD_BY_KEY)
    warnings = _raise_on_errors(issues)

    # registry_no is allocated from a sequence to stay unique under concurrency
    next_no = db.execute(select(func.nextval("registry_no_seq"))).scalar_one()
    patient = Patient(centre_id=user.centre_id, registry_no=next_no,
                      registry_id=f"WM{next_no:04d}", status=Status.DRAFT.value,
                      created_by=user.id, **values)
    db.add(patient)
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status.HTTP_409_CONFLICT,
                            f"A record with hospital number '{payload.crno}' already exists "
                            f"in your centre")

    record(db, user=user, action="Created record", entity_type="patient",
           entity_id=patient.id, patient=patient, ip=client_ip(request),
           user_agent=request.headers.get("user-agent"))
    db.commit()
    db.refresh(patient)
    detail = _detail(db, user, patient)
    detail.warnings = detail.warnings + warnings
    return detail


# --------------------------------------------------------------------------- update
@router.patch("/{patient_id}", response_model=PatientDetail)
def update_patient(patient_id: uuid.UUID, payload: PatientUpdate, request: Request,
                   db: Session = Depends(get_db), user: User = Depends(current_user)):
    """Sparse update.

    Baseline fields (frames 1-6) freeze on HoD approval. Outcome fields stay
    open to anyone with follow-up rights, because a registry has to keep
    recording what happens after the baseline is signed off; such a change is
    marked as an amendment and flagged to the Head of Department.
    """
    patient = get_writable_patient(db, user, patient_id)
    supplied = payload.model_dump(exclude_unset=True)
    client_version = supplied.pop("version", None)

    if client_version is not None and client_version != patient.version:
        raise HTTPException(status.HTTP_409_CONFLICT,
                            "This record was changed by someone else while you were editing. "
                            "Reload it and re-apply your change.")
    if not supplied:
        return _detail(db, user, patient)

    touches_baseline = bool(set(supplied) & BASELINE_KEYS)
    touches_followup = bool(set(supplied) & FOLLOWUP_KEYS)

    if touches_baseline and not baseline_editable(user.role, patient.status):
        raise HTTPException(
            status.HTTP_423_LOCKED,
            "The baseline of this record has been approved and locked by the Head of "
            "Department. Follow-up fields remain editable; ask your HoD to unlock the "
            "record if a baseline correction is required.")
    if touches_followup and not followup_editable(user.role, patient.status):
        raise HTTPException(status.HTTP_403_FORBIDDEN,
                            "Your role may not record follow-up data")

    values, issues = _validate_assignments(supplied, FIELD_BY_KEY)
    warnings = _raise_on_errors(issues)

    before = snapshot(patient, set(values))
    for k, v in values.items():
        setattr(patient, k, v)

    # keep dependent fields honest
    if patient.relapse is False:
        patient.relapse_date = None
    if patient.death is False:
        patient.death_date = patient.death_cause = None
    if patient.transformation is False:
        patient.transformation_date = None

    hard = [i for i in check_consistency(patient, patient.therapy_lines) if i.level == "error"]
    if hard:
        db.rollback()
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                            {"message": "The change is internally inconsistent",
                             "errors": [i.as_dict() for i in hard]})

    patient.version += 1
    amended = patient.status == Status.APPROVED.value
    if amended:
        patient.followup_amended = True
        patient.followup_amended_at = _now()

    record(db, user=user,
           action="Amended follow-up on a locked record" if amended else "Updated record",
           entity_type="patient", entity_id=patient.id, patient=patient,
           changes=diff(before, snapshot(patient, set(values))),
           ip=client_ip(request), user_agent=request.headers.get("user-agent"))
    db.commit()
    db.refresh(patient)
    detail = _detail(db, user, patient)
    detail.warnings = detail.warnings + warnings
    return detail


@router.delete("/{patient_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_draft(patient_id: uuid.UUID, request: Request, db: Session = Depends(get_db),
                 user: User = Depends(current_user)):
    """Only an unsubmitted draft can be removed; anything further along is part
    of the study record and must be retained."""
    patient = get_writable_patient(db, user, patient_id)
    if patient.status != Status.DRAFT.value:
        raise HTTPException(status.HTTP_409_CONFLICT,
                            "Only a draft may be deleted. Submitted records are part of the "
                            "study database and are retained.")
    record(db, user=user, action="Deleted draft record", entity_type="patient",
           entity_id=patient.id, patient=patient, ip=client_ip(request),
           detail=f"CR {patient.crno}")
    db.delete(patient)
    db.commit()


# --------------------------------------------------------------------------- workflow
@router.post("/{patient_id}/transition", response_model=PatientDetail)
def transition(patient_id: uuid.UUID, payload: TransitionRequest, request: Request,
               db: Session = Depends(get_db), user: User = Depends(current_user)):
    patient = get_writable_patient(db, user, patient_id)
    ok, why = can_transition(user.role, patient.status, payload.to)
    if not ok:
        raise HTTPException(status.HTTP_403_FORBIDDEN, why)

    if payload.to == Status.SUBMITTED.value and patient.status == Status.DRAFT.value:
        comp = D.completeness(patient, patient.therapy_lines)
        if not comp["submittable"]:
            raise HTTPException(
                status.HTTP_422_UNPROCESSABLE_ENTITY,
                {"message": "Mandatory fields are still missing",
                 "missing": comp["missing_required"]})
        if not patient.therapy_lines:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                                {"message": "At least one line of therapy must be recorded "
                                            "before submission (worksheet columns AV–BB)"})

    if payload.to == Status.QUERY.value and not db.execute(
            select(DataQuery).where(DataQuery.patient_id == patient.id,
                                    DataQuery.status == "OPEN")).first():
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                            "Raise a data query first — a record is only flagged when an "
                            "open query exists against it")

    previous = patient.status
    patient.status = payload.to
    now = _now()
    if payload.to == Status.SUBMITTED.value:
        patient.submitted_by, patient.submitted_at = user.id, now
    elif payload.to == Status.VERIFIED.value:
        patient.verified_by, patient.verified_at = user.id, now
    elif payload.to == Status.APPROVED.value:
        patient.approved_by, patient.approved_at = user.id, now
        patient.followup_amended = False        # HoD has re-confirmed
    patient.version += 1

    labels = {"SUBMITTED": "Submitted for clinical verification",
              "VERIFIED": "Clinically verified", "APPROVED": "Approved and locked",
              "DRAFT": "Returned to data entry", "QUERY": "Flagged with a data query"}
    record(db, user=user, action=labels.get(payload.to, f"Moved to {payload.to}"),
           entity_type="patient", entity_id=patient.id, patient=patient,
           changes={"status": {"from": previous, "to": payload.to}},
           detail=payload.note, ip=client_ip(request),
           user_agent=request.headers.get("user-agent"))
    db.commit()
    db.refresh(patient)
    return _detail(db, user, patient)


# --------------------------------------------------------------------------- therapy lines
@router.post("/{patient_id}/therapy-lines", response_model=PatientDetail,
             status_code=status.HTTP_201_CREATED)
def add_line(patient_id: uuid.UUID, payload: TherapyLineIn, request: Request,
             db: Session = Depends(get_db), user: User = Depends(current_user)):
    patient = get_writable_patient(db, user, patient_id)
    if not followup_editable(user.role, patient.status):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role may not record therapy")

    values, issues = _validate_assignments(payload.model_dump(exclude_none=True), LINE_FIELD_BY_KEY)
    warnings = _raise_on_errors(issues)

    line = TherapyLine(patient_id=patient.id, centre_id=patient.centre_id,
                       line_no=len(patient.therapy_lines) + 1, created_by=user.id,
                       added_after_lock=(patient.status == Status.APPROVED.value), **values)
    db.add(line)
    db.flush()
    _renumber_lines(db, patient)

    if line.added_after_lock:
        patient.followup_amended = True
        patient.followup_amended_at = _now()
    patient.version += 1

    record(db, user=user, action="Added a line of therapy", entity_type="therapy_line",
           entity_id=line.id, patient=patient, changes=snapshot(line),
           ip=client_ip(request))
    db.commit()
    db.refresh(patient)
    detail = _detail(db, user, patient)
    detail.warnings += warnings
    return detail


@router.patch("/{patient_id}/therapy-lines/{line_id}", response_model=PatientDetail)
def update_line(patient_id: uuid.UUID, line_id: uuid.UUID, payload: TherapyLineIn,
                request: Request, db: Session = Depends(get_db),
                user: User = Depends(current_user)):
    patient = get_writable_patient(db, user, patient_id)
    if not followup_editable(user.role, patient.status):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role may not record therapy")
    line = db.execute(select(TherapyLine).where(TherapyLine.id == line_id,
                                                TherapyLine.patient_id == patient.id)).scalar_one_or_none()
    if line is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Therapy line not found")

    values, issues = _validate_assignments(payload.model_dump(exclude_unset=True), LINE_FIELD_BY_KEY)
    warnings = _raise_on_errors(issues)
    before = snapshot(line, set(values))
    for k, v in values.items():
        setattr(line, k, v)
    db.flush()
    _renumber_lines(db, patient)
    patient.version += 1

    record(db, user=user, action="Edited a line of therapy", entity_type="therapy_line",
           entity_id=line.id, patient=patient, changes=diff(before, snapshot(line, set(values))),
           ip=client_ip(request))
    db.commit()
    db.refresh(patient)
    detail = _detail(db, user, patient)
    detail.warnings += warnings
    return detail


@router.delete("/{patient_id}/therapy-lines/{line_id}", response_model=PatientDetail)
def delete_line(patient_id: uuid.UUID, line_id: uuid.UUID, request: Request,
                db: Session = Depends(get_db), user: User = Depends(current_user)):
    patient = get_writable_patient(db, user, patient_id)
    if not followup_editable(user.role, patient.status):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role may not record therapy")
    line = db.execute(select(TherapyLine).where(TherapyLine.id == line_id,
                                                TherapyLine.patient_id == patient.id)).scalar_one_or_none()
    if line is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Therapy line not found")
    record(db, user=user, action="Removed a line of therapy", entity_type="therapy_line",
           entity_id=line.id, patient=patient, changes=snapshot(line), ip=client_ip(request))
    db.delete(line)
    db.flush()
    _renumber_lines(db, patient)
    patient.version += 1
    db.commit()
    db.refresh(patient)
    return _detail(db, user, patient)


# --------------------------------------------------------------------------- follow-up visits
@router.post("/{patient_id}/visits", response_model=PatientDetail,
             status_code=status.HTTP_201_CREATED)
def add_visit(patient_id: uuid.UUID, payload: VisitIn, request: Request,
              db: Session = Depends(get_db), user: User = Depends(current_user)):
    """Record a follow-up contact.

    Available to the DEO, clinician and HoD, and deliberately still available
    after the record is approved and locked: locking protects the baseline, it
    does not end the patient's follow-up.
    """
    patient = get_writable_patient(db, user, patient_id)
    if not followup_editable(user.role, patient.status):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role may not record follow-up")

    values, issues = _validate_assignments(payload.model_dump(exclude_none=True), VISIT_FIELD_BY_KEY)
    warnings = _raise_on_errors(issues)

    if patient.dx_date and values.get("visit_date") and values["visit_date"] < patient.dx_date:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                            "A follow-up visit cannot precede the date of diagnosis")

    locked = patient.status == Status.APPROVED.value
    visit = FollowupVisit(patient_id=patient.id, centre_id=patient.centre_id,
                          created_by=user.id, added_after_lock=locked, **values)
    db.add(visit)
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status.HTTP_409_CONFLICT,
                            "A visit is already recorded for that date")

    # The latest contact drives the last follow-up date (BM) and therefore OS.
    if not patient.death and (patient.last_followup_date is None
                              or visit.visit_date > patient.last_followup_date):
        patient.last_followup_date = visit.visit_date

    # Progressive disease at a visit sets relapse (BC) and its date (BD).
    auto = None
    if visit.disease_status and visit.disease_status.startswith("PD") and not patient.relapse:
        patient.relapse = True
        if not patient.relapse_date:
            patient.relapse_date = visit.visit_date
        auto = "Progression recorded at this visit set Relapse/Progression (BC) and its date (BD)"

    if locked:
        patient.followup_amended = True
        patient.followup_amended_at = _now()
    patient.version += 1

    record(db, user=user,
           action="Added follow-up visit to a locked record" if locked else "Added follow-up visit",
           entity_type="visit", entity_id=visit.id, patient=patient,
           changes=snapshot(visit), detail=auto, ip=client_ip(request),
           user_agent=request.headers.get("user-agent"))
    db.commit()
    db.refresh(patient)
    detail = _detail(db, user, patient)
    detail.warnings += warnings
    if auto:
        detail.warnings.append({"field": "Relapse/Progression", "column": "BC",
                                "level": "info", "message": auto})
    return detail


@router.patch("/{patient_id}/visits/{visit_id}", response_model=PatientDetail)
def update_visit(patient_id: uuid.UUID, visit_id: uuid.UUID, payload: VisitIn,
                 request: Request, db: Session = Depends(get_db),
                 user: User = Depends(current_user)):
    patient = get_writable_patient(db, user, patient_id)
    if not followup_editable(user.role, patient.status):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role may not record follow-up")
    visit = db.execute(select(FollowupVisit).where(FollowupVisit.id == visit_id,
                                                   FollowupVisit.patient_id == patient.id)).scalar_one_or_none()
    if visit is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Visit not found")

    values, issues = _validate_assignments(payload.model_dump(exclude_unset=True), VISIT_FIELD_BY_KEY)
    warnings = _raise_on_errors(issues)
    before = snapshot(visit, set(values))
    for k, v in values.items():
        setattr(visit, k, v)
    patient.version += 1
    record(db, user=user, action="Edited follow-up visit", entity_type="visit",
           entity_id=visit.id, patient=patient,
           changes=diff(before, snapshot(visit, set(values))), ip=client_ip(request))
    db.commit()
    db.refresh(patient)
    detail = _detail(db, user, patient)
    detail.warnings += warnings
    return detail


@router.delete("/{patient_id}/visits/{visit_id}", response_model=PatientDetail)
def delete_visit(patient_id: uuid.UUID, visit_id: uuid.UUID, request: Request,
                 db: Session = Depends(get_db), user: User = Depends(current_user)):
    patient = get_writable_patient(db, user, patient_id)
    if not followup_editable(user.role, patient.status):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role may not record follow-up")
    visit = db.execute(select(FollowupVisit).where(FollowupVisit.id == visit_id,
                                                   FollowupVisit.patient_id == patient.id)).scalar_one_or_none()
    if visit is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Visit not found")
    record(db, user=user, action="Removed follow-up visit", entity_type="visit",
           entity_id=visit.id, patient=patient, changes=snapshot(visit), ip=client_ip(request))
    db.delete(visit)
    db.flush()
    remaining = db.execute(select(func.max(FollowupVisit.visit_date))
                           .where(FollowupVisit.patient_id == patient.id)).scalar_one_or_none()
    if not patient.death and remaining:
        patient.last_followup_date = remaining
    patient.version += 1
    db.commit()
    db.refresh(patient)
    return _detail(db, user, patient)
