"""Bulk import of retrospective data from a centre's own Excel worksheet.

Two phases, deliberately: ``/preview`` parses and validates without writing
anything, ``/commit`` writes the rows the operator has accepted. The parsed
payload is held on the import batch row between the two calls, so a large file
is not re-uploaded when the mapping is corrected.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime, timezone
from typing import Any, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile, status
from fastapi.responses import Response
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import client_ip, get_db, require
from app.core.config import settings
from app.core.permissions import Perm, Status
from app.models import ImportBatch, Patient, TherapyLine, User
from app.schemas import ImportCommitRequest, ImportPreview, ImportPreviewRow, ImportResult
from app.services import derive as D
from app.services.audit import record
from app.services.dictionary import FIELD_BY_KEY
from app.services.excel import (IMPORTABLE, auto_map, build_csv, build_workbook,
                                read_tabular, template_rows)
from app.services.validation import coerce

router = APIRouter(prefix="/imports", tags=["bulk import"])

# Flat worksheet columns that describe the first and second line of therapy.
# They are not patient columns in the database; the importer turns them into
# therapy_lines rows so the normalised model and the flat sheet agree.
LINE1_KEYS = {"l1_category": "category", "l1_regimen": "regimen", "l1_cycles": "cycles",
              "l1_start": "start_date", "l1_end": "end_date", "l1_response": "best_response"}


def _now():
    return datetime.now(timezone.utc)


# --------------------------------------------------------------------------- templates
@router.get("/template.xlsx")
def template_xlsx(user: User = Depends(require(Perm.BULK_IMPORT))):
    headers, notes = template_rows()
    data = build_workbook("WM Data Sheet", headers, [], note_row=notes)
    return Response(content=data,
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": 'attachment; filename="IMAGe_WM_import_template.xlsx"'})


@router.get("/template.csv")
def template_csv(user: User = Depends(require(Perm.BULK_IMPORT))):
    headers, notes = template_rows()
    return Response(content=build_csv(headers, [notes]), media_type="text/csv",
                    headers={"Content-Disposition": 'attachment; filename="IMAGe_WM_import_template.csv"'})


# --------------------------------------------------------------------------- preview
@router.post("/preview", response_model=ImportPreview)
async def preview(request: Request, file: UploadFile = File(...),
                  mapping_json: Optional[str] = Form(None),
                  db: Session = Depends(get_db),
                  user: User = Depends(require(Perm.BULK_IMPORT))):
    """Parse and validate an uploaded worksheet. Nothing is written to the registry."""
    if user.centre_id is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your account is not attached to a centre")

    name = (file.filename or "upload").strip()
    if not name.lower().endswith((".xlsx", ".csv")):
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
                            "Upload an .xlsx or .csv file")
    raw = await file.read()
    if len(raw) > settings.MAX_UPLOAD_BYTES:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                            f"File exceeds {settings.MAX_UPLOAD_BYTES // (1024*1024)} MB")

    try:
        rows, sheet = read_tabular(raw, name)
    except Exception as exc:                                    # noqa: BLE001
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"Could not read the file: {exc}")

    if len(rows) < 2:
        raise HTTPException(status.HTTP_400_BAD_REQUEST,
                            "The file needs a heading row and at least one data row")
    if len(rows) - 1 > settings.MAX_IMPORT_ROWS:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                            f"At most {settings.MAX_IMPORT_ROWS} rows per upload")

    headers = [str(h) if h is not None else "" for h in rows[0]]
    mapping, unmapped = auto_map(headers)
    if mapping_json:
        import json
        try:
            mapping = {str(k): v for k, v in json.loads(mapping_json).items() if v}
        except ValueError:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "mapping_json is not valid JSON")

    batch = ImportBatch(centre_id=user.centre_id, filename=name, sheet_name=sheet,
                        uploaded_by=user.id, rows_read=len(rows) - 1,
                        report={"headers": headers, "rows": _jsonable(rows[1:]),
                                "mapping": mapping})
    db.add(batch)
    db.flush()

    parsed = _parse(db, user, rows, mapping)
    record(db, user=user, action="Uploaded a worksheet for import", entity_type="import",
           entity_id=batch.id, detail=f"{name} — {len(rows) - 1} rows", ip=client_ip(request))
    db.commit()

    required_unmapped = sorted(
        f.label for f in IMPORTABLE
        if f.required and f.key not in set(mapping.values()) and f.key != "centre_code")

    return ImportPreview(
        batch_id=batch.id, filename=name, sheet=sheet, detected_columns=headers,
        mapping=mapping, unmapped_columns=[h for h in unmapped if h],
        unmapped_required_fields=required_unmapped,
        rows_read=len(rows) - 1,
        summary=parsed["summary"], rows=parsed["rows"][:200])


def _jsonable(rows: list[list[Any]]) -> list[list[Any]]:
    out = []
    for r in rows:
        out.append([v.isoformat() if isinstance(v, (date, datetime)) else v for v in r])
    return out


def _parse(db: Session, user: User, rows: list[list[Any]], mapping: dict[str, str]) -> dict:
    """Validate every data row and classify it. Pure function — writes nothing."""
    existing = {c.lower() for c in db.execute(
        select(Patient.crno).where(Patient.centre_id == user.centre_id)).scalars()}
    seen: set[str] = set()
    out_rows: list[ImportPreviewRow] = []
    summary = {"ok": 0, "warning": 0, "error": 0, "duplicate": 0, "rejected": 0}

    for idx, raw_row in enumerate(rows[1:], start=2):
        values: dict[str, Any] = {}
        issues: list[dict] = []
        populated = False

        for col_idx, key in mapping.items():
            f = FIELD_BY_KEY.get(key)
            if f is None or f.type == "derived":
                continue
            try:
                cell = raw_row[int(col_idx)]
            except (IndexError, ValueError):
                continue
            res = coerce(f, cell)
            issues.extend(i.as_dict() for i in res.issues)
            if res.value not in (None, ""):
                values[key] = res.value
                populated = True

        if not populated and not values.get("crno"):
            continue

        crno = str(values.get("crno") or "").strip()
        verdict = "ok"
        if not crno:
            issues.append({"field": "CR No", "column": "C", "level": "error",
                           "message": "missing — the row cannot be identified"})
            verdict = "rejected"
        elif crno.lower() in existing:
            issues.append({"field": "CR No", "column": "C", "level": "error",
                           "message": "already registered in your centre"})
            verdict = "duplicate"
        elif crno.lower() in seen:
            issues.append({"field": "CR No", "column": "C", "level": "error",
                           "message": "repeated earlier in this file"})
            verdict = "duplicate"
        else:
            seen.add(crno.lower())
            if any(i["level"] == "error" for i in issues):
                verdict = "error"
            elif any(i["level"] == "warning" for i in issues):
                verdict = "warning"

        summary[verdict] += 1
        out_rows.append(ImportPreviewRow(
            row=idx, crno=crno or None, verdict=verdict,
            completeness=_rough_completeness(values),
            values={k: (v.isoformat() if isinstance(v, (date, datetime)) else v)
                    for k, v in values.items()},
            issues=issues))

    return {"rows": out_rows, "summary": summary}


def _rough_completeness(values: dict) -> int:
    total = len([f for f in IMPORTABLE if f.key != "centre_code"])
    return round(len(values) * 100 / total) if total else 0


# --------------------------------------------------------------------------- commit
@router.post("/commit", response_model=ImportResult)
def commit(payload: ImportCommitRequest, request: Request, db: Session = Depends(get_db),
           user: User = Depends(require(Perm.BULK_IMPORT))):
    """Write the accepted rows as drafts belonging to the caller's own centre."""
    batch = db.get(ImportBatch, payload.batch_id)
    if batch is None or batch.centre_id != user.centre_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Import batch not found")
    if batch.committed:
        raise HTTPException(status.HTTP_409_CONFLICT, "This batch has already been imported")

    stored = batch.report or {}
    headers = stored.get("headers", [])
    data_rows = stored.get("rows", [])
    mapping = payload.mapping or stored.get("mapping", {})

    parsed = _parse(db, user, [headers] + data_rows, mapping)
    skip = set(payload.skip_rows)

    imported: list[str] = []
    flagged = skipped = 0

    for row in parsed["rows"]:
        if row.verdict in ("duplicate", "rejected") or row.row in skip:
            skipped += 1
            continue

        values = dict(row.values)
        line_values = {LINE1_KEYS[k]: values.pop(k) for k in list(values) if k in LINE1_KEYS}
        l2_regimen = values.pop("l2_regimen", None)

        # coerce ISO strings back to dates for the ORM
        for k, v in list(values.items()):
            f = FIELD_BY_KEY.get(k)
            if f and f.type == "date" and isinstance(v, str):
                values[k] = date.fromisoformat(v)
        for k, v in list(line_values.items()):
            if k in ("start_date", "end_date") and isinstance(v, str):
                line_values[k] = date.fromisoformat(v)

        values.pop("centre_code", None)
        values.pop("registry_no", None)

        next_no = db.execute(select(func.nextval("registry_no_seq"))).scalar_one()
        patient = Patient(centre_id=user.centre_id, registry_no=next_no,
                          registry_id=f"WM{next_no:04d}", status=Status.DRAFT.value,
                          created_by=user.id, import_batch_id=batch.id,
                          import_issue_count=len(row.issues), **values)
        db.add(patient)
        db.flush()

        if any(line_values.values()):
            db.add(TherapyLine(patient_id=patient.id, centre_id=user.centre_id,
                               line_no=1, created_by=user.id, **line_values))
        if l2_regimen:
            db.add(TherapyLine(patient_id=patient.id, centre_id=user.centre_id,
                               line_no=2, regimen=l2_regimen, created_by=user.id,
                               start_date=patient.relapse_date))
        db.flush()

        imported.append(patient.registry_id)
        if row.issues:
            flagged += 1

    batch.committed = True
    batch.rows_imported = len(imported)
    batch.rows_skipped = skipped
    batch.report = {**stored, "summary": parsed["summary"],
                    "committed_at": _now().isoformat(),
                    "registry_ids": imported}

    record(db, user=user, action="Bulk imported records from a worksheet",
           entity_type="import", entity_id=batch.id,
           detail=f"{batch.filename}: {len(imported)} imported, {skipped} skipped",
           ip=client_ip(request), user_agent=request.headers.get("user-agent"))
    db.commit()

    return ImportResult(batch_id=batch.id, imported=len(imported), skipped=skipped,
                        flagged=flagged, registry_ids=imported)


@router.get("/batches")
def list_batches(db: Session = Depends(get_db), user: User = Depends(require(Perm.BULK_IMPORT))):
    rows = db.execute(select(ImportBatch).where(ImportBatch.centre_id == user.centre_id)
                      .order_by(ImportBatch.uploaded_at.desc()).limit(50)).scalars().all()
    return [{"id": b.id, "filename": b.filename, "sheet": b.sheet_name,
             "uploaded_at": b.uploaded_at, "rows_read": b.rows_read,
             "rows_imported": b.rows_imported, "rows_skipped": b.rows_skipped,
             "committed": b.committed} for b in rows]
