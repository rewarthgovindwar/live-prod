"""Authentication: sign-in, refresh, sign-out, password change, TOTP enrolment."""
from __future__ import annotations

import secrets
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import client_ip, current_user, get_db, token_version
from app.core.config import settings
from app.core.security import (create_access_token, hash_password, hash_refresh_token,
                               needs_rehash, new_refresh_token, new_totp_secret,
                               totp_provisioning_uri, validate_password_strength,
                               verify_password, verify_totp)
from app.models import RefreshToken, User
from app.schemas import (LoginRequest, PasswordChange, RefreshRequest, TokenPair,
                         TotpEnrolConfirm, TotpEnrolStart, UserOut)
from app.services.audit import record

router = APIRouter(prefix="/auth", tags=["authentication"])


def _now():
    return datetime.now(timezone.utc)


def _issue_pair(db: Session, user: User, request: Request) -> TokenPair:
    access = create_access_token(
        user_id=user.id, role=user.role,
        centre_id=user.centre_id, centre_code=user.centre.code if user.centre else None,
        token_version=token_version(user))
    raw, hashed = new_refresh_token()
    db.add(RefreshToken(
        user_id=user.id, token_hash=hashed,
        expires_at=_now() + timedelta(days=settings.REFRESH_TOKEN_DAYS),
        ip=client_ip(request), user_agent=request.headers.get("user-agent", "")[:300]))
    return TokenPair(
        access_token=access, refresh_token=raw,
        expires_in=settings.ACCESS_TOKEN_MINUTES * 60,
        must_change_password=user.must_change_password,
        totp_enrolment_required=(user.role in settings.REQUIRE_2FA_FOR_ROLES
                                 and not user.totp_enabled))


@router.post("/login", response_model=TokenPair)
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)):
    """Sign in.

    Failures are deliberately indistinguishable from one another so the endpoint
    cannot be used to discover which addresses are registered.
    """
    generic = HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid email, password or code")
    user = db.execute(select(User).where(User.email == payload.email.lower())).scalar_one_or_none()

    if user is None:
        # Spend comparable time so timing does not leak account existence.
        verify_password(payload.password, hash_password(secrets.token_hex(16)))
        raise generic

    if user.locked_until and user.locked_until > _now():
        mins = int((user.locked_until - _now()).total_seconds() // 60) + 1
        raise HTTPException(status.HTTP_423_LOCKED,
                            f"Account temporarily locked after repeated failed sign-ins. "
                            f"Try again in {mins} minute(s) or contact your Head of Department.")

    if not user.is_active:
        raise generic

    if not verify_password(payload.password, user.password_hash):
        user.failed_logins += 1
        if user.failed_logins >= settings.MAX_FAILED_LOGINS:
            user.locked_until = _now() + timedelta(minutes=settings.LOCKOUT_MINUTES)
            user.failed_logins = 0
            record(db, user=user, action="Account locked after repeated failed sign-ins",
                   ip=client_ip(request))
        db.commit()
        raise generic

    # Second factor, mandatory for the roles named in configuration.
    if user.totp_enabled:
        if not payload.totp_code or not verify_totp(user.totp_secret or "", payload.totp_code):
            user.failed_logins += 1
            db.commit()
            raise generic
    elif user.role in settings.REQUIRE_2FA_FOR_ROLES and settings.is_production:
        raise HTTPException(status.HTTP_403_FORBIDDEN,
                            "Two-factor authentication must be enrolled for this role. "
                            "Sign in on the enrolment endpoint or contact the registry administrator.")

    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(payload.password)

    user.failed_logins = 0
    user.locked_until = None
    user.last_login_at = _now()
    pair = _issue_pair(db, user, request)
    record(db, user=user, action="Signed in", ip=client_ip(request),
           user_agent=request.headers.get("user-agent"))
    db.commit()
    return pair


@router.post("/refresh", response_model=TokenPair)
def refresh(payload: RefreshRequest, request: Request, db: Session = Depends(get_db)):
    """Exchange a refresh token. Rotates the token and revokes the presented one."""
    hashed = hash_refresh_token(payload.refresh_token)
    tok = db.execute(select(RefreshToken).where(RefreshToken.token_hash == hashed)).scalar_one_or_none()
    if tok is None or tok.revoked_at is not None or tok.expires_at <= _now():
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Refresh token is invalid or expired")

    user = db.get(User, tok.user_id)
    if user is None or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Account is inactive")

    tok.revoked_at = _now()
    pair = _issue_pair(db, user, request)
    db.commit()
    return pair


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(payload: RefreshRequest, request: Request, db: Session = Depends(get_db),
           user: User = Depends(current_user)):
    hashed = hash_refresh_token(payload.refresh_token)
    tok = db.execute(select(RefreshToken).where(RefreshToken.token_hash == hashed,
                                                RefreshToken.user_id == user.id)).scalar_one_or_none()
    if tok and tok.revoked_at is None:
        tok.revoked_at = _now()
    record(db, user=user, action="Signed out", ip=client_ip(request))
    db.commit()


@router.post("/logout-all", status_code=status.HTTP_204_NO_CONTENT)
def logout_all(request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)):
    for tok in db.execute(select(RefreshToken).where(RefreshToken.user_id == user.id,
                                                     RefreshToken.revoked_at.is_(None))).scalars():
        tok.revoked_at = _now()
    record(db, user=user, action="Signed out of all sessions", ip=client_ip(request))
    db.commit()


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(current_user)):
    return user


@router.post("/change-password", status_code=status.HTTP_204_NO_CONTENT)
def change_password(payload: PasswordChange, request: Request,
                    db: Session = Depends(get_db), user: User = Depends(current_user)):
    if not verify_password(payload.current_password, user.password_hash):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Current password is incorrect")
    problems = validate_password_strength(payload.new_password, user.email)
    if problems:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                            "Password " + "; ".join(problems))
    if verify_password(payload.new_password, user.password_hash):
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                            "New password must differ from the current one")

    user.password_hash = hash_password(payload.new_password)
    user.password_changed_at = _now()
    user.must_change_password = False
    # Changing the password invalidates every outstanding session.
    for tok in db.execute(select(RefreshToken).where(RefreshToken.user_id == user.id,
                                                     RefreshToken.revoked_at.is_(None))).scalars():
        tok.revoked_at = _now()
    record(db, user=user, action="Changed password", ip=client_ip(request))
    db.commit()


@router.post("/2fa/enrol", response_model=TotpEnrolStart)
def enrol_2fa(db: Session = Depends(get_db), user: User = Depends(current_user)):
    """Generate a secret. It is not active until confirmed with a valid code."""
    if user.totp_enabled:
        raise HTTPException(status.HTTP_409_CONFLICT, "Two-factor authentication is already enabled")
    secret = new_totp_secret()
    user.totp_secret = secret
    db.commit()
    return TotpEnrolStart(secret=secret, otpauth_uri=totp_provisioning_uri(secret, user.email))


@router.post("/2fa/confirm", status_code=status.HTTP_204_NO_CONTENT)
def confirm_2fa(payload: TotpEnrolConfirm, request: Request,
                db: Session = Depends(get_db), user: User = Depends(current_user)):
    if not user.totp_secret or not verify_totp(user.totp_secret, payload.code):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "That code is not valid")
    user.totp_enabled = True
    record(db, user=user, action="Enabled two-factor authentication", ip=client_ip(request))
    db.commit()


@router.post("/2fa/disable", status_code=status.HTTP_204_NO_CONTENT)
def disable_2fa(payload: TotpEnrolConfirm, request: Request,
                db: Session = Depends(get_db), user: User = Depends(current_user)):
    if user.role in settings.REQUIRE_2FA_FOR_ROLES:
        raise HTTPException(status.HTTP_403_FORBIDDEN,
                            "Two-factor authentication is mandatory for your role")
    if not user.totp_enabled or not verify_totp(user.totp_secret or "", payload.code):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "That code is not valid")
    user.totp_enabled = False
    user.totp_secret = None
    record(db, user=user, action="Disabled two-factor authentication", ip=client_ip(request))
    db.commit()
