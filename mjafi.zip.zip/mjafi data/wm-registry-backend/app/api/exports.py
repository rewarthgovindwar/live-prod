"""Data export in the original worksheet column order."""
from __future__ import annotations

from datetime import date, datetime
from typing import Any, Optional

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import (client_ip, get_db, is_national, require_any, resolve_centre,
                          scoped_patients)
from app.core.permissions import Perm
from app.models import Centre, User
from app.services import derive as D
from app.services.audit import record
from app.services.dictionary import WORKSHEET_ORDER
from app.services.excel import build_csv, build_workbook

router = APIRouter(prefix="/exports", tags=["export"])

EXTRA_COLUMNS = ["PFS (months)", "PFS event", "OS (months)", "OS event",
                 "Time to first treatment (months)", "Follow-up (months)",
                 "Therapy lines recorded", "Follow-up visits recorded", "Record status"]


def _bool_word(v: Any) -> Any:
    if isinstance(v, bool):
        return "Yes" if v else "No"
    return v


def _rows(db: Session, user: User, centre_code: Optional[str], analysis: bool):
    stmt = scoped_patients(user)
    if centre_code:
        c = resolve_centre(db, user, centre_code)
        stmt = stmt.where(type(stmt.column_descriptions[0]["entity"]).centre_id == c.id)
    patients = db.execute(stmt.order_by()).scalars().all()
    centres = {c.id: c for c in db.execute(select(Centre)).scalars()}
    national = is_national(user)

    out: list[list[Any]] = []
    for p in sorted(patients, key=lambda x: x.registry_no):
        d = D.derive_patient(p)
        row: list[Any] = []
        for f in WORKSHEET_ORDER:
            if f.key == "registry_no":
                row.append(p.registry_no)
            elif f.key == "centre_code":
                row.append(centres[p.centre_id].code)
            elif f.key == "crno":
                # The hospital number is centre-confidential and is replaced by
                # the registry ID in any pooled export.
                row.append(p.registry_id if national else p.crno)
            elif f.type == "derived" or f.key in d:
                row.append(_bool_word(d.get(f.key)))
            else:
                row.append(_bool_word(getattr(p, f.key, None)))
        if analysis:
            row += [d["pfs_months"], d["pfs_event"], d["os_months"], d["os_event"],
                    d["time_to_first_treatment_months"], d["followup_months"],
                    d["total_lines"], len(p.visits), p.status]
        out.append(row)
    return out, patients


def _headers(analysis: bool) -> list[str]:
    heads = [f.label for f in WORKSHEET_ORDER]
    return heads + EXTRA_COLUMNS if analysis else heads


def _filename(user: User, kind: str, ext: str, centre_code: Optional[str]) -> str:
    scope = centre_code or ("POOLED" if is_national(user)
                            else (user.centre.code if user.centre else "CENTRE"))
    return f"IMAGe_WM_{kind}_{scope}_{date.today():%Y%m%d}.{ext}"


@router.get("/patients.xlsx")
def export_xlsx(request: Request, centre: Optional[str] = None, analysis: bool = False,
                db: Session = Depends(get_db),
                user: User = Depends(require_any(Perm.EXPORT_CENTRE, Perm.EXPORT_POOLED))):
    """All 65 worksheet columns in the original order; optionally with survival variables."""
    rows, patients = _rows(db, user, centre, analysis)
    data = build_workbook("WM Data Sheet", _headers(analysis), rows)
    record(db, user=user, action="Exported dataset (xlsx)",
           detail=f"{len(rows)} records{' with survival variables' if analysis else ''}",
           ip=client_ip(request))
    db.commit()
    return Response(content=data,
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition":
                             f'attachment; filename="{_filename(user, "analysis" if analysis else "worksheet", "xlsx", centre)}"'})


@router.get("/patients.csv")
def export_csv(request: Request, centre: Optional[str] = None, analysis: bool = False,
               db: Session = Depends(get_db),
               user: User = Depends(require_any(Perm.EXPORT_CENTRE, Perm.EXPORT_POOLED))):
    rows, _ = _rows(db, user, centre, analysis)
    record(db, user=user, action="Exported dataset (csv)", detail=f"{len(rows)} records",
           ip=client_ip(request))
    db.commit()
    return Response(content=build_csv(_headers(analysis), rows), media_type="text/csv",
                    headers={"Content-Disposition":
                             f'attachment; filename="{_filename(user, "worksheet", "csv", centre)}"'})


@router.get("/visits.csv")
def export_visits(request: Request, centre: Optional[str] = None,
                  db: Session = Depends(get_db),
                  user: User = Depends(require_any(Perm.EXPORT_CENTRE, Perm.EXPORT_POOLED))):
    """Long format: one row per follow-up visit, for longitudinal modelling."""
    stmt = scoped_patients(user)
    patients = db.execute(stmt).scalars().all()
    centres = {c.id: c for c in db.execute(select(Centre)).scalars()}
    if centre:
        c = resolve_centre(db, user, centre)
        patients = [p for p in patients if p.centre_id == c.id]

    headers = ["Registry ID", "AHC", "Visit date", "Visit type", "ECOG", "On therapy", "Hb",
               "TLC", "ALC", "Platelet", "Creatinine", "Total protein", "Albumin", "IgM",
               "M band", "Beta2 MG", "Disease status", "Transfusion dependent",
               "New symptoms", "Notes", "Added after lock"]
    rows = []
    for p in sorted(patients, key=lambda x: x.registry_no):
        for v in sorted(p.visits, key=lambda x: x.visit_date):
            rows.append([p.registry_id, centres[p.centre_id].code, v.visit_date, v.visit_type,
                         v.ecog, _bool_word(v.on_therapy), v.hb, v.tlc, v.alc, v.platelets,
                         v.creatinine, v.total_protein, v.albumin, v.igm, v.m_band, v.beta2m,
                         v.disease_status, _bool_word(v.transfusion_dependent),
                         v.new_symptoms, v.notes, _bool_word(v.added_after_lock)])
    record(db, user=user, action="Exported follow-up visits", detail=f"{len(rows)} visits",
           ip=client_ip(request))
    db.commit()
    return Response(content=build_csv(headers, rows), media_type="text/csv",
                    headers={"Content-Disposition":
                             f'attachment; filename="{_filename(user, "visits", "csv", centre)}"'})


@router.get("/therapy-lines.csv")
def export_lines(request: Request, centre: Optional[str] = None,
                 db: Session = Depends(get_db),
                 user: User = Depends(require_any(Perm.EXPORT_CENTRE, Perm.EXPORT_POOLED))):
    patients = db.execute(scoped_patients(user)).scalars().all()
    centres = {c.id: c for c in db.execute(select(Centre)).scalars()}
    if centre:
        c = resolve_centre(db, user, centre)
        patients = [p for p in patients if p.centre_id == c.id]

    headers = ["Registry ID", "AHC", "Line", "Category", "Regimen", "Cycles", "Start", "End",
               "Best response", "Reason stopped", "Grade >=3 toxicity", "Toxicity detail",
               "Added after lock"]
    rows = []
    for p in sorted(patients, key=lambda x: x.registry_no):
        for l in sorted(p.therapy_lines, key=lambda x: x.line_no):
            rows.append([p.registry_id, centres[p.centre_id].code, l.line_no, l.category,
                         l.regimen, l.cycles, l.start_date, l.end_date, l.best_response,
                         l.stop_reason, _bool_word(l.grade3_toxicity), l.toxicity_detail,
                         _bool_word(l.added_after_lock)])
    record(db, user=user, action="Exported therapy lines", detail=f"{len(rows)} lines",
           ip=client_ip(request))
    db.commit()
    return Response(content=build_csv(headers, rows), media_type="text/csv",
                    headers={"Content-Disposition":
                             f'attachment; filename="{_filename(user, "therapy_lines", "csv", centre)}"'})
