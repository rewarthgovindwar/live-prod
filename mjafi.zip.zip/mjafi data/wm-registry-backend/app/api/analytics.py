"""Cohort analytics and survival curves, computed on the server.

Everything here respects the same scoping rule as the rest of the API, so a
centre's analytics cover only that centre and the national view covers only
records the centres have released to the pool.
"""
from __future__ import annotations

from collections import Counter
from datetime import date
from typing import Any, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import (current_user, get_db, is_national, require, require_any,
                          resolve_centre, scoped_patients)
from app.core.config import settings
from app.core.permissions import Perm
from app.models import Centre, DataQuery, Patient, User
from app.services import derive as D
from app.services.survival import kaplan_meier, logrank

router = APIRouter(prefix="/analytics", tags=["analytics"])

MIN_GROUP = 3   # do not publish a curve for a group this small


def _cohort(db: Session, user: User, centre_code: Optional[str]) -> list[Patient]:
    stmt = scoped_patients(user)
    if centre_code:
        c = resolve_centre(db, user, centre_code)
        stmt = stmt.where(Patient.centre_id == c.id)
    return db.execute(stmt).scalars().all()


def _median(xs: list[float]) -> Optional[float]:
    xs = sorted(x for x in xs if x is not None)
    if not xs:
        return None
    n = len(xs)
    return round(xs[n // 2] if n % 2 else (xs[n // 2 - 1] + xs[n // 2]) / 2, 1)


def _iqr(xs: list[float]) -> Optional[list[float]]:
    xs = sorted(x for x in xs if x is not None)
    if len(xs) < 4:
        return None
    q1 = xs[len(xs) // 4]
    q3 = xs[(3 * len(xs)) // 4]
    return [round(q1, 1), round(q3, 1)]


@router.get("/summary")
def summary(centre: Optional[str] = None, db: Session = Depends(get_db),
            user: User = Depends(require_any(Perm.ANALYTICS_CENTRE, Perm.ANALYTICS_NATIONAL))):
    """Headline cohort description."""
    patients = _cohort(db, user, centre)
    derived = [(p, D.derive_patient(p)) for p in patients]

    ages = [p.age for p, _ in derived if p.age is not None]
    igms = [p.igm for p, _ in derived if p.igm is not None]
    hbs = [p.hb for p, _ in derived if p.hb is not None]
    myd_tested = [p.myd88 for p, _ in derived if p.myd88 in ("Positive", "Negative")]

    os_pairs = [(d["os_months"], d["os_event"]) for _, d in derived]
    pfs_pairs = [(d["pfs_months"], d["pfs_event"]) for _, d in derived]

    today = date.today()
    overdue = sum(1 for p, _ in derived
                  if not p.death and p.last_followup_date
                  and (D.months_between(p.last_followup_date, today) or 0)
                  > settings.FOLLOWUP_OVERDUE_MONTHS)

    return {
        "scope": "national_pool" if is_national(user) and not centre else (centre or
                 (user.centre.code if user.centre else None)),
        "patients": len(patients),
        "centres_contributing": len({p.centre_id for p in patients}),
        "age": {"median": _median(ages), "iqr": _iqr(ages)},
        "sex": dict(Counter(p.gender for p, _ in derived if p.gender)),
        "igm_g_per_l": {"median": _median(igms), "iqr": _iqr(igms)},
        "haemoglobin": {"median": _median(hbs), "iqr": _iqr(hbs)},
        "myd88_positive_pct": (round(sum(1 for m in myd_tested if m == "Positive") * 100
                                     / len(myd_tested)) if myd_tested else None),
        "ipss_risk": dict(Counter(d["ipss_risk"] for _, d in derived if d["ipss_risk"])),
        "deaths": sum(1 for p, _ in derived if p.death),
        "progressions": sum(1 for p, _ in derived if p.relapse),
        "median_os_months": kaplan_meier(os_pairs).median,
        "median_pfs_months": kaplan_meier(pfs_pairs).median,
        "followup_overdue": overdue,
        "record_status": dict(Counter(p.status for p in patients)),
        "completeness_mean_pct": (round(sum(D.completeness(p)["percent"] for p in patients)
                                        / len(patients)) if patients else 0),
    }


@router.get("/survival")
def survival_curves(
    endpoint: str = Query("os", pattern="^(os|pfs)$"),
    stratify: Optional[str] = Query(None, pattern="^(ipss_risk|btki_ever|sex|myd88|centre|srsm)$"),
    centre: Optional[str] = None,
    db: Session = Depends(get_db),
    user: User = Depends(require_any(Perm.ANALYTICS_CENTRE, Perm.ANALYTICS_NATIONAL)),
):
    """Kaplan-Meier estimate with Greenwood confidence bands, and a log-rank test
    when the cohort is stratified."""
    patients = _cohort(db, user, centre)
    centres = {c.id: c.code for c in db.execute(select(Centre)).scalars()}

    def key(p: Patient, d: dict) -> Optional[str]:
        if stratify == "ipss_risk":
            return d["ipss_risk"]
        if stratify == "btki_ever":
            return {"Yes": "BTKi exposed", "No": "No BTKi"}.get(d["btki_ever"])
        if stratify == "sex":
            return p.gender
        if stratify == "myd88":
            return p.myd88 if p.myd88 in ("Positive", "Negative") else None
        if stratify == "srsm":
            return p.srsm_score
        if stratify == "centre":
            return centres.get(p.centre_id)
        return "All patients"

    buckets: dict[str, list[tuple[Optional[float], int]]] = {}
    for p in patients:
        d = D.derive_patient(p)
        k = key(p, d)
        if k is None:
            continue
        t = d["os_months"] if endpoint == "os" else d["pfs_months"]
        e = d["os_event"] if endpoint == "os" else d["pfs_event"]
        buckets.setdefault(k, []).append((t, e))

    order = {"Low": 0, "Intermediate": 1, "High": 2}
    names = sorted(buckets, key=lambda k: (order.get(k, 99), k))
    curves = [kaplan_meier(buckets[n], n).as_dict() for n in names if len(buckets[n]) >= MIN_GROUP]
    suppressed = [n for n in names if len(buckets[n]) < MIN_GROUP]

    test = None
    if stratify and len(curves) > 1:
        test = logrank([buckets[n] for n in names if len(buckets[n]) >= MIN_GROUP])

    return {
        "endpoint": "Overall survival from diagnosis" if endpoint == "os"
                    else "Progression-free survival from start of first-line therapy",
        "stratified_by": stratify,
        "curves": curves,
        "logrank": test,
        "suppressed_groups": suppressed,
        "note": (f"Groups with fewer than {MIN_GROUP} patients are not plotted."
                 if suppressed else None),
    }


@router.get("/distributions")
def distributions(centre: Optional[str] = None, db: Session = Depends(get_db),
                  user: User = Depends(require_any(Perm.ANALYTICS_CENTRE, Perm.ANALYTICS_NATIONAL))):
    """Counts for the bar charts: presenting features, therapy, response, accrual."""
    patients = _cohort(db, user, centre)
    derived = [(p, D.derive_patient(p)) for p in patients]

    symptom_fields = [("Anaemia symptoms", "sym_anaemia"), ("Constitutional", "constitutional"),
                      ("Lymphadenopathy", "lymphadenopathy"), ("Splenomegaly", "splenomegaly"),
                      ("Hyperviscosity", "hyperviscosity"), ("IgM-related symptoms", "igm_symptoms"),
                      ("Fever", "fever"), ("Bleeding", "bleeding")]

    def counts(values) -> dict:
        return dict(Counter(v for v in values if v))

    return {
        "n": len(patients),
        "presenting_features": {label: sum(1 for p, _ in derived if getattr(p, key) is True)
                                for label, key in symptom_fields},
        "ipss_risk": counts(d["ipss_risk"] for _, d in derived),
        "srsm_score": counts(p.srsm_score for p, _ in derived),
        "first_line_category": counts(d["l1_category"] for _, d in derived),
        "first_line_regimen": counts(d["l1_regimen"] for _, d in derived),
        "best_response": counts((d["l1_response"] or "").split(" —")[0] or None for _, d in derived),
        "myd88": counts(p.myd88 for p, _ in derived),
        "lines_of_therapy": counts(str(d["total_lines"]) for _, d in derived),
        "year_of_diagnosis": dict(sorted(counts(d["dx_year"] for _, d in derived).items())),
        "cause_of_death": counts(p.death_cause for p, _ in derived if p.death),
    }


@router.get("/centres")
def centre_scorecard(db: Session = Depends(get_db),
                     user: User = Depends(require(Perm.ANALYTICS_NATIONAL))):
    """Accrual and data-quality per centre. National coordinator only.

    Aggregates only — this endpoint never returns a patient-level row, so the
    national view can compare centres without seeing another centre's records.
    """
    centres = db.execute(select(Centre).order_by(Centre.code)).scalars().all()
    all_patients = db.execute(select(Patient)).scalars().all()
    by_centre: dict[Any, list[Patient]] = {}
    for p in all_patients:
        by_centre.setdefault(p.centre_id, []).append(p)

    open_q = dict(db.execute(
        select(DataQuery.centre_id, func.count()).where(DataQuery.status == "OPEN")
        .group_by(DataQuery.centre_id)).all())

    today = date.today()
    out = []
    for c in centres:
        rows = by_centre.get(c.id, [])
        pooled = [p for p in rows if p.status in ("VERIFIED", "APPROVED")]
        derived = [D.derive_patient(p) for p in pooled]
        out.append({
            "code": c.code, "name": c.name, "city": c.city, "zone": c.zone,
            "registered": len(rows),
            "released_to_pool": len(pooled),
            "completeness_pct": (round(sum(D.completeness(p)["percent"] for p in rows) / len(rows))
                                 if rows else 0),
            "open_queries": open_q.get(c.id, 0),
            "followup_overdue": sum(
                1 for p in rows if not p.death and p.last_followup_date
                and (D.months_between(p.last_followup_date, today) or 0) > settings.FOLLOWUP_OVERDUE_MONTHS),
            "median_os_months": kaplan_meier([(d["os_months"], d["os_event"]) for d in derived]).median,
            "median_pfs_months": kaplan_meier([(d["pfs_months"], d["pfs_event"]) for d in derived]).median,
            "deaths": sum(1 for p in pooled if p.death),
        })
    return {"centres": out, "total_registered": len(all_patients)}


@router.get("/followup-due")
def followup_due(centre: Optional[str] = None, db: Session = Depends(get_db),
                 user: User = Depends(current_user)):
    """Living patients ordered by time since last recorded contact."""
    patients = _cohort(db, user, centre)
    centres = {c.id: c.code for c in db.execute(select(Centre)).scalars()}
    today = date.today()
    rows = []
    for p in patients:
        if p.death:
            continue
        gap = D.months_between(p.last_followup_date, today)
        if gap is None:
            continue
        last_visit = max((v.visit_date for v in p.visits), default=None)
        rows.append({
            "id": str(p.id), "registry_id": p.registry_id, "centre": centres[p.centre_id],
            "age": p.age, "gender": p.gender,
            "last_followup_date": p.last_followup_date,
            "months_since": gap,
            "visits_recorded": len(p.visits),
            "last_visit_date": last_visit,
            "last_disease_status": next((v.disease_status for v in
                                         sorted(p.visits, key=lambda x: x.visit_date, reverse=True)), None),
            "status": p.status,
            "band": ("overdue" if gap > settings.FOLLOWUP_OVERDUE_MONTHS
                     else "due" if gap > settings.FOLLOWUP_DUE_MONTHS else "current"),
        })
    rows.sort(key=lambda r: r["months_since"], reverse=True)
    return {"items": rows,
            "counts": dict(Counter(r["band"] for r in rows))}
