"""Request dependencies: authentication, permission gates and centre scoping.

``scoped_patients()`` is the only sanctioned way to reach patient rows. Every
route uses it, and PostgreSQL row-level security backs it up.
"""
from __future__ import annotations

import uuid
from typing import Iterator, Optional

import jwt
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import Select, select
from sqlalchemy.orm import Session

from app.core.permissions import POOLED_STATUSES, Perm, Role, has
from app.core.security import decode_access_token
from app.db import SessionLocal, set_rls_context
from app.models import Centre, FollowupVisit, Patient, TherapyLine, User

bearer = HTTPBearer(auto_error=False)


def get_db(request: Request) -> Iterator[Session]:
    db = SessionLocal()
    try:
        request.state.db = db
        yield db
    finally:
        db.close()


def _unauthorised(detail: str = "Not authenticated") -> HTTPException:
    return HTTPException(status.HTTP_401_UNAUTHORIZED, detail,
                         headers={"WWW-Authenticate": "Bearer"})


def current_user(request: Request,
                 creds: Optional[HTTPAuthorizationCredentials] = Depends(bearer),
                 db: Session = Depends(get_db)) -> User:
    if creds is None or not creds.credentials:
        raise _unauthorised()
    try:
        payload = decode_access_token(creds.credentials)
    except jwt.ExpiredSignatureError:
        raise _unauthorised("Session expired — please sign in again")
    except jwt.InvalidTokenError:
        raise _unauthorised("Invalid credentials")

    user = db.get(User, uuid.UUID(payload["sub"]))
    if user is None or not user.is_active:
        raise _unauthorised("Account is inactive")

    # A password change invalidates every token issued before it.
    if payload.get("tv") != token_version(user):
        raise _unauthorised("Credentials have changed — please sign in again")

    # Bind identity to the transaction so row-level security applies.
    set_rls_context(db, user_id=str(user.id), centre_id=str(user.centre_id) if user.centre_id else None,
                    national=(user.role == Role.IMAGE.value))
    request.state.user = user
    return user


def token_version(user: User) -> str:
    """Changes whenever the password changes, invalidating outstanding tokens."""
    stamp = user.password_changed_at.isoformat() if user.password_changed_at else "initial"
    return str(abs(hash((str(user.id), stamp))) % (10 ** 12))


def require(*perms: Perm):
    """Route guard: the caller must hold every listed permission."""
    def _dep(user: User = Depends(current_user)) -> User:
        missing = [p.value for p in perms if not has(user.role, p)]
        if missing:
            raise HTTPException(
                status.HTTP_403_FORBIDDEN,
                f"Your role ({user.role}) does not permit this action "
                f"(requires: {', '.join(missing)})")
        return user
    return _dep


def require_any(*perms: Perm):
    def _dep(user: User = Depends(current_user)) -> User:
        if not any(has(user.role, p) for p in perms):
            raise HTTPException(status.HTTP_403_FORBIDDEN,
                                f"Your role ({user.role}) does not permit this action")
        return user
    return _dep


# --------------------------------------------------------------------------- scoping
def is_national(user: User) -> bool:
    return has(user.role, Perm.VIEW_ALL)


def scoped_patients(user: User) -> Select:
    """Base SELECT restricted to what this user is permitted to see.

    * Centre staff see every record belonging to their own centre.
    * The national representative sees only records a centre has released to the
      pool (verified or approved) - drafts and queried records stay private to
      the owning centre until the centre stands behind them.
    """
    stmt = select(Patient)
    if is_national(user):
        return stmt.where(Patient.status.in_([s.value for s in POOLED_STATUSES]))
    return stmt.where(Patient.centre_id == user.centre_id)


def scoped_lines(user: User) -> Select:
    stmt = select(TherapyLine).join(Patient, TherapyLine.patient_id == Patient.id)
    if is_national(user):
        return stmt.where(Patient.status.in_([s.value for s in POOLED_STATUSES]))
    return stmt.where(TherapyLine.centre_id == user.centre_id)


def scoped_visits(user: User) -> Select:
    stmt = select(FollowupVisit).join(Patient, FollowupVisit.patient_id == Patient.id)
    if is_national(user):
        return stmt.where(Patient.status.in_([s.value for s in POOLED_STATUSES]))
    return stmt.where(FollowupVisit.centre_id == user.centre_id)


def get_patient_or_404(db: Session, user: User, patient_id: uuid.UUID) -> Patient:
    """Fetch a patient the user is allowed to see.

    A record belonging to another centre is reported as 404, never 403: a 403
    would confirm that a given identifier exists somewhere in the registry,
    which is itself a small disclosure across centres.
    """
    patient = db.execute(scoped_patients(user).where(Patient.id == patient_id)).scalar_one_or_none()
    if patient is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Record not found")
    return patient


def get_writable_patient(db: Session, user: User, patient_id: uuid.UUID) -> Patient:
    """As above, but refuses records the user may only read."""
    patient = get_patient_or_404(db, user, patient_id)
    if is_national(user):
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            "The national coordinator cannot modify a centre's data. "
            "Raise a data query with the owning centre instead.")
    if patient.centre_id != user.centre_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Record not found")
    return patient


def resolve_centre(db: Session, user: User, centre_code: Optional[str]) -> Optional[Centre]:
    """Validate an optional centre filter against what the user may see."""
    if not centre_code:
        return None
    centre = db.execute(select(Centre).where(Centre.code == centre_code)).scalar_one_or_none()
    if centre is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Unknown centre")
    if not is_national(user) and centre.id != user.centre_id:
        raise HTTPException(status.HTTP_403_FORBIDDEN,
                            "You may only work with your own centre's data")
    return centre


def client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else "unknown"
