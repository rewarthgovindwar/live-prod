"""IMAGe WM Registry — application entry point."""
from __future__ import annotations

import logging
import time
import uuid

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text

from app.api import admin, analytics, auth, exports, imports, patients
from app.core.config import settings
from app.db import engine

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s %(message)s')
log = logging.getLogger("wm-registry")

DESCRIPTION = """
Backend for the IMAGe multicentric registry of Waldenström macroglobulinemia.

**Centre isolation.** Every patient row belongs to exactly one participating
centre. Requests are scoped in the application layer and again by PostgreSQL
row-level security, so a centre cannot reach another centre's records even if an
endpoint is written incorrectly. The national coordinator sees the pooled
dataset for analysis but cannot alter a centre's values — corrections travel
back as data queries.

**Derived values.** Year of diagnosis, elevated LDH, the IgM threshold flag, the
SFLC ratio, the IPSS-WM score and risk group, total lines of therapy, BTK
inhibitor exposure, the event indicator, PFS and OS are all computed here from
the stored primary data. They are never accepted from a client.
"""

app = FastAPI(
    title=settings.APP_NAME,
    description=DESCRIPTION,
    version="1.0.0",
    docs_url="/docs" if not settings.is_production else None,
    redoc_url="/redoc" if not settings.is_production else None,
    openapi_url="/openapi.json" if not settings.is_production else None,
)

app.add_middleware(GZipMiddleware, minimum_size=1024)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
    expose_headers=["Content-Disposition", "X-Request-ID"],
)


@app.middleware("http")
async def request_context(request: Request, call_next):
    rid = request.headers.get("x-request-id") or uuid.uuid4().hex[:12]
    started = time.perf_counter()
    response = await call_next(request)
    ms = (time.perf_counter() - started) * 1000
    response.headers["X-Request-ID"] = rid
    # Hardening headers; TLS termination and HSTS belong to the reverse proxy.
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Cache-Control"] = "no-store"
    log.info("%s %s %s %s %.1fms", rid, request.method, request.url.path,
             response.status_code, ms)
    return response


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    """Return field-level problems in the same shape the registry uses elsewhere."""
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"detail": {"message": "The request could not be accepted",
                            "errors": [{"field": ".".join(str(x) for x in e["loc"][1:]),
                                        "level": "error", "message": e["msg"]}
                                       for e in exc.errors()]}},
    )


@app.get("/health", tags=["operations"])
def health():
    """Liveness and database reachability, for the reverse proxy and monitoring."""
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        db_ok = True
    except Exception as exc:                                    # noqa: BLE001
        log.error("health check: database unreachable: %s", exc)
        db_ok = False
    return JSONResponse(
        status_code=200 if db_ok else 503,
        content={"status": "ok" if db_ok else "degraded", "database": db_ok,
                 "environment": settings.ENVIRONMENT, "version": app.version},
    )


api = settings.API_PREFIX
app.include_router(auth.router, prefix=api)
app.include_router(patients.router, prefix=api)
app.include_router(imports.router, prefix=api)
app.include_router(exports.router, prefix=api)
app.include_router(analytics.router, prefix=api)
app.include_router(admin.router, prefix=api)


@app.on_event("startup")
def on_startup():
    log.info("%s starting in %s mode", settings.APP_NAME, settings.ENVIRONMENT)
    if not settings.is_production:
        log.info("API documentation at /docs")
