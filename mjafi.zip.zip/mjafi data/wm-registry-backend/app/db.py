"""Database engine, session factory and the row-level-security context.

Centre isolation is enforced in two independent layers:

1. Application layer  - every query goes through ``scoped()`` in app/api/deps.py.
2. Database layer     - PostgreSQL row-level security policies compare each row's
                        ``centre_id`` with ``current_setting('app.centre_id')``,
                        which this module sets for the life of each transaction.

Layer 2 exists precisely because layer 1 is written by humans. If a future
endpoint forgets the filter, PostgreSQL still returns nothing.
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator, Optional

from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import settings

engine = create_engine(
    settings.DATABASE_URL,
    pool_size=settings.DB_POOL_SIZE,
    max_overflow=settings.DB_MAX_OVERFLOW,
    pool_pre_ping=True,
    echo=settings.DB_ECHO,
    future=True,
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False, future=True)


def _apply(conn, ctx: dict) -> None:
    conn.execute(text("SELECT set_config('app.user_id', :v, true)"), {"v": ctx["user_id"]})
    conn.execute(text("SELECT set_config('app.centre_id', :v, true)"), {"v": ctx["centre_id"]})
    conn.execute(text("SELECT set_config('app.national', :v, true)"), {"v": ctx["national"]})


@event.listens_for(Session, "after_begin")
def _reapply_rls(session: Session, transaction, connection) -> None:
    """Re-apply the identity whenever a new transaction starts.

    ``set_config(..., true)`` is transaction-local, which is what makes a pooled
    connection safe: the next request can never inherit the previous user's
    context. The consequence is that a commit inside a request would otherwise
    drop the context, so it is re-applied here on every BEGIN.
    """
    ctx = session.info.get("rls")
    if ctx:
        _apply(connection, ctx)


def set_rls_context(db: Session, *, user_id: Optional[str], centre_id: Optional[str],
                    national: bool) -> None:
    """Bind the current identity to this session for the rest of the request."""
    ctx = {
        "user_id": str(user_id) if user_id else "",
        "centre_id": str(centre_id) if centre_id else "",
        "national": "on" if national else "off",
    }
    db.info["rls"] = ctx
    _apply(db.connection(), ctx)     # apply to the transaction already in flight


def clear_rls_context(db: Session) -> None:
    db.info.pop("rls", None)
    set_rls_context(db, user_id=None, centre_id=None, national=False)


@contextmanager
def session_scope(*, user_id: Optional[str] = None, centre_id: Optional[str] = None,
                  national: bool = False) -> Iterator[Session]:
    """Transactional scope for scripts and background jobs."""
    db = SessionLocal()
    try:
        set_rls_context(db, user_id=user_id, centre_id=centre_id, national=national)
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
