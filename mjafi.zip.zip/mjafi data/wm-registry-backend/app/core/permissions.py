"""Role and workflow permission model.

This is the single source of truth. The front-end mirrors it for convenience,
but every decision is re-taken here on the server; nothing is trusted from the
client. ``GET /api/v1/meta/roles`` serves this table so the two cannot drift.
"""
from __future__ import annotations

from enum import Enum
from typing import Optional


class Role(str, Enum):
    DEO = "DEO"
    CLIN = "CLIN"
    HOD = "HOD"
    IMAGE = "IMAGE"


class Status(str, Enum):
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"
    QUERY = "QUERY"
    VERIFIED = "VERIFIED"
    APPROVED = "APPROVED"


class Perm(str, Enum):
    VIEW_OWN = "view_own"
    VIEW_ALL = "view_all"
    CREATE = "create"
    EDIT_BASELINE = "edit_baseline"      # frames 1-6 of the CRF
    EDIT_FOLLOWUP = "edit_followup"      # therapy lines, visits, outcome
    SUBMIT = "submit"
    VERIFY = "verify"
    APPROVE = "approve"
    UNLOCK = "unlock"
    RETURN_TO_DEO = "return_to_deo"
    RAISE_QUERY = "raise_query"
    RESOLVE_QUERY = "resolve_query"
    BULK_IMPORT = "bulk_import"
    EXPORT_CENTRE = "export_centre"
    EXPORT_POOLED = "export_pooled"
    ANALYTICS_CENTRE = "analytics_centre"
    ANALYTICS_NATIONAL = "analytics_national"
    MANAGE_CENTRE_USERS = "manage_centre_users"
    MANAGE_CENTRES = "manage_centres"
    VIEW_AUDIT = "view_audit"


ROLE_PERMISSIONS: dict[Role, set[Perm]] = {
    Role.DEO: {
        Perm.VIEW_OWN, Perm.CREATE, Perm.EDIT_BASELINE, Perm.EDIT_FOLLOWUP,
        Perm.SUBMIT, Perm.RESOLVE_QUERY, Perm.BULK_IMPORT, Perm.VIEW_AUDIT,
    },
    Role.CLIN: {
        Perm.VIEW_OWN, Perm.CREATE, Perm.EDIT_BASELINE, Perm.EDIT_FOLLOWUP,
        Perm.SUBMIT, Perm.VERIFY, Perm.RETURN_TO_DEO, Perm.RAISE_QUERY,
        Perm.RESOLVE_QUERY, Perm.BULK_IMPORT, Perm.ANALYTICS_CENTRE, Perm.VIEW_AUDIT,
    },
    Role.HOD: {
        Perm.VIEW_OWN, Perm.CREATE, Perm.EDIT_BASELINE, Perm.EDIT_FOLLOWUP,
        Perm.SUBMIT, Perm.VERIFY, Perm.APPROVE, Perm.UNLOCK, Perm.RETURN_TO_DEO,
        Perm.RAISE_QUERY, Perm.RESOLVE_QUERY, Perm.BULK_IMPORT,
        Perm.EXPORT_CENTRE, Perm.ANALYTICS_CENTRE, Perm.MANAGE_CENTRE_USERS, Perm.VIEW_AUDIT,
    },
    Role.IMAGE: {
        # Deliberately no edit, no create, no approve. The national coordinator
        # can read the pool and query a centre, but never change a centre's data.
        Perm.VIEW_ALL, Perm.RAISE_QUERY, Perm.EXPORT_CENTRE, Perm.EXPORT_POOLED,
        Perm.ANALYTICS_CENTRE, Perm.ANALYTICS_NATIONAL, Perm.MANAGE_CENTRES, Perm.VIEW_AUDIT,
    },
}

# Statuses whose records are released to the national pool.
POOLED_STATUSES = {Status.VERIFIED, Status.APPROVED}

# Allowed workflow transitions: (from status) -> {to status: permission required}
TRANSITIONS: dict[Status, dict[Status, Perm]] = {
    Status.DRAFT:     {Status.SUBMITTED: Perm.SUBMIT},
    Status.SUBMITTED: {Status.VERIFIED: Perm.VERIFY,
                       Status.DRAFT: Perm.RETURN_TO_DEO,
                       Status.QUERY: Perm.RAISE_QUERY},
    Status.QUERY:     {Status.SUBMITTED: Perm.RESOLVE_QUERY,
                       Status.VERIFIED: Perm.VERIFY,
                       Status.DRAFT: Perm.RETURN_TO_DEO},
    Status.VERIFIED:  {Status.APPROVED: Perm.APPROVE,
                       Status.DRAFT: Perm.RETURN_TO_DEO,
                       Status.QUERY: Perm.RAISE_QUERY},
    Status.APPROVED:  {Status.VERIFIED: Perm.UNLOCK},
}


def has(role: Role | str, perm: Perm) -> bool:
    try:
        return perm in ROLE_PERMISSIONS[Role(role)]
    except (KeyError, ValueError):
        return False


def can_transition(role: Role | str, frm: Status | str, to: Status | str) -> tuple[bool, Optional[str]]:
    try:
        frm_s, to_s = Status(frm), Status(to)
    except ValueError:
        return False, "unknown status"
    allowed = TRANSITIONS.get(frm_s, {})
    if to_s not in allowed:
        return False, f"a record in '{frm_s.value}' cannot move to '{to_s.value}'"
    if not has(role, allowed[to_s]):
        return False, f"your role is not permitted to perform this transition"
    return True, None


def baseline_editable(role: Role | str, status: Status | str) -> bool:
    """Frames 1-6. Frozen once the HoD approves, unless the user can unlock."""
    if not has(role, Perm.EDIT_BASELINE):
        return False
    if Status(status) is Status.APPROVED:
        return has(role, Perm.UNLOCK)
    return True


def followup_editable(role: Role | str, status: Status | str) -> bool:
    """Therapy lines, follow-up visits and outcome.

    A registry is longitudinal: locking the baseline must not stop the centre
    recording what happened next. So follow-up stays open after approval to
    anyone holding EDIT_FOLLOWUP, and each such change is marked as an
    amendment and flagged to the Head of Department.
    """
    return has(role, Perm.EDIT_FOLLOWUP)


def as_dict() -> dict:
    """Serialisable permission matrix for the /meta/roles endpoint."""
    return {
        "roles": {
            r.value: {
                "permissions": sorted(p.value for p in perms),
                "scope": "all_centres" if Perm.VIEW_ALL in perms else "own_centre",
            }
            for r, perms in ROLE_PERMISSIONS.items()
        },
        "transitions": {
            frm.value: {to.value: perm.value for to, perm in tos.items()}
            for frm, tos in TRANSITIONS.items()
        },
        "pooled_statuses": sorted(s.value for s in POOLED_STATUSES),
    }
