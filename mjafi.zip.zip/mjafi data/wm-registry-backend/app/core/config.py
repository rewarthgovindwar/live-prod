"""Application configuration.

Every deployment-specific value is read from the environment so the same image
can run on a hospital server, a state data centre or a cloud VM without change.
"""
from functools import lru_cache
from typing import List

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- identity -----------------------------------------------------------
    APP_NAME: str = "IMAGe WM Registry API"
    ENVIRONMENT: str = "development"          # development | staging | production
    API_PREFIX: str = "/api/v1"

    # --- database -----------------------------------------------------------
    # The application connects as an UNPRIVILEGED role so PostgreSQL row-level
    # security actually applies to it. Migrations run as the owner role.
    DATABASE_URL: str = "postgresql+psycopg://wm_app:change-me@localhost:5432/wm_registry"
    MIGRATION_DATABASE_URL: str = "postgresql+psycopg://wm_owner:change-me@localhost:5432/wm_registry"
    DB_POOL_SIZE: int = 10
    DB_MAX_OVERFLOW: int = 20
    DB_ECHO: bool = False

    # --- security -----------------------------------------------------------
    SECRET_KEY: str = Field(default="dev-only-secret-change-in-production", min_length=16)
    ACCESS_TOKEN_MINUTES: int = 20             # short: clinical data
    REFRESH_TOKEN_DAYS: int = 7
    REQUIRE_2FA_FOR_ROLES: List[str] = ["HOD", "IMAGE"]
    MAX_FAILED_LOGINS: int = 5
    LOCKOUT_MINUTES: int = 30
    PASSWORD_MIN_LENGTH: int = 12
    CORS_ORIGINS: List[str] = ["http://localhost:5173", "http://localhost:8080"]

    # --- registry rules -----------------------------------------------------
    LDH_UPPER_LIMIT: float = 250.0             # local laboratory ULN, U/L
    IGM_FLAG_THRESHOLD: float = 7.5            # g/L, worksheet column AI
    FOLLOWUP_DUE_MONTHS: int = 6
    FOLLOWUP_OVERDUE_MONTHS: int = 12
    MAX_IMPORT_ROWS: int = 5000
    MAX_UPLOAD_BYTES: int = 15 * 1024 * 1024

    @field_validator("CORS_ORIGINS", "REQUIRE_2FA_FOR_ROLES", mode="before")
    @classmethod
    def _split(cls, v):
        if isinstance(v, str):
            return [x.strip() for x in v.split(",") if x.strip()]
        return v

    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT.lower() == "production"


@lru_cache
def get_settings() -> Settings:
    s = Settings()
    if s.is_production and s.SECRET_KEY.startswith("dev-only"):
        raise RuntimeError("SECRET_KEY must be set to a strong random value in production")
    return s


settings = get_settings()
