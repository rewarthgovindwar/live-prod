"""Password hashing, JWT issue/verify, TOTP second factor."""
from __future__ import annotations

import hashlib
import hmac
import re
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import jwt
import pyotp
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerifyMismatchError

from app.core.config import settings

# Argon2id with parameters suited to a small server: ~64 MB, 3 passes.
_ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=2, hash_len=32, salt_len=16)

ALGORITHM = "HS256"


# --------------------------------------------------------------------------- passwords
def hash_password(plain: str) -> str:
    return _ph.hash(plain)


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return _ph.verify(hashed, plain)
    except (VerifyMismatchError, InvalidHashError, ValueError):
        return False


def needs_rehash(hashed: str) -> bool:
    try:
        return _ph.check_needs_rehash(hashed)
    except InvalidHashError:
        return True


COMMON_PASSWORDS = {
    "password", "password123", "12345678", "qwertyuiop", "administrator",
    "welcome123", "registry123", "hospital123", "myeloma123", "changeme123",
}


def validate_password_strength(pw: str, email: str = "") -> list[str]:
    """Return a list of problems; empty list means the password is acceptable."""
    problems: list[str] = []
    if len(pw) < settings.PASSWORD_MIN_LENGTH:
        problems.append(f"must be at least {settings.PASSWORD_MIN_LENGTH} characters")
    if not re.search(r"[a-z]", pw):
        problems.append("must contain a lower-case letter")
    if not re.search(r"[A-Z]", pw):
        problems.append("must contain an upper-case letter")
    if not re.search(r"\d", pw):
        problems.append("must contain a digit")
    if not re.search(r"[^A-Za-z0-9]", pw):
        problems.append("must contain a symbol")
    if pw.lower() in COMMON_PASSWORDS:
        problems.append("is too common")
    if email and email.split("@")[0].lower() in pw.lower():
        problems.append("must not contain your username")
    return problems


# --------------------------------------------------------------------------- JWT
def _now() -> datetime:
    return datetime.now(timezone.utc)


def create_access_token(*, user_id: uuid.UUID, role: str, centre_id: Optional[uuid.UUID],
                        centre_code: Optional[str], token_version: str) -> str:
    now = _now()
    payload: dict[str, Any] = {
        "sub": str(user_id),
        "role": role,
        "cid": str(centre_id) if centre_id else None,
        "centre": centre_code,
        "tv": token_version,
        "typ": "access",
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=settings.ACCESS_TOKEN_MINUTES)).timestamp()),
        "jti": secrets.token_hex(8),
    }
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=ALGORITHM)


def decode_access_token(token: str) -> dict:
    payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[ALGORITHM])
    if payload.get("typ") != "access":
        raise jwt.InvalidTokenError("wrong token type")
    return payload


def new_refresh_token() -> tuple[str, str]:
    """Return (opaque token given to the client, sha256 hash stored in the database)."""
    raw = secrets.token_urlsafe(48)
    return raw, hash_refresh_token(raw)


def hash_refresh_token(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()


def constant_time_equals(a: str, b: str) -> bool:
    return hmac.compare_digest(a, b)


# --------------------------------------------------------------------------- TOTP
def new_totp_secret() -> str:
    return pyotp.random_base32()


def totp_provisioning_uri(secret: str, email: str) -> str:
    return pyotp.TOTP(secret).provisioning_uri(name=email, issuer_name="IMAGe WM Registry")


def verify_totp(secret: str, code: str) -> bool:
    if not secret or not code:
        return False
    # one step of drift either way tolerates modest clock skew on hospital PCs
    return pyotp.TOTP(secret).verify(code.strip().replace(" ", ""), valid_window=1)
