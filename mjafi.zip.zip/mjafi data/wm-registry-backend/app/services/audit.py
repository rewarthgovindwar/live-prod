"""Append-only audit trail.

Regulatory expectation for a clinical registry: who changed what, when, from
where, and what the value was before. Every mutating route calls ``record()``.
"""
from __future__ import annotations

import uuid
from typing import Any, Optional

from sqlalchemy.orm import Session

from app.models import AuditLog, Patient, User

# Values never written to the audit trail even if they change.
_REDACT = {"password", "password_hash", "totp_secret", "token_hash"}


def diff(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    """Field-level change set, with dates and UUIDs rendered as strings."""
    out: dict[str, Any] = {}
    for key in set(before) | set(after):
        if key in _REDACT:
            continue
        b, a = before.get(key), after.get(key)
        if b != a:
            out[key] = {"from": _plain(b), "to": _plain(a)}
    return out


def _plain(v: Any) -> Any:
    if v is None or isinstance(v, (str, int, float, bool)):
        return v
    return str(v)


def snapshot(obj: Any, keys: Optional[set[str]] = None) -> dict[str, Any]:
    if obj is None:
        return {}
    cols = {c.name for c in obj.__table__.columns}
    if keys:
        cols &= keys
    return {c: _plain(getattr(obj, c)) for c in cols}


def record(db: Session, *, user: Optional[User], action: str,
           entity_type: Optional[str] = None, entity_id: Optional[Any] = None,
           patient: Optional[Patient] = None, registry_id: Optional[str] = None,
           changes: Optional[dict] = None, detail: Optional[str] = None,
           ip: Optional[str] = None, user_agent: Optional[str] = None,
           centre_code: Optional[str] = None) -> AuditLog:
    entry = AuditLog(
        user_id=user.id if user else None,
        user_name=user.full_name if user else None,
        user_role=user.role if user else None,
        centre_code=centre_code or (user.centre.code if user and user.centre else
                                    ("NATIONAL" if user else None)),
        action=action,
        entity_type=entity_type,
        entity_id=str(entity_id) if entity_id else None,
        registry_id=registry_id or (patient.registry_id if patient else None),
        ip=ip, user_agent=(user_agent or "")[:300] or None,
        changes=changes or None, detail=detail,
    )
    db.add(entry)
    return entry
