"""Excel and CSV reading/writing for bulk import, export and templates."""
from __future__ import annotations

import csv
import io
import re
from datetime import date, datetime
from typing import Any, Iterable, Optional

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from app.services.dictionary import (PATIENT_FIELDS, WORKSHEET_ORDER, Field, REGIMENS)


def _squash(s: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


#: heading (squashed) -> field key. Built from the exact worksheet headings plus
#: the aliases declared in the data dictionary, so a centre's own copy of the
#: IMAGe worksheet maps with no manual intervention.
HEADER_INDEX: dict[str, str] = {}
for _f in PATIENT_FIELDS:
    HEADER_INDEX.setdefault(_squash(_f.label), _f.key)
    for _a in _f.aliases:
        HEADER_INDEX.setdefault(_squash(_a), _f.key)
    HEADER_INDEX.setdefault(_squash(_f.key), _f.key)

#: Fields a client may map an import column onto (derived columns are ignored).
IMPORTABLE: list[Field] = [f for f in PATIENT_FIELDS if f.type != "derived"]
IMPORTABLE_KEYS = {f.key for f in IMPORTABLE}


def read_tabular(data: bytes, filename: str) -> tuple[list[list[Any]], str]:
    """Return (rows, sheet name). Row 0 is the heading row."""
    if filename.lower().endswith(".csv"):
        text = data.decode("utf-8-sig", errors="replace")
        rows = [r for r in csv.reader(io.StringIO(text))]
        return [r for r in rows if any(str(c).strip() for c in r)], "CSV"

    wb = load_workbook(io.BytesIO(data), data_only=True, read_only=True)
    ws = wb[wb.sheetnames[0]]
    rows: list[list[Any]] = []
    for row in ws.iter_rows(values_only=True):
        values = list(row)
        if any(v is not None and str(v).strip() != "" for v in values):
            rows.append(values)
    name = ws.title
    wb.close()
    return rows, name


def auto_map(headers: Iterable[Any]) -> tuple[dict[str, str], list[str]]:
    """Map file columns onto registry fields. Returns (mapping, unmapped headings).

    ``mapping`` is keyed by the column index as a string so it survives JSON.
    """
    mapping: dict[str, str] = {}
    unmapped: list[str] = []
    taken: set[str] = set()
    for i, h in enumerate(headers):
        key = HEADER_INDEX.get(_squash(h))
        if key and key in IMPORTABLE_KEYS and key not in taken and key != "centre_code":
            mapping[str(i)] = key
            taken.add(key)
        else:
            unmapped.append(str(h) if h is not None else "")
    return mapping, unmapped


# --------------------------------------------------------------------------- writing
_HEAD_FILL = PatternFill("solid", fgColor="4A1A24")
_HEAD_FONT = Font(color="FFFFFF", bold=True, size=10)
_NOTE_FILL = PatternFill("solid", fgColor="F9EFD8")
_NOTE_FONT = Font(color="7A5A12", italic=True, size=9)


def _cell(v: Any) -> Any:
    if isinstance(v, (datetime,)):
        return v.date()
    return v


def build_workbook(sheet_name: str, headers: list[str], rows: list[list[Any]],
                   note_row: Optional[list[str]] = None,
                   freeze: str = "A2") -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name[:31]

    ws.append(headers)
    for c in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill = _HEAD_FILL
        cell.font = _HEAD_FONT
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 34

    if note_row:
        ws.append(note_row)
        for c in range(1, len(headers) + 1):
            cell = ws.cell(row=2, column=c)
            cell.fill = _NOTE_FILL
            cell.font = _NOTE_FONT
            cell.alignment = Alignment(vertical="top", wrap_text=True)
        ws.row_dimensions[2].height = 30
        freeze = "A3"

    for r in rows:
        ws.append([_cell(v) for v in r])

    for i, h in enumerate(headers, start=1):
        width = min(38, max(11, len(str(h)) + 2))
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.freeze_panes = freeze

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def build_csv(headers: list[str], rows: list[list[Any]]) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(headers)
    for r in rows:
        w.writerow(["" if v is None else (v.isoformat() if isinstance(v, (date, datetime)) else v)
                    for v in r])
    return buf.getvalue().encode("utf-8-sig")


def template_rows() -> tuple[list[str], list[str]]:
    """Headings in worksheet order plus a guidance row of permitted values."""
    headers = [f.label for f in WORKSHEET_ORDER]
    notes = []
    for f in WORKSHEET_ORDER:
        if f.type == "derived":
            notes.append("calculated by the registry — leave blank")
        elif f.type == "bool":
            notes.append("Yes / No")
        elif f.type == "enum":
            choices = f.choices or []
            shown = " | ".join(choices[:4]) + (" | …" if len(choices) > 4 else "")
            notes.append(shown)
        elif f.type in ("int", "float"):
            notes.append(f"number {f.minimum}–{f.maximum}" + (f" {f.unit}" if f.unit else ""))
        elif f.type == "date":
            notes.append("DD/MM/YYYY")
        else:
            notes.append("free text")
    return headers, notes
