"""Field coercion and clinical range checking.

The registry uses a two-tier rule, matching how data entry actually works in a
busy haematology unit:

* HARD errors  - the value cannot be stored (wrong type, impossible date,
                 outside the physically possible range). The write is refused.
* SOFT warnings - the value is storable but outside the usual clinical range.
                 It is saved and returned to the caller as a warning so the
                 operator can confirm it against the source document.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field as dc_field
from datetime import date, datetime, timedelta
from typing import Any, Optional

from app.services.dictionary import Field

TRUE_WORDS = {"y", "yes", "true", "1", "present", "positive", "reactive"}
FALSE_WORDS = {"n", "no", "false", "0", "absent", "negative", "nil"}
BLANK_WORDS = {"", "na", "n/a", "nil", "-", "--", "nd", "not done", "unknown", "?", "none"}

EXCEL_EPOCH = date(1899, 12, 30)   # Excel's 1900 system, including its leap-year bug


@dataclass
class Issue:
    field: str
    column: Optional[str]
    level: str          # "error" | "warning"
    message: str

    def as_dict(self) -> dict:
        return {"field": self.field, "column": self.column,
                "level": self.level, "message": self.message}


@dataclass
class Coerced:
    value: Any = None
    issues: list[Issue] = dc_field(default_factory=list)

    @property
    def failed(self) -> bool:
        return any(i.level == "error" for i in self.issues)


def _issue(f: Field, level: str, msg: str) -> Issue:
    return Issue(f.label, f.col, level, msg)


def parse_date(raw: Any) -> Optional[date]:
    """Accept ISO, DD/MM/YYYY, DD-MM-YYYY, Excel serials and datetime objects."""
    if raw is None or raw == "":
        return None
    if isinstance(raw, datetime):
        return raw.date()
    if isinstance(raw, date):
        return raw
    if isinstance(raw, (int, float)) and 1000 < float(raw) < 80000:
        return EXCEL_EPOCH + timedelta(days=int(round(float(raw))))

    s = str(raw).strip()
    if s.lower() in BLANK_WORDS:
        return None
    if re.fullmatch(r"\d+(\.0+)?", s) and 1000 < float(s) < 80000:
        return EXCEL_EPOCH + timedelta(days=int(float(s)))

    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d/%m/%y", "%d-%m-%y",
                "%Y/%m/%d", "%d %b %Y", "%d %B %Y", "%b %d, %Y"):
        try:
            return datetime.strptime(s[:19].replace("T", " ").split(" ")[0]
                                     if fmt == "%Y-%m-%d" else s, fmt).date()
        except ValueError:
            continue
    raise ValueError(f"“{raw}” is not a recognisable date")


def coerce(f: Field, raw: Any, *, today: Optional[date] = None) -> Coerced:
    today = today or date.today()
    out = Coerced()

    if raw is None or (isinstance(raw, str) and raw.strip().lower() in BLANK_WORDS):
        return out

    try:
        if f.type == "bool":
            s = str(raw).strip().lower()
            if s in TRUE_WORDS:
                out.value = True
            elif s in FALSE_WORDS:
                out.value = False
            else:
                out.issues.append(_issue(f, "error", f"“{raw}” is not Yes or No"))
            return out

        if f.type == "date":
            d = parse_date(raw)
            if d is None:
                return out
            if d > today:
                out.issues.append(_issue(f, "error", "the date is in the future"))
                return out
            if d.year < 1900:
                out.issues.append(_issue(f, "error", "the year looks implausible"))
                return out
            out.value = d
            return out

        if f.type in ("int", "float"):
            s = str(raw).replace(",", "").strip()
            s = re.sub(r"[^\d.\-eE+]", "", s)
            if s in ("", "-", "."):
                out.issues.append(_issue(f, "error", f"“{raw}” is not a number"))
                return out
            n = float(s)
            if f.type == "int":
                n = int(round(n))
            if f.minimum is not None and n < f.minimum:
                out.issues.append(_issue(f, "error",
                                         f"{n} is below the permitted minimum {f.minimum}"
                                         f"{' ' + f.unit if f.unit else ''}"))
                return out
            if f.maximum is not None and n > f.maximum:
                out.issues.append(_issue(f, "error",
                                         f"{n} is above the permitted maximum {f.maximum}"
                                         f"{' ' + f.unit if f.unit else ''}"))
                return out
            if f.soft and not (f.soft[0] <= n <= f.soft[1]):
                out.issues.append(_issue(f, "warning",
                                         f"{n}{' ' + f.unit if f.unit else ''} is outside the "
                                         f"usual range {f.soft[0]}–{f.soft[1]} — please confirm"))
            out.value = n
            return out

        if f.type == "enum":
            s = str(raw).strip()
            choices = f.choices or []
            # Ordered from most to least specific. The descriptive-part check
            # comes before substring matching so that "partial response" resolves
            # to PR and not to VGPR, whose label also contains those words.
            hit = (next((c for c in choices if c.lower() == s.lower()), None)
                   or next((c for c in choices if c.split(" —")[0].lower() == s.lower()), None)
                   or next((c for c in choices
                            if c.split("—")[-1].strip().lower() == s.lower()), None)
                   or next((c for c in choices if c.lower().startswith(s.lower())), None))
            if hit is None and _squash(s):
                # last resort: the shortest label containing the text, so a more
                # specific code is never shadowed by a longer one
                cands = [c for c in choices if _squash(s) in _squash(c)]
                hit = min(cands, key=len) if cands else None
            if hit:
                out.value = hit
            else:
                out.issues.append(_issue(f, "warning",
                                         f"“{s}” did not match a coded value — left blank for review"))
            return out

        out.value = str(raw).strip()
        return out

    except ValueError as exc:
        out.issues.append(_issue(f, "error", str(exc)))
        return out


def _squash(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


# --------------------------------------------------------------------------- cross-field
def check_consistency(patient, lines=None) -> list[Issue]:
    """Rules that involve more than one field. Warnings unless clearly impossible."""
    issues: list[Issue] = []
    lines = list(lines if lines is not None else getattr(patient, "therapy_lines", []) or [])

    def w(label, col, msg):
        issues.append(Issue(label, col, "warning", msg))

    def e(label, col, msg):
        issues.append(Issue(label, col, "error", msg))

    dx = patient.dx_date
    if dx:
        for lbl, col, d in (("Date of death", "BK", patient.death_date),
                            ("Last Follow up date", "BM", patient.last_followup_date),
                            ("Relapse/Progression Date", "BD", patient.relapse_date)):
            if d and d < dx:
                e(lbl, col, "cannot be earlier than the date of diagnosis")
        for ln in lines:
            if ln.start_date and ln.start_date < dx:
                e(f"Line {ln.line_no} start date", None,
                  "cannot be earlier than the date of diagnosis")

    if patient.death and not patient.death_date:
        e("Date of death", "BK", "required when the patient is recorded as deceased")
    if patient.death and patient.death_date and patient.last_followup_date \
            and patient.last_followup_date > patient.death_date:
        w("Last Follow up date", "BM", "is later than the recorded date of death")
    if patient.relapse and not patient.relapse_date:
        w("Relapse/Progression Date", "BD", "not recorded although relapse is marked Yes")
    if patient.relapse is False and patient.relapse_date:
        w("Relapse/Progression", "BC", "a progression date is present but relapse is marked No")
    if patient.transformation and not patient.transformation_date:
        w("Date of transformation", None, "not recorded although transformation is marked Yes")

    if len(lines) > 1 and patient.relapse is False:
        w("Relapse/Progression", "BC",
          "a second line of therapy is recorded but relapse is marked No")

    if patient.kappa_flc is not None and patient.lambda_flc == 0:
        w("Lambda light chain", "AK", "zero — the SFLC ratio cannot be computed")

    starts = [l.start_date for l in lines if l.start_date]
    if len(starts) != len(set(starts)):
        w("Therapy lines", None, "two lines share the same start date")

    return issues
