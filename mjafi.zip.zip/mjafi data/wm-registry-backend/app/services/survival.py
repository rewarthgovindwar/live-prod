"""Kaplan-Meier estimation, computed in the database process.

Deliberately dependency-free: the estimator is a dozen lines and adding pandas
or lifelines to a hospital-server deployment is a maintenance cost the registry
does not need. Greenwood's formula supplies the variance for the confidence
band and for the log-rank test between groups.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Optional, Sequence


@dataclass
class KMPoint:
    time: float
    n_risk: int
    n_event: int
    n_censored: int
    survival: float
    ci_low: float
    ci_high: float


@dataclass
class KMCurve:
    label: str
    n: int
    events: int
    points: list[KMPoint]
    median: Optional[float]
    median_ci: tuple[Optional[float], Optional[float]]

    def as_dict(self) -> dict:
        return {
            "label": self.label, "n": self.n, "events": self.events,
            "median_months": self.median,
            "median_ci": list(self.median_ci),
            "points": [
                {"t": p.time, "at_risk": p.n_risk, "events": p.n_event,
                 "censored": p.n_censored, "s": round(p.survival, 4),
                 "lo": round(p.ci_low, 4), "hi": round(p.ci_high, 4)}
                for p in self.points
            ],
        }


def kaplan_meier(observations: Iterable[tuple[Optional[float], int]], label: str = "All") -> KMCurve:
    """observations: iterable of (time_in_months, event_indicator 0|1)."""
    data = sorted([(float(t), int(bool(e))) for t, e in observations if t is not None and t >= 0],
                  key=lambda x: (x[0], -x[1]))
    n_total = len(data)
    if n_total == 0:
        return KMCurve(label, 0, 0, [], None, (None, None))

    points = [KMPoint(0.0, n_total, 0, 0, 1.0, 1.0, 1.0)]
    at_risk = n_total
    surv = 1.0
    greenwood = 0.0
    total_events = 0

    i = 0
    while i < len(data):
        t = data[i][0]
        events = censored = 0
        while i < len(data) and data[i][0] == t:
            if data[i][1]:
                events += 1
            else:
                censored += 1
            i += 1

        if events and at_risk > 0:
            surv *= (1 - events / at_risk)
            total_events += events
            denom = at_risk * (at_risk - events)
            greenwood += (events / denom) if denom > 0 else 0.0

        # log-log transformed confidence interval, clipped to [0, 1]
        if 0 < surv < 1 and greenwood > 0:
            se = math.sqrt(greenwood)
            log_s = math.log(surv)
            factor = math.exp(1.96 * se / abs(log_s))
            lo = surv ** factor
            hi = surv ** (1 / factor)
        else:
            lo = hi = surv
        points.append(KMPoint(t, at_risk, events, censored, surv,
                              max(0.0, min(1.0, lo)), max(0.0, min(1.0, hi))))
        at_risk -= (events + censored)

    median = next((p.time for p in points if p.survival <= 0.5), None)
    med_lo = next((p.time for p in points if p.ci_high <= 0.5), None)
    med_hi = next((p.time for p in points if p.ci_low <= 0.5), None)
    return KMCurve(label, n_total, total_events, points, median, (med_lo, med_hi))


def logrank(groups: Sequence[Sequence[tuple[Optional[float], int]]]) -> Optional[dict]:
    """Log-rank test across 2+ groups. Returns chi-square, df and an approximate p."""
    clean = [[(float(t), int(bool(e))) for t, e in g if t is not None and t >= 0] for g in groups]
    clean = [g for g in clean if g]
    k = len(clean)
    if k < 2:
        return None

    times = sorted({t for g in clean for t, _ in g})
    obs = [0.0] * k
    exp = [0.0] * k

    for t in times:
        at_risk = [sum(1 for tt, _ in g if tt >= t) for g in clean]
        events = [sum(1 for tt, ee in g if tt == t and ee) for g in clean]
        n = sum(at_risk)
        d = sum(events)
        if n == 0 or d == 0:
            continue
        for j in range(k):
            obs[j] += events[j]
            exp[j] += d * at_risk[j] / n

    chi2 = sum(((obs[j] - exp[j]) ** 2) / exp[j] for j in range(k) if exp[j] > 0)
    df = k - 1
    return {"chi_square": round(chi2, 3), "df": df,
            "p_value": _chi2_sf(chi2, df),
            "observed": obs, "expected": [round(e, 2) for e in exp]}


def _chi2_sf(x: float, df: int) -> float:
    """Upper tail of the chi-square distribution (regularised incomplete gamma)."""
    if x <= 0:
        return 1.0
    a = df / 2.0
    xx = x / 2.0
    if xx < a + 1:
        # series expansion
        term = 1.0 / a
        total = term
        n = 1
        while n < 500:
            term *= xx / (a + n)
            total += term
            if abs(term) < abs(total) * 1e-12:
                break
            n += 1
        p = total * math.exp(-xx + a * math.log(xx) - math.lgamma(a))
        return round(max(0.0, min(1.0, 1.0 - p)), 6)
    # continued fraction
    tiny = 1e-300
    b = xx + 1 - a
    c = 1 / tiny
    d = 1 / b if b != 0 else 1 / tiny
    h = d
    for i in range(1, 500):
        an = -i * (i - a)
        b += 2
        d = an * d + b
        if abs(d) < tiny:
            d = tiny
        c = b + an / c
        if abs(c) < tiny:
            c = tiny
        d = 1 / d
        delta = d * c
        h *= delta
        if abs(delta - 1) < 1e-12:
            break
    q = math.exp(-xx + a * math.log(xx) - math.lgamma(a)) * h
    return round(max(0.0, min(1.0, q)), 6)
