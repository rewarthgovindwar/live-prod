"""Derived clinical values.

Everything the worksheet marks as calculated is computed here, on the server,
from the stored primary data. Nothing derived is ever persisted, so a correction
to a source value cannot leave a stale score behind, and an API client cannot
submit a fabricated risk group.

References
----------
IPSS-WM (Morel et al., Blood 2009): one point each for age > 65 years,
haemoglobin <= 11.5 g/dL, platelets <= 100 x10^9/L, beta-2 microglobulin
> 3 mg/L and serum monoclonal IgM > 70 g/L. Low = 0-1 adverse covariates and
age <= 65; Intermediate = 2 covariates or age > 65; High = more than 2.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Any, Iterable, Optional

from app.core.config import settings
from app.services.dictionary import BTKI_PATTERN

DAYS_PER_MONTH = 30.4375


# --------------------------------------------------------------------------- helpers
def months_between(start: Optional[date], end: Optional[date]) -> Optional[float]:
    if not start or not end:
        return None
    return round((end - start).days / DAYS_PER_MONTH, 1)


def _yn(value: Optional[bool]) -> Optional[str]:
    if value is None:
        return None
    return "Yes" if value else "No"


# --------------------------------------------------------------------------- IPSS-WM
@dataclass
class IpssResult:
    score: Optional[int]
    risk: Optional[str]
    components: dict[str, Optional[bool]]
    missing: list[str]

    def as_dict(self) -> dict[str, Any]:
        return {"score": self.score, "risk": self.risk,
                "components": self.components, "missing": self.missing}


IPSS_LABELS = {
    "age_gt_65": "Age > 65 years",
    "hb_le_115": "Haemoglobin ≤ 11.5 g/dL",
    "plt_le_100": "Platelets ≤ 100 ×10⁹/L",
    "b2m_gt_3": "Beta-2 microglobulin > 3 mg/L",
    "igm_gt_70": "Serum IgM > 70 g/L",
}


def ipss_wm(*, age: Optional[int], hb: Optional[float], platelets: Optional[float],
            beta2m: Optional[float], igm: Optional[float]) -> IpssResult:
    comp: dict[str, Optional[bool]] = {
        "age_gt_65": None if age is None else age > 65,
        "hb_le_115": None if hb is None else hb <= 11.5,
        "plt_le_100": None if platelets is None else platelets <= 100,
        "b2m_gt_3": None if beta2m is None else beta2m > 3,
        "igm_gt_70": None if igm is None else igm > 70,
    }
    missing = [IPSS_LABELS[k] for k, v in comp.items() if v is None]
    if missing:
        return IpssResult(None, None, comp, missing)

    score = sum(1 for v in comp.values() if v)
    if score > 2:
        risk = "High"
    elif score == 2 or comp["age_gt_65"]:
        risk = "Intermediate"
    else:
        risk = "Low"
    return IpssResult(score, risk, comp, [])


# --------------------------------------------------------------------------- survival
@dataclass
class Survival:
    pfs_months: Optional[float]
    pfs_event: int          # 1 = progression or death observed, 0 = censored
    pfs_origin: Optional[date]
    os_months: Optional[float]
    os_event: int
    ttft_months: Optional[float]
    followup_months: Optional[float]

    def as_dict(self) -> dict[str, Any]:
        return {
            "pfs_months": self.pfs_months, "pfs_event": self.pfs_event,
            "os_months": self.os_months, "os_event": self.os_event,
            "time_to_first_treatment_months": self.ttft_months,
            "followup_months": self.followup_months,
        }


def survival(*, dx_date: Optional[date], first_line_start: Optional[date],
             relapse_date: Optional[date], death: Optional[bool],
             death_date: Optional[date], last_followup: Optional[date]) -> Survival:
    """PFS from the start of first-line therapy; OS from the date of diagnosis.

    PFS is censored at last follow-up when neither progression nor death is
    recorded. If first-line therapy has not started, PFS is measured from
    diagnosis so untreated (watch-and-wait) patients still contribute.
    """
    died = bool(death)
    origin = first_line_start or dx_date

    pfs_end_candidates = [d for d in (relapse_date, death_date if died else None) if d]
    pfs_event = 1 if pfs_end_candidates else 0
    pfs_end = min(pfs_end_candidates) if pfs_end_candidates else last_followup

    pfs = months_between(origin, pfs_end)
    if pfs is not None and pfs < 0:
        pfs = 0.0

    os_end = death_date if died else last_followup
    os = months_between(dx_date, os_end)
    if os is not None and os < 0:
        os = 0.0

    return Survival(
        pfs_months=pfs, pfs_event=pfs_event, pfs_origin=origin,
        os_months=os, os_event=1 if died else 0,
        ttft_months=months_between(dx_date, first_line_start),
        followup_months=months_between(dx_date, death_date if died else last_followup),
    )


# --------------------------------------------------------------------------- whole record
def is_btki(category: Optional[str], regimen: Optional[str]) -> bool:
    blob = f"{category or ''} {regimen or ''}".lower()
    return any(token in blob for token in BTKI_PATTERN)


def derive_patient(patient, lines: Iterable[Any] | None = None) -> dict[str, Any]:
    """Compute every derived worksheet column for one patient ORM object."""
    lines = sorted(list(lines if lines is not None else patient.therapy_lines),
                   key=lambda l: (l.line_no or 0))
    l1 = lines[0] if lines else None
    l2 = lines[1] if len(lines) > 1 else None

    ipss = ipss_wm(age=patient.age, hb=patient.hb, platelets=patient.platelets,
                   beta2m=patient.beta2m, igm=patient.igm)
    surv = survival(dx_date=patient.dx_date,
                    first_line_start=l1.start_date if l1 else None,
                    relapse_date=patient.relapse_date,
                    death=patient.death, death_date=patient.death_date,
                    last_followup=patient.last_followup_date)

    btki = any(is_btki(l.category, l.regimen) for l in lines) if lines else None

    event: Optional[bool]
    if patient.relapse or patient.death or patient.transformation:
        event = True
    elif patient.relapse is False and patient.death is False:
        event = False
    else:
        event = None

    return {
        # worksheet G, Z, AI, AL
        "dx_year": patient.dx_date.year if patient.dx_date else None,
        "elevated_ldh": _yn(patient.ldh > settings.LDH_UPPER_LIMIT) if patient.ldh is not None else None,
        "igm_above_threshold": (_yn(patient.igm > settings.IGM_FLAG_THRESHOLD)
                                if patient.igm is not None else None),
        "sflc_ratio": (round(patient.kappa_flc / patient.lambda_flc, 2)
                       if patient.kappa_flc is not None and patient.lambda_flc else None),
        # worksheet AT, AU
        "ipss_score": ipss.score,
        "ipss_risk": ipss.risk,
        "ipss_detail": ipss.as_dict(),
        # worksheet AV-BB projected from therapy_lines
        "total_lines": len(lines),
        "l1_category": l1.category if l1 else None,
        "l1_regimen": l1.regimen if l1 else None,
        "l1_cycles": l1.cycles if l1 else None,
        "l1_start": l1.start_date if l1 else None,
        "l1_end": l1.end_date if l1 else None,
        "l1_response": l1.best_response if l1 else None,
        # worksheet BE, BF
        "second_line_received": _yn(l2 is not None) if lines else None,
        "l2_regimen": l2.regimen if l2 else None,
        # worksheet BH, BI
        "btki_ever": _yn(btki) if btki is not None else None,
        "event": _yn(event) if event is not None else None,
        # survival
        **surv.as_dict(),
    }


# --------------------------------------------------------------------------- completeness
def completeness(patient, lines: Iterable[Any] | None = None) -> dict[str, Any]:
    """Percentage of non-derived worksheet fields that carry a value."""
    from app.services.dictionary import PATIENT_FIELDS

    derived = derive_patient(patient, lines)
    captured = total = 0
    missing_required: list[str] = []

    for f in PATIENT_FIELDS:
        if f.type == "derived" or f.key == "centre_code":
            continue
        if f.key.startswith("l1_") or f.key == "l2_regimen":
            value = derived.get(f.key)
        else:
            value = getattr(patient, f.key, None)
        # conditional fields only count when their trigger is set
        if f.key == "relapse_date" and not patient.relapse:
            continue
        if f.key in {"death_date", "death_cause"} and not patient.death:
            continue
        if f.key == "transformation_date" and not patient.transformation:
            continue
        total += 1
        if value not in (None, ""):
            captured += 1
        elif f.required:
            missing_required.append(f"{f.label} ({f.col})" if f.col else f.label)

    pct = round(captured * 100 / total) if total else 0
    return {"captured": captured, "total": total, "percent": pct,
            "missing_required": missing_required,
            "submittable": not missing_required}
