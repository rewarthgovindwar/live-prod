"""The registry data dictionary — one definition consumed by everything.

Validation, Excel import, Excel/CSV export, the ``/meta/dictionary`` endpoint and
the front-end form builder all read this table, so a field can never be
validated one way and exported another.

``col`` is the column letter in the original IMAGe WM worksheet. ``None`` marks a
registry extension that does not exist in the flat worksheet.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

# --------------------------------------------------------------------------- picklists
YES_NO = ["Yes", "No"]
REACTIVE = ["Reactive", "Negative"]
SRSM = ["Low", "Low-Intermediate", "Intermediate", "High"]
IPSS_RISK = ["Low", "Intermediate", "High"]
GENDER = ["Male", "Female", "Other"]
MYD88 = ["Positive", "Negative", "Not done"]
SIFE = ["IgM Kappa", "IgM Lambda", "IgM Kappa + free Kappa", "IgM Lambda + free Lambda",
        "Biclonal", "Not detected", "Not done"]
RX_CATEGORY = ["Chemo-immunotherapy", "Bortezomib based therapy",
               "BTK inhibitor based therapy", "Other"]
RESPONSE = ["CR — Complete Response", "VGPR — Very Good Partial Response",
            "PR — Partial Response", "MR — Minor Response", "SD — Stable Disease",
            "PD — Progressive Disease", "Not evaluable"]
DEATH_CAUSE = ["Disease progression", "Infection / sepsis", "Treatment-related toxicity",
               "Histological transformation", "Second primary malignancy",
               "Cardiovascular event", "Bleeding", "Unrelated cause", "Unknown"]
VISIT_TYPE = ["Routine follow-up", "On-treatment assessment", "Response assessment",
              "Toxicity review", "Suspected progression", "Post-progression / salvage",
              "Terminal / palliative"]
STOP_REASON = ["Planned course completed", "Progressive disease", "Toxicity",
               "Patient choice / non-compliance", "Death", "Lost to follow-up",
               "Financial constraint", "Ongoing"]
REGIMENS: dict[str, list[str]] = {
    "Chemo-immunotherapy": [
        "DRC (Dexamethasone–Rituximab–Cyclophosphamide)", "BR (Bendamustine–Rituximab)",
        "R-CHOP", "RCD (Rituximab–Cyclophosphamide–Dexamethasone)", "Rituximab monotherapy",
        "Chlorambucil", "Fludarabine–Rituximab", "CVP ± Rituximab"],
    "Bortezomib based therapy": [
        "BDR (Bortezomib–Dexamethasone–Rituximab)", "Bortezomib–Dexamethasone",
        "VCD (Bortezomib–Cyclophosphamide–Dexamethasone)", "Bortezomib monotherapy"],
    "BTK inhibitor based therapy": [
        "Ibrutinib monotherapy", "Ibrutinib + Rituximab", "Zanubrutinib", "Acalabrutinib"],
    "Other": [
        "Plasmapheresis + corticosteroids", "Thalidomide–Rituximab", "Autologous SCT",
        "Observation / watch & wait", "Clinical trial regimen", "Best supportive care",
        "Other (specify in notes)"],
}
ALL_REGIMENS = [r for group in REGIMENS.values() for r in group]

BTKI_PATTERN = ("ibrutinib", "zanubrutinib", "acalabrutinib", "tirabrutinib", "pirtobrutinib", "btk")


# --------------------------------------------------------------------------- field spec
@dataclass(frozen=True)
class Field:
    key: str                       # ORM attribute / API field name
    col: Optional[str]             # worksheet column letter
    label: str                     # exact worksheet heading where one exists
    type: str                      # int | float | bool | date | text | enum | derived
    unit: Optional[str] = None
    required: bool = False
    minimum: Optional[float] = None
    maximum: Optional[float] = None
    soft: Optional[tuple[float, float]] = None      # plausible clinical range
    choices: Optional[list[str]] = None
    section: str = ""
    aliases: tuple[str, ...] = ()
    note: str = ""


F = Field

PATIENT_FIELDS: list[Field] = [
    # --- enrolment ---------------------------------------------------------
    F("registry_no", "A", "S No", "derived", section="Enrolment",
      note="assigned by the registry"),
    F("centre_code", "B", "AHC", "derived", section="Enrolment",
      note="stamped from the signed-in user's centre", aliases=("centre", "center", "site")),
    F("crno", "C", "CR No", "text", required=True, section="Enrolment",
      aliases=("uhid", "hospital no", "hospital number", "mrn", "patient id")),
    F("age", "D", "Age", "int", unit="years", required=True, minimum=14, maximum=105,
      soft=(25, 90), section="Enrolment", aliases=("age at diagnosis",)),
    F("gender", "E", "Gender", "enum", required=True, choices=GENDER, section="Enrolment",
      aliases=("sex",)),
    F("dx_date", "F", "Date of diagnosis", "date", required=True, section="Enrolment",
      aliases=("diagnosis date", "dx date")),
    F("dx_year", "G", "year of diagnosis", "derived", section="Enrolment"),

    # --- clinical presentation --------------------------------------------
    F("sym_anaemia", "H", "Symptoms of anemia", "bool", required=True, section="Clinical"),
    F("fever", "I", "Fever", "bool", required=True, section="Clinical"),
    F("bleeding", "J", "Bleeding", "bool", required=True, section="Clinical"),
    F("hyperviscosity", "K", "Hyperviscosity", "bool", required=True, section="Clinical"),
    F("constitutional", "L", "Constitutional symptoms", "bool", required=True, section="Clinical"),
    F("igm_symptoms", "M", "IgM related symp (except hyperviscosity)", "bool", required=True,
      section="Clinical"),
    F("lymphadenopathy", "N", "lymphadenopathy", "bool", required=True, section="Clinical"),
    F("splenomegaly", "O", "Splenomegaly", "bool", required=True, section="Clinical"),
    F("ecog_dx", None, "ECOG PS at diagnosis", "int", minimum=0, maximum=4, section="Clinical"),
    F("clinical_notes", None, "Clinical remarks", "text", section="Clinical"),

    # --- haematology & biochemistry ---------------------------------------
    F("hb", "P", "Hb", "float", unit="g/dL", required=True, minimum=1, maximum=22,
      soft=(6, 17), section="Haematology", aliases=("haemoglobin", "hemoglobin")),
    F("tlc", "Q", "TLC", "float", unit="×10⁹/L", required=True, minimum=0.1, maximum=400,
      soft=(2, 20), section="Haematology", aliases=("wbc", "total leucocyte count")),
    F("alc", "R", "ALC", "float", unit="×10⁹/L", required=True, minimum=0, maximum=300,
      soft=(0.5, 10), section="Haematology", aliases=("absolute lymphocyte count",)),
    F("platelets", "S", "Platelet", "float", unit="×10⁹/L", required=True, minimum=1, maximum=1500,
      soft=(50, 450), section="Haematology", aliases=("platelets", "platelet count")),
    F("calcium", "T", "Calcium", "float", unit="mg/dL", minimum=4, maximum=20, soft=(8, 11),
      section="Biochemistry", aliases=("serum calcium",)),
    F("urea", "U", "Urea", "float", unit="mg/dL", minimum=5, maximum=300, soft=(15, 50),
      section="Biochemistry", aliases=("blood urea",)),
    F("creatinine", "V", "Creatinine", "float", unit="mg/dL", minimum=0.1, maximum=20,
      soft=(0.4, 1.6), section="Biochemistry", aliases=("serum creatinine",)),
    F("total_protein", "W", "Total protein", "float", unit="g/dL", minimum=3, maximum=16,
      soft=(6, 9), section="Biochemistry"),
    F("albumin", "X", "Albumin", "float", unit="g/dL", minimum=1, maximum=6, soft=(3, 5),
      section="Biochemistry", aliases=("serum albumin",)),
    F("ldh", "Y", "LDH", "float", unit="U/L", minimum=20, maximum=6000, soft=(100, 450),
      section="Biochemistry", aliases=("serum ldh",)),
    F("elevated_ldh", "Z", "Elevated LDH", "derived", section="Biochemistry"),

    # --- risk --------------------------------------------------------------
    F("srsm_score", "AA", "SRSM WM score", "enum", required=True, choices=SRSM, section="Risk"),

    # --- serology ----------------------------------------------------------
    F("hiv", "AB", "HIV", "enum", required=True, choices=REACTIVE, section="Serology"),
    F("hbsag", "AC", "HBsAG", "enum", required=True, choices=REACTIVE, section="Serology",
      aliases=("hbsag",)),
    F("anti_hcv", "AD", "Anti HCV", "enum", required=True, choices=REACTIVE, section="Serology"),
    F("anti_hbc", "AE", "Anti HBc", "enum", choices=REACTIVE, section="Serology"),

    # --- paraprotein -------------------------------------------------------
    F("m_band", "AF", "M band quantification", "float", unit="g/dL", minimum=0, maximum=12,
      soft=(0.2, 7), section="Paraprotein"),
    F("sife", "AG", "SIFE", "enum", required=True, choices=SIFE, section="Paraprotein"),
    F("igm", "AH", "IgM level", "float", unit="g/L", required=True, minimum=0, maximum=200,
      soft=(3, 90), section="Paraprotein", aliases=("serum igm", "igm")),
    F("igm_above_threshold", "AI", "IgM > 7.5g/L", "derived", section="Paraprotein"),
    F("kappa_flc", "AJ", "kappa light chain", "float", unit="mg/L", minimum=0, maximum=20000,
      soft=(3, 400), section="Paraprotein", aliases=("kappa", "serum free kappa")),
    F("lambda_flc", "AK", "Lambda light chain", "float", unit="mg/L", minimum=0, maximum=20000,
      soft=(3, 400), section="Paraprotein", aliases=("lambda", "serum free lambda")),
    F("sflc_ratio", "AL", "SFLC Ratio", "derived", section="Paraprotein"),

    # --- associated phenomena ---------------------------------------------
    F("dct", "AM", "DCT", "bool", section="Associated", aliases=("direct coombs test",)),
    F("amyloid", "AN", "Amyloid", "bool", section="Associated", aliases=("amyloidosis",)),
    F("cryoglobulins", "AO", "Cryoglobulins", "bool", section="Associated"),
    F("beta2m", "AP", "Beta2 MG", "float", unit="mg/L", required=True, minimum=0.3, maximum=60,
      soft=(1, 8), section="Associated",
      aliases=("beta 2 microglobulin", "b2m", "beta2 microglobulin")),

    # --- marrow & molecular -----------------------------------------------
    F("pb_lpl", "AQ", "Peripheral blood circulating LPL cells", "bool", section="Marrow"),
    F("bm_lpl_pct", "AR", "Bone marrow LPL cell %", "float", unit="%", required=True,
      minimum=0, maximum=100, soft=(5, 95), section="Marrow",
      aliases=("bone marrow lpl", "marrow infiltration")),
    F("myd88", "AS", "MYD 88", "enum", choices=MYD88, section="Marrow",
      aliases=("myd88", "myd88 l265p")),
    F("cxcr4", None, "CXCR4 mutation", "enum", choices=MYD88, section="Marrow"),
    F("bm_date", None, "Date of bone marrow examination", "date", section="Marrow"),

    # --- derived risk ------------------------------------------------------
    F("ipss_score", "AT", "IPSS WM score", "derived", section="Risk"),
    F("ipss_risk", "AU", "IPSS WM risk", "derived", choices=IPSS_RISK, section="Risk"),

    # --- treatment (line 1 columns are projected from therapy_lines) -------
    F("total_lines", "AV", "Total Lines of Rx", "derived", section="Treatment"),
    F("l1_category", "AW", "First Line therapy category", "enum", required=True,
      choices=RX_CATEGORY, section="Treatment"),
    F("l1_regimen", "AX", "First Line therapy (exact regimen)", "enum", required=True,
      choices=ALL_REGIMENS, section="Treatment"),
    F("l1_cycles", "AY", "Number of cycles of therapy", "int", minimum=0, maximum=40,
      soft=(1, 12), section="Treatment"),
    F("l1_start", "AZ", "First therapy start date", "date", required=True, section="Treatment"),
    F("l1_end", "BA", "First therapy End date", "date", section="Treatment"),
    F("l1_response", "BB", "Response to First line therapy (as per IWMF)", "enum",
      required=True, choices=RESPONSE, section="Treatment"),

    # --- relapse / second line --------------------------------------------
    F("relapse", "BC", "Relapse/Progression", "bool", required=True, section="Outcome"),
    F("relapse_date", "BD", "Relapse/Progression Date", "date", section="Outcome"),
    F("second_line_received", "BE", "Received 2nd line therapy", "derived", section="Outcome"),
    F("l2_regimen", "BF", "Second line therapy (exact regimen)", "enum", choices=ALL_REGIMENS,
      section="Outcome"),

    # --- transformation & vital status ------------------------------------
    F("transformation", "BG", "Transformation", "bool", section="Outcome"),
    F("transformation_date", None, "Date of transformation", "date", section="Outcome"),
    F("btki_ever", "BH", "BTK inhibitor received at any time", "derived", section="Outcome"),
    F("event", "BI", "Event (relapse/progression/death)", "derived", section="Outcome"),
    F("death", "BJ", "Death", "bool", required=True, section="Outcome"),
    F("death_date", "BK", "Date of death", "date", section="Outcome"),
    F("death_cause", "BL", "Cause of death", "enum", choices=DEATH_CAUSE, section="Outcome"),
    F("last_followup_date", "BM", "Last Follow up date", "date", required=True, section="Outcome"),
]

FIELD_BY_KEY: dict[str, Field] = {f.key: f for f in PATIENT_FIELDS}

#: Worksheet column order, used verbatim by the export and template builders.
WORKSHEET_ORDER: list[Field] = sorted(
    [f for f in PATIENT_FIELDS if f.col],
    key=lambda f: (len(f.col), f.col),
)

#: Fields a client may write directly to the patient row.
WRITABLE_KEYS = {
    f.key for f in PATIENT_FIELDS
    if f.type != "derived" and f.key not in {"l1_category", "l1_regimen", "l1_cycles",
                                             "l1_start", "l1_end", "l1_response", "l2_regimen"}
}

BASELINE_KEYS = {f.key for f in PATIENT_FIELDS
                 if f.section in {"Enrolment", "Clinical", "Haematology", "Biochemistry",
                                  "Serology", "Paraprotein", "Associated", "Marrow", "Risk"}
                 and f.type != "derived" and f.key != "centre_code"}

FOLLOWUP_KEYS = {f.key for f in PATIENT_FIELDS
                 if f.section == "Outcome" and f.type != "derived"}


VISIT_FIELDS: list[Field] = [
    F("visit_date", None, "Visit date", "date", required=True, section="Visit"),
    F("visit_type", None, "Visit type", "enum", required=True, choices=VISIT_TYPE, section="Visit"),
    F("ecog", None, "ECOG PS", "int", minimum=0, maximum=4, section="Visit"),
    F("on_therapy", None, "Currently on therapy", "bool", section="Visit"),
    F("hb", None, "Hb", "float", unit="g/dL", minimum=1, maximum=22, soft=(6, 17), section="Visit"),
    F("tlc", None, "TLC", "float", unit="×10⁹/L", minimum=0.1, maximum=400, soft=(2, 20), section="Visit"),
    F("alc", None, "ALC", "float", unit="×10⁹/L", minimum=0, maximum=300, soft=(0.5, 10), section="Visit"),
    F("platelets", None, "Platelets", "float", unit="×10⁹/L", minimum=1, maximum=1500,
      soft=(50, 450), section="Visit"),
    F("creatinine", None, "Creatinine", "float", unit="mg/dL", minimum=0.1, maximum=20,
      soft=(0.4, 1.6), section="Visit"),
    F("total_protein", None, "Total protein", "float", unit="g/dL", minimum=3, maximum=16, section="Visit"),
    F("albumin", None, "Albumin", "float", unit="g/dL", minimum=1, maximum=6, section="Visit"),
    F("igm", None, "IgM level", "float", unit="g/L", minimum=0, maximum=200, section="Visit"),
    F("m_band", None, "M band", "float", unit="g/dL", minimum=0, maximum=12, section="Visit"),
    F("beta2m", None, "Beta2 MG", "float", unit="mg/L", minimum=0.3, maximum=60, section="Visit"),
    F("disease_status", None, "Disease status", "enum", required=True, choices=RESPONSE, section="Visit"),
    F("transfusion_dependent", None, "Transfusion dependent", "bool", section="Visit"),
    F("new_symptoms", None, "New / worsening symptoms", "text", section="Visit"),
    F("notes", None, "Visit notes", "text", section="Visit"),
]
VISIT_FIELD_BY_KEY = {f.key: f for f in VISIT_FIELDS}

LINE_FIELDS: list[Field] = [
    F("line_no", None, "Line number", "int", required=True, minimum=1, maximum=20, section="Line"),
    F("category", None, "Therapy category", "enum", required=True, choices=RX_CATEGORY, section="Line"),
    F("regimen", None, "Exact regimen", "enum", required=True, choices=ALL_REGIMENS, section="Line"),
    F("cycles", None, "Cycles delivered", "int", minimum=0, maximum=40, soft=(1, 12), section="Line"),
    F("start_date", None, "Start date", "date", required=True, section="Line"),
    F("end_date", None, "End date", "date", section="Line"),
    F("best_response", None, "Best response (IWMF)", "enum", required=True, choices=RESPONSE, section="Line"),
    F("stop_reason", None, "Reason for stopping", "enum", choices=STOP_REASON, section="Line"),
    F("grade3_toxicity", None, "Grade ≥3 toxicity", "bool", section="Line"),
    F("toxicity_detail", None, "Toxicity details", "text", section="Line"),
]
LINE_FIELD_BY_KEY = {f.key: f for f in LINE_FIELDS}


def as_dict() -> dict[str, Any]:
    """Serialisable dictionary for GET /meta/dictionary."""
    def ser(f: Field) -> dict:
        return {"key": f.key, "column": f.col, "label": f.label, "type": f.type,
                "unit": f.unit, "required": f.required, "min": f.minimum, "max": f.maximum,
                "expected_range": list(f.soft) if f.soft else None,
                "choices": f.choices, "section": f.section, "note": f.note or None}

    return {
        "patient": [ser(f) for f in PATIENT_FIELDS],
        "visit": [ser(f) for f in VISIT_FIELDS],
        "therapy_line": [ser(f) for f in LINE_FIELDS],
        "worksheet_order": [f.label for f in WORKSHEET_ORDER],
        "regimens_by_category": REGIMENS,
    }
