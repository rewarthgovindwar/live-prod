"""Pydantic request/response models."""
from __future__ import annotations

import uuid
from datetime import date, datetime
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

ORM = ConfigDict(from_attributes=True)


# --------------------------------------------------------------------------- auth
class LoginRequest(BaseModel):
    email: EmailStr
    password: str
    totp_code: Optional[str] = None


class TokenPair(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    must_change_password: bool = False
    totp_enrolment_required: bool = False


class RefreshRequest(BaseModel):
    refresh_token: str


class PasswordChange(BaseModel):
    current_password: str
    new_password: str = Field(min_length=12)


class TotpEnrolStart(BaseModel):
    secret: str
    otpauth_uri: str


class TotpEnrolConfirm(BaseModel):
    code: str


class CentreOut(BaseModel):
    model_config = ORM
    id: uuid.UUID
    code: str
    name: str
    city: Optional[str] = None
    state: Optional[str] = None
    zone: Optional[str] = None
    is_active: bool = True


class UserOut(BaseModel):
    model_config = ORM
    id: uuid.UUID
    email: EmailStr
    full_name: str
    designation: Optional[str] = None
    role: str
    is_active: bool
    totp_enabled: bool
    must_change_password: bool
    last_login_at: Optional[datetime] = None
    centre: Optional[CentreOut] = None


class UserCreate(BaseModel):
    email: EmailStr
    full_name: str
    designation: Optional[str] = None
    role: Literal["DEO", "CLIN", "HOD", "IMAGE"]
    centre_code: Optional[str] = None
    initial_password: str = Field(min_length=12)


class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    designation: Optional[str] = None
    role: Optional[Literal["DEO", "CLIN", "HOD", "IMAGE"]] = None
    is_active: Optional[bool] = None
    reset_password_to: Optional[str] = Field(default=None, min_length=12)


# --------------------------------------------------------------------------- patients
class PatientCreate(BaseModel):
    """Only the identifying minimum is required to open a record; the rest is
    filled in progressively through the eight CRF frames."""
    crno: str = Field(min_length=1, max_length=64)
    age: Optional[int] = None
    gender: Optional[str] = None
    dx_date: Optional[date] = None

    @field_validator("crno")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()


class PatientUpdate(BaseModel):
    """Sparse update. Any subset of writable fields; unknown keys are rejected."""
    model_config = ConfigDict(extra="forbid")

    crno: Optional[str] = None
    age: Optional[int] = None
    gender: Optional[str] = None
    dx_date: Optional[date] = None

    sym_anaemia: Optional[bool] = None
    fever: Optional[bool] = None
    bleeding: Optional[bool] = None
    hyperviscosity: Optional[bool] = None
    constitutional: Optional[bool] = None
    igm_symptoms: Optional[bool] = None
    lymphadenopathy: Optional[bool] = None
    splenomegaly: Optional[bool] = None
    ecog_dx: Optional[int] = None
    clinical_notes: Optional[str] = None

    hb: Optional[float] = None
    tlc: Optional[float] = None
    alc: Optional[float] = None
    platelets: Optional[float] = None
    calcium: Optional[float] = None
    urea: Optional[float] = None
    creatinine: Optional[float] = None
    total_protein: Optional[float] = None
    albumin: Optional[float] = None
    ldh: Optional[float] = None

    srsm_score: Optional[str] = None
    hiv: Optional[str] = None
    hbsag: Optional[str] = None
    anti_hcv: Optional[str] = None
    anti_hbc: Optional[str] = None

    m_band: Optional[float] = None
    sife: Optional[str] = None
    igm: Optional[float] = None
    kappa_flc: Optional[float] = None
    lambda_flc: Optional[float] = None

    dct: Optional[bool] = None
    amyloid: Optional[bool] = None
    cryoglobulins: Optional[bool] = None
    beta2m: Optional[float] = None

    pb_lpl: Optional[bool] = None
    bm_lpl_pct: Optional[float] = None
    myd88: Optional[str] = None
    cxcr4: Optional[str] = None
    bm_date: Optional[date] = None

    relapse: Optional[bool] = None
    relapse_date: Optional[date] = None
    transformation: Optional[bool] = None
    transformation_date: Optional[date] = None
    death: Optional[bool] = None
    death_date: Optional[date] = None
    death_cause: Optional[str] = None
    last_followup_date: Optional[date] = None

    version: Optional[int] = Field(default=None, description="Optimistic lock; send the value you read")


class TherapyLineIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    category: Optional[str] = None
    regimen: Optional[str] = None
    cycles: Optional[int] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    best_response: Optional[str] = None
    stop_reason: Optional[str] = None
    grade3_toxicity: Optional[bool] = None
    toxicity_detail: Optional[str] = None


class TherapyLineOut(BaseModel):
    model_config = ORM
    id: uuid.UUID
    line_no: int
    category: Optional[str] = None
    regimen: Optional[str] = None
    cycles: Optional[int] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    best_response: Optional[str] = None
    stop_reason: Optional[str] = None
    grade3_toxicity: Optional[bool] = None
    toxicity_detail: Optional[str] = None
    added_after_lock: bool = False


class VisitIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    visit_date: date
    visit_type: Optional[str] = None
    ecog: Optional[int] = None
    on_therapy: Optional[bool] = None
    hb: Optional[float] = None
    tlc: Optional[float] = None
    alc: Optional[float] = None
    platelets: Optional[float] = None
    creatinine: Optional[float] = None
    total_protein: Optional[float] = None
    albumin: Optional[float] = None
    igm: Optional[float] = None
    m_band: Optional[float] = None
    beta2m: Optional[float] = None
    disease_status: Optional[str] = None
    transfusion_dependent: Optional[bool] = None
    new_symptoms: Optional[str] = None
    notes: Optional[str] = None


class VisitOut(VisitIn):
    model_config = ORM
    id: uuid.UUID
    added_after_lock: bool = False


class PatientSummary(BaseModel):
    """Row shape for the patient list."""
    id: uuid.UUID
    registry_id: str
    registry_no: int
    centre_code: str
    crno: Optional[str] = None          # masked for the national view
    age: Optional[int] = None
    gender: Optional[str] = None
    dx_date: Optional[date] = None
    hb: Optional[float] = None
    igm: Optional[float] = None
    ipss_risk: Optional[str] = None
    l1_category: Optional[str] = None
    l1_response: Optional[str] = None
    pfs_months: Optional[float] = None
    pfs_event: int = 0
    os_months: Optional[float] = None
    os_event: int = 0
    death: Optional[bool] = None
    status: str
    completeness: int = 0
    open_queries: int = 0
    followup_amended: bool = False
    months_since_followup: Optional[float] = None


class PatientDetail(BaseModel):
    id: uuid.UUID
    registry_id: str
    registry_no: int
    centre: CentreOut
    status: str
    version: int
    fields: dict[str, Any]              # stored worksheet values
    derived: dict[str, Any]             # calculated worksheet values
    completeness: dict[str, Any]
    warnings: list[dict[str, Any]]
    therapy_lines: list[TherapyLineOut]
    visits: list[VisitOut]
    permissions: dict[str, bool]
    workflow: dict[str, Any]
    open_queries: list["QueryOut"] = []


class Page(BaseModel):
    items: list[Any]
    total: int
    limit: int
    offset: int


# --------------------------------------------------------------------------- workflow
class TransitionRequest(BaseModel):
    to: Literal["DRAFT", "SUBMITTED", "QUERY", "VERIFIED", "APPROVED"]
    note: Optional[str] = None


# --------------------------------------------------------------------------- queries
class QueryCreate(BaseModel):
    patient_id: uuid.UUID
    field_key: Optional[str] = None
    query_text: str = Field(min_length=5)


class QueryResolve(BaseModel):
    resolution_note: Optional[str] = None


class QueryOut(BaseModel):
    model_config = ORM
    id: uuid.UUID
    query_no: str
    patient_id: uuid.UUID
    registry_id: Optional[str] = None
    centre_code: Optional[str] = None
    field_key: Optional[str] = None
    field_label: Optional[str] = None
    query_text: str
    status: str
    raised_by_name: Optional[str] = None
    raised_at: datetime
    resolved_at: Optional[datetime] = None
    resolution_note: Optional[str] = None


# --------------------------------------------------------------------------- import
class ImportPreviewRow(BaseModel):
    row: int
    crno: Optional[str] = None
    verdict: Literal["ok", "warning", "error", "duplicate", "rejected"]
    completeness: int
    values: dict[str, Any]
    issues: list[dict[str, Any]]


class ImportPreview(BaseModel):
    batch_id: uuid.UUID
    filename: str
    sheet: Optional[str] = None
    detected_columns: list[str]
    mapping: dict[str, str]
    unmapped_columns: list[str]
    unmapped_required_fields: list[str]
    rows_read: int
    summary: dict[str, int]
    rows: list[ImportPreviewRow]


class ImportCommitRequest(BaseModel):
    batch_id: uuid.UUID
    mapping: Optional[dict[str, str]] = None
    skip_rows: list[int] = []


class ImportResult(BaseModel):
    batch_id: uuid.UUID
    imported: int
    skipped: int
    flagged: int
    registry_ids: list[str]


PatientDetail.model_rebuild()
