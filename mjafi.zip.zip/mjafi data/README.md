# IMAGe WM Registry — backend

Server for the Indian Myeloma Academic Groupe multicentric registry of
Waldenström macroglobulinemia. FastAPI + PostgreSQL, packaged to run on a single
institutional server.

The registry captures all 65 variables of the IMAGe WM worksheet, extends it
with longitudinal follow-up, and enforces the rule the study group set out:
**no centre can see another centre's data.**

---

## 1. What runs where

```
                    ┌──────────────────────────────────────────┐
  clinician's PC    │  Caddy (TLS, security headers)           │   :443
  ──────────────▶   │    /api/*  → api          /  → front-end │
                    └──────────────┬───────────────────────────┘
                                   │ (private network)
                    ┌──────────────▼───────────────┐
                    │  api — FastAPI, 4 workers    │   :8000, not published
                    │  connects as role wm_app     │
                    └──────────────┬───────────────┘
                                   │
                    ┌──────────────▼───────────────┐
                    │  db — PostgreSQL 16          │   :5432, not published
                    │  row-level security enforced │
                    └──────────────────────────────┘
```

Nothing except the proxy is reachable from the hospital network. The database
port is never published.

---

## 2. Install

Requires Docker Engine 24+ and Docker Compose v2 on Linux. 4 GB RAM and 40 GB of
disk is comfortable for tens of thousands of records.

```bash
git clone <your-repository> /opt/wm-registry
cd /opt/wm-registry

cp .env.example .env
openssl rand -hex 32                 # paste into SECRET_KEY
$EDITOR .env                         # change every CHANGE ME value

docker compose up -d db
docker compose run --rm api alembic upgrade head
docker compose run --rm api python -m scripts.seed        # centres + accounts
docker compose up -d
```

Check it is alive:

```bash
curl -s https://registry.example.org/health
# {"status":"ok","database":true,"environment":"production","version":"1.0.0"}
```

`scripts/seed.py` creates the six participating centres and one account per
role, all with the same initial password printed to the console, all forced to
change it at first sign-in. Change the centre list at the top of that file
before running it, or add centres afterwards through
`POST /api/v1/admin/centres`.

To load synthetic data for a demonstration, add `--demo`. Every synthetic
hospital number begins with `DEMO/` so it is unmistakable. **Never run `--demo`
against a live database.**

### Upgrading

```bash
git pull
docker compose build api
docker compose run --rm api alembic upgrade head
docker compose up -d api
```

Migrations are additive; take a backup first regardless.

---

## 3. How centre isolation is enforced

This is the part worth reviewing carefully, because it is the property the
study group is relying on.

**Layer 1 — application.** Every route reaches patient data through
`scoped_patients()` in `app/api/deps.py`, which filters on the signed-in user's
centre. A record belonging to another centre is reported as **404, not 403**:
a 403 would confirm that a given identifier exists somewhere in the registry.

**Layer 2 — database.** The API connects as `wm_app`, an unprivileged role.
Every table holding clinical data carries `centre_id` and has `FORCE ROW LEVEL
SECURITY` with policies comparing that column against
`current_setting('app.centre_id')`, which the application sets per transaction.
If a future endpoint forgets its filter, PostgreSQL still returns nothing.

`tests/test_isolation.py` attacks this from both sides, including raw SQL
underneath the application:

```python
# with AHC-02's context set, ask directly for AHC-03's rows
SELECT count(*) FROM patients WHERE centre_id = '<AHC-03>'   -->  0
```

**The national coordinator** is scoped differently rather than exempted:

| | centre staff | national coordinator |
|---|---|---|
| records visible | all of their own centre | only records a centre has released (verified or approved) |
| hospital CR number | visible | replaced by the registry ID, in the API and in exports |
| write access | own centre | **none** — the write policy excludes the national context at the database level |
| corrections | direct | only by raising a data query with the owning centre |

The one exception is deliberate and narrow: migration `0002` adds an
INSERT-only policy on `data_queries` so the coordinator can raise a query.
UPDATE and DELETE stay closed, so only the owning centre can close one.

---

## 4. Roles

`app/core/permissions.py` is the single source of truth and is published at
`GET /api/v1/meta/roles`, so the front-end cannot drift from it.

| capability | DEO | Clinician | HoD | IMAGe |
|---|:--:|:--:|:--:|:--:|
| view scope | own centre | own centre | own centre | pooled, all centres |
| create record | ✓ | ✓ | ✓ | — |
| edit baseline (frames 1–6) | ✓ | ✓ | ✓ | — |
| **edit follow-up after HoD lock** | ✓ | ✓ | ✓ | — |
| submit | ✓ | ✓ | ✓ | — |
| clinically verify | — | ✓ | ✓ | — |
| approve & lock | — | — | ✓ | — |
| unlock for correction | — | — | ✓ | — |
| raise data query | — | ✓ | ✓ | ✓ |
| resolve data query | ✓ | ✓ | ✓ | — |
| bulk import from Excel | ✓ | ✓ | ✓ | — |
| export centre dataset | — | — | ✓ | ✓ |
| export pooled dataset | — | — | — | ✓ |
| centre analytics | — | ✓ | ✓ | ✓ |
| national analytics / scorecard | — | — | — | ✓ |
| manage centre users | — | — | ✓ | — |

### Record lifecycle

```
DRAFT ──submit──▶ SUBMITTED ──verify──▶ VERIFIED ──approve──▶ APPROVED
  ▲                   │                    │                     │
  └──── return ───────┴────────────────────┘        unlock ──────┘
                      │
                   QUERY  (open data query on the record)
```

Approval locks **the baseline only**. Frames 7 and 8 — therapy lines, follow-up
visits, progression and vital status — stay open to the DEO, because locking a
record must not end the patient's follow-up. Each such change is marked
`added_after_lock`, sets `followup_amended` on the record and is written to the
audit trail, so the Head of Department can re-confirm.

---

## 5. Derived values

Everything the worksheet marks as calculated is computed on the server from
stored primary data and is **never accepted from a client** — posting
`ipss_risk` returns 422. Nothing derived is stored, so correcting a source value
cannot leave a stale score behind.

| worksheet column | derived from |
|---|---|
| G — year of diagnosis | date of diagnosis (F) |
| Z — elevated LDH | LDH (Y) above the laboratory limit, `LDH_UPPER_LIMIT` |
| AI — IgM > 7.5 g/L | IgM level (AH) |
| AL — SFLC ratio | kappa (AJ) ÷ lambda (AK) |
| AT / AU — IPSS-WM score and risk | age, Hb, platelets, β2M, IgM |
| AV — total lines of Rx | count of therapy lines |
| AW–BB — first-line columns | therapy line 1 |
| BE / BF — second line | therapy line 2 |
| BH — BTK inhibitor ever | any line containing a BTK inhibitor |
| BI — event | relapse, transformation or death |
| PFS / OS | see below |

**IPSS-WM** (Morel et al., *Blood* 2009;113:4163–70): one point each for age
> 65 years, haemoglobin ≤ 11.5 g/dL, platelets ≤ 100 ×10⁹/L, β2-microglobulin
> 3 mg/L, serum IgM > 70 g/L. Low = 0–1 points **and** age ≤ 65; Intermediate =
2 points **or** age > 65; High = more than 2. If any covariate is missing the
score is returned as `null` with the missing items named — it is never guessed.

**PFS** runs from the start of first-line therapy to the earliest of
progression, death, or last follow-up (censored). If therapy has not started it
runs from diagnosis, so watch-and-wait patients still contribute. **OS** runs
from diagnosis to death or last follow-up.

**Kaplan–Meier** is implemented in `app/services/survival.py` with Greenwood
variance, log–log confidence bands and a log-rank test — no external statistics
dependency to maintain on a hospital server. `tests/test_clinical.py` checks it
against a hand-worked example. Groups smaller than three patients are not
plotted.

---

## 6. Bulk import

Two phases so nothing is written until the operator has seen what will happen.

```
POST /imports/preview   (multipart file)  ──▶  parsed, validated, nothing written
POST /imports/commit    {batch_id}        ──▶  accepted rows created as drafts
```

* `.xlsx` and `.csv`; row 1 is the heading row.
* Column headings from the original IMAGe worksheet map automatically —
  in testing 50 of 52 columns mapped with no manual work, the two skipped being
  *S No* and *AHC*, which the registry assigns itself. The mapping is returned
  and can be corrected before committing.
* Accepts `Yes/Y/1/true`, matches coded values case-insensitively, and reads
  dates as `DD/MM/YYYY`, `DD-MM-YYYY`, ISO or native Excel serials. Impossible
  dates such as `31/02/2020` are rejected rather than rolled forward.
* Every row is stamped with the uploader's own centre; an `AHC` column in the
  file is ignored, so a file cannot introduce another centre's patients.
* Rows whose hospital number already exists are flagged and skipped, so
  re-uploading a corrected file does not create duplicates.
* The flat first-line columns (AW–BB) become a proper therapy line, keeping the
  normalised model and the flat sheet in agreement.

Blank templates: `GET /imports/template.xlsx` and `.csv`, with the permitted
values printed in row 2.

## 7. Export

`GET /exports/patients.csv` and `.xlsx` reproduce all 65 worksheet columns in
the original order, so the file opens directly in the study group's existing
analysis workflow. Add `?analysis=true` for nine extra columns (PFS, OS, their
event indicators, time to first treatment, follow-up duration, counts, status)
ready for R, Stata or SPSS. `visits.csv` and `therapy-lines.csv` give long-format
files for longitudinal modelling. Every export is written to the audit trail,
and pooled exports carry registry IDs in place of hospital numbers.

---

## 8. Security

* **Passwords** — Argon2id (64 MB, 3 passes). Strength rules enforced server
  side; a password change revokes every outstanding session.
* **Sessions** — 20-minute access token, 7-day rotating refresh token stored as
  a SHA-256 hash. Presenting a used refresh token fails.
* **Two-factor** — TOTP, mandatory for the roles in `REQUIRE_2FA_FOR_ROLES`
  (Head of Department and national coordinator by default).
* **Brute force** — five failures locks the account for 30 minutes. An unknown
  email and a wrong password return an identical response, and comparable
  timing, so the endpoint cannot enumerate accounts.
* **Audit trail** — append-only; `UPDATE` and `DELETE` are revoked from the
  application role. Every create, edit, transition, query, import and export is
  recorded with user, role, centre, timestamp, IP and a field-level change set.
* **Transport** — TLS terminates at Caddy, which adds HSTS and the usual
  hardening headers. The API sets `Cache-Control: no-store` on every response.

### Before going live

- [ ] `SECRET_KEY` set from `openssl rand -hex 32`, both database passwords changed
- [ ] `ENVIRONMENT=production` — this disables `/docs` and `/openapi.json`
- [ ] `CORS_ORIGINS` set to the real front-end origin only
- [ ] TLS certificate valid; port 5432 not reachable from the hospital network
- [ ] Nightly `scripts/backup.sh` in cron, **and one restore actually tested**
- [ ] Ethics approval reference recorded against each centre
- [ ] Data-sharing agreement signed by each participating centre

### Data protection

Patient records sit on institutional infrastructure and never leave it. The only
direct identifier held is the local hospital number, which stays inside the
owning centre — the pooled national view and pooled exports carry registry IDs
instead. Under India's Digital Personal Data Protection Act the participating
institutions are the data fiduciaries; IMAGe is a processor for the pooled
analysis. Retention, deletion and the grievance route belong in the
data-sharing agreement, not in code — the registry deliberately refuses to
delete anything past draft stage so that a deletion is always a documented
decision.

---

## 9. Layout

```
app/
  main.py               application, middleware, health
  core/
    config.py           every deployment setting, from the environment
    security.py         Argon2, JWT, TOTP
    permissions.py      roles, permissions, legal workflow transitions
  db.py                 engine, session, row-level-security context
  models/               SQLAlchemy ORM
  schemas.py            request/response models
  api/
    deps.py             authentication, permission gates, centre scoping
    auth.py  patients.py  imports.py  exports.py  analytics.py  admin.py
  services/
    dictionary.py       the data dictionary — one definition for everything
    derive.py           IPSS-WM, SFLC, PFS/OS and the other derived columns
    survival.py         Kaplan–Meier, Greenwood, log-rank
    validation.py       coercion, hard limits, soft clinical ranges
    excel.py            worksheet reading and writing
    audit.py            append-only trail
alembic/versions/       migrations (0001 schema + RLS, 0002 query policy)
scripts/                seed, backup, database role bootstrap
tests/                  79 tests
```

`app/services/dictionary.py` is worth reading first: validation, import, export,
the API metadata endpoint and the front-end form builder all consume it, so a
field cannot be validated one way and exported another.

---

## 10. Tests

```bash
createdb wm_registry_test
DATABASE_URL=... MIGRATION_DATABASE_URL=... alembic upgrade head
python -m scripts.seed --demo
pytest -q
```

79 tests covering centre isolation (application and database layer), the full
DEO → clinician → HoD lifecycle, follow-up on a locked record, optimistic
locking, IPSS-WM against its published definition, Kaplan–Meier against a
hand-worked example, log-rank, date and unit coercion, the import pipeline
including duplicate protection, and export column fidelity.

## 11. API

With `ENVIRONMENT=development`, interactive documentation is at `/docs`.

```
POST   /api/v1/auth/login | refresh | logout | change-password | 2fa/*
GET    /api/v1/patients                  list, scoped and filtered
POST   /api/v1/patients                  create in the caller's own centre
GET    /api/v1/patients/{id}             stored + derived + completeness + permissions
PATCH  /api/v1/patients/{id}             sparse update, optimistic locking
POST   /api/v1/patients/{id}/transition  submit / verify / approve / unlock / return
POST   /api/v1/patients/{id}/therapy-lines
POST   /api/v1/patients/{id}/visits      follow-up entry, open after lock
POST   /api/v1/imports/preview | commit  bulk import
GET    /api/v1/imports/template.xlsx
GET    /api/v1/exports/patients.xlsx|csv | visits.csv | therapy-lines.csv
GET    /api/v1/analytics/summary | survival | distributions | centres | followup-due
GET    /api/v1/queries        POST /api/v1/queries   POST /api/v1/queries/{id}/resolve
GET    /api/v1/audit
GET    /api/v1/meta/dictionary | roles | centres | config
```

`/meta/dictionary` returns every field with its column letter, type, units, hard
limits, expected clinical range and picklist — enough for a client to build the
entire case report form without hard-coding anything.
